<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ca_ES">
<context>
    <name>AlarmDialog</name>
    <message utf8="true">
        <source>ALARMA DE INTRUSIÓN</source>
        <translation>ALARMA D&apos;INTRUSIÓ</translation>
    </message>
    <message>
        <source>ALARMA DE FUEGO</source>
        <translation>ALARMA DE FOC</translation>
    </message>
    <message>
        <source>ALARMA DE GAS</source>
        <translation>ALARMA DE GAS</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE INUNDACIÓN</source>
        <translation>ALARMA D&apos;INUNDACIÓ</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE ELÉCTRICO</source>
        <translation>ALARMA DE TALL ELÈCTRIC</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE TELEFÓNICO</source>
        <translation>ALARMA DE TALL TELEFÒNIC</translation>
    </message>
    <message>
        <source>ALARMA DE SISTEMA</source>
        <translation>ALARMA DE SISTEMA</translation>
    </message>
    <message utf8="true">
        <source>ALARMA MÉDICA</source>
        <translation>ALARMA MÈDICA</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE PÁNICO</source>
        <translation>ALARMA DE PÀNIC</translation>
    </message>
    <message>
        <source>ALARMA SILENCIOSA</source>
        <translation>ALARMA SILENCIOSA</translation>
    </message>
    <message>
        <source>ALARMA DE SABOTAJE</source>
        <translation>ALARMA DE SABOTATGE</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE COACCIÓN</source>
        <translation>ALARMA DE COACCIÓ</translation>
    </message>
    <message>
        <source>
 en las siguientes zonas:
</source>
        <translation>a les següents zones:</translation>
    </message>
    <message>
        <source>REARMAR ALARMAS</source>
        <translation>REARMAR ALARMES</translation>
    </message>
    <message>
        <source>Hay alarmas desarmadas. Pulse rearmar para volver a proteger el sistema.</source>
        <translation>Hi ha alarmes desarmades. Premi rearmar per tornar a protegir el sistema.</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar alarmas</source>
        <translation>Introdueixi contrasenya per desarmar alarme</translation>
    </message>
</context>
<context>
    <name>AlarmDialogClass</name>
    <message>
        <source>AlarmDialog</source>
        <translation>DIÀLEG ALARMA</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Desarmar</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation>&lt;&lt;</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation>&gt;&gt;</translation>
    </message>
    <message utf8="true">
        <source>Menú
Alarmas</source>
        <translation>Menú
Alarmes</translation>
    </message>
    <message>
        <source>Rearmar</source>
        <translation>Rearmar</translation>
    </message>
</context>
<context>
    <name>AlarmsWindow</name>
    <message>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
</context>
<context>
    <name>AlarmsWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation>Incendi</translation>
    </message>
    <message>
        <source>Gas</source>
        <translation>Gas</translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation>Inundació</translation>
    </message>
    <message utf8="true">
        <source>Corte Eléctrico</source>
        <translation>Tall Elèctric</translation>
    </message>
    <message utf8="true">
        <source>Corte de Teléfono</source>
        <translation>Tall de Telèfon</translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation>Sistema</translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation>Mèdica</translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation>Pànic</translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation>Silenciosa</translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation>Sabotatge</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation>Etiqueta</translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation>Coacció</translation>
    </message>
</context>
<context>
    <name>ArmingWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Armando...</source>
        <translation>Armant...</translation>
    </message>
</context>
<context>
    <name>AssociatedZonesClass</name>
    <message>
        <source>AssociatedZones</source>
        <translation>Zones Associades</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Baixar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Pujar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message utf8="true">
        <source>Zonas asociadas con la unidad climática...</source>
        <translation>Zones Associades amb la unitat climàtica...</translation>
    </message>
</context>
<context>
    <name>BlackboardWindowClass</name>
    <message>
        <source>BlackboardWindow</source>
        <translation>BlackboardWindow</translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Borrar</translation>
    </message>
</context>
<context>
    <name>BlindControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Cap</translation>
    </message>
    <message>
        <source>Grupo de persianas</source>
        <translation>Grup de persianes</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estat desconegut</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi el nou nom...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
</context>
<context>
    <name>BlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associat:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <source>Bajar persianas en caso de lluvia</source>
        <translation>Baixar persianes en cas de pluja</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Temps de pujada / baixada:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Mode de funcionament:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Canviar icona</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>tots</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Bajar persianas en caso de viento fuerte</source>
        <translation>Baixar persianes en cas de vent fort</translation>
    </message>
</context>
<context>
    <name>CRAConfigDialog</name>
    <message>
        <source>ADEMCO CID</source>
        <translation>ADEMCO CID</translation>
    </message>
    <message utf8="true">
        <source>Introduzca el código de abonado ...</source>
        <translation>Introdueixi el codi d&apos;abonat ...</translation>
    </message>
</context>
<context>
    <name>CRAConfigDialogClass</name>
    <message>
        <source>CRAConfigDialog</source>
        <translation>CRAConfiguració</translation>
    </message>
    <message>
        <source>Configuracion CRA</source>
        <translation>Configuració CRA</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Habilitacion</source>
        <translation>Habitació</translation>
    </message>
    <message>
        <source>Cambiar
Codigo</source>
        <translation>Canviar
Codi</translation>
    </message>
    <message>
        <source>Protocolo</source>
        <translation>Protocol</translation>
    </message>
    <message>
        <source>Autotest</source>
        <translation>Autotest</translation>
    </message>
    <message>
        <source>Cadencia</source>
        <translation>Cadència</translation>
    </message>
    <message>
        <source>Hora del primer test</source>
        <translation>Hora del primer test</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:mm</translation>
    </message>
    <message>
        <source>Codigo de cuenta</source>
        <translation>Codi de compte</translation>
    </message>
</context>
<context>
    <name>CamsWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation>Trucada a porteria</translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation>Comunicació amb porteria establerta</translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation>No és possible establir comunicació perquè ja s&apos;ha despenjat des d&apos;un altre terminal.</translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation>Videoporter ocupat</translation>
    </message>
</context>
<context>
    <name>CamsWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation>Parlar</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Obrir</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation>Pujar Vol.</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation>Baixar Vol.</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Pujar</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Baixar</translation>
    </message>
    <message>
        <source>Izquierda</source>
        <translation>Esquerra</translation>
    </message>
    <message>
        <source>Derecha</source>
        <translation>Dreta</translation>
    </message>
</context>
<context>
    <name>ClimaControl</name>
    <message utf8="true">
        <source>Frío</source>
        <translation>Fred</translation>
    </message>
    <message>
        <source>Calor</source>
        <translation>Calor</translation>
    </message>
    <message>
        <source>Climatizador</source>
        <translation>Climatitzador</translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation>Apagat</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Cap</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi nou nom...</translation>
    </message>
</context>
<context>
    <name>ClimaControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Modo general:</source>
        <translation>Mode general:</translation>
    </message>
    <message>
        <source>Primer programa asociado:</source>
        <translation>Primer programa associat:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renombrar</translation>
    </message>
    <message utf8="true">
        <source>Apagar climatización en caso de ventana abierta</source>
        <translation>Apagar climatització en cas de finestra oberta</translation>
    </message>
    <message>
        <source>Consig. Min:</source>
        <translation>Consig. Min:</translation>
    </message>
    <message>
        <source>Consig. Max:</source>
        <translation>Consig. Max:</translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source>Zonas
Asociadas</source>
        <translation>Zones
Associades</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Canviar icona</translation>
    </message>
    <message>
        <source>Sensor de temperatura asociado:</source>
        <translation>Sensor de temperatura associat:</translation>
    </message>
    <message>
        <source>Histeresis:</source>
        <translation>Histèresi:</translation>
    </message>
    <message>
        <source>Segundo programa asociado:</source>
        <translation>Segon programa associat:</translation>
    </message>
    <message>
        <source>modo</source>
        <translation>mode</translation>
    </message>
    <message utf8="true">
        <source>0ºC</source>
        <translation>0ºC</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>tots</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>ClimaWindow</name>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
</context>
<context>
    <name>ClimaWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>MANUAL</source>
        <translation>MANUAL</translation>
    </message>
    <message>
        <source>PROGRAMA</source>
        <translation>PROGRAMA</translation>
    </message>
    <message>
        <source>ECO</source>
        <translation>ECO</translation>
    </message>
    <message utf8="true">
        <source>--ºC</source>
        <translation>--ºC</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Baixar</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Pujar</translation>
    </message>
</context>
<context>
    <name>ConfigWindow</name>
    <message utf8="true">
        <source>Vivimat III

versión %1.%2.%3

[%4]</source>
        <translation>Vivimat III

versión %1.%2.%3

[%4]</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión %1.%2.%3
</source>
        <translation>Vision Color 7

versión %1.%2.%3</translation>
    </message>
    <message utf8="true">
        <source>Sistema de ficheros

Versión: %1</source>
        <translation>Sistema de fitxers

Versió: %1</translation>
    </message>
</context>
<context>
    <name>ConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>mando IR</source>
        <translation>comandament IR</translation>
    </message>
    <message>
        <source>programas horarios</source>
        <translation>programes horaris</translation>
    </message>
    <message>
        <source>multimedia</source>
        <translation>multimèdia</translation>
    </message>
    <message utf8="true">
        <source>gestión de energía</source>
        <translation>gestió d&apos;energia</translation>
    </message>
    <message>
        <source>escenas</source>
        <translation>escenes</translation>
    </message>
    <message utf8="true">
        <source>telefonía</source>
        <translation>telefonia</translation>
    </message>
    <message>
        <source>usuarios</source>
        <translation>usuaris</translation>
    </message>
    <message>
        <source>sistema</source>
        <translation>sistema</translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation>seguretat</translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation>videoporter</translation>
    </message>
    <message>
        <source>fecha y hora</source>
        <translation>Data i hora</translation>
    </message>
    <message>
        <source>pantalla</source>
        <translation>pantalla</translation>
    </message>
</context>
<context>
    <name>ConfirmationDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation>Finestra Confirmació</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancel.lar</translation>
    </message>
</context>
<context>
    <name>CurtainControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Cap</translation>
    </message>
    <message>
        <source>Grupo de cortinas</source>
        <translation>Grup de cortines</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estat desconegut</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi el nou nom ...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
</context>
<context>
    <name>CurtainControlClass</name>
    <message>
        <source>CurtainControl</source>
        <translation>Control cortina</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associat:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Mode de funcionament:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Canviar icona</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Temps de pujada / baixada:</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>tots</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>DateHourWindow</name>
    <message>
        <source>Lunes</source>
        <translation>Dilluns</translation>
    </message>
    <message>
        <source>Martes</source>
        <translation>Dimarts</translation>
    </message>
    <message utf8="true">
        <source>Miércoles</source>
        <translation>Dimecres</translation>
    </message>
    <message>
        <source>Jueves</source>
        <translation>Dijous</translation>
    </message>
    <message>
        <source>Viernes</source>
        <translation>Divendres</translation>
    </message>
    <message utf8="true">
        <source>Sábado</source>
        <translation>Dissabte</translation>
    </message>
    <message>
        <source>Domingo</source>
        <translation>Diumenge</translation>
    </message>
</context>
<context>
    <name>DateHourWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>/</source>
        <translation>/</translation>
    </message>
    <message>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
</context>
<context>
    <name>DoorControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Cap</translation>
    </message>
    <message>
        <source>Abierta</source>
        <translation>Oberta</translation>
    </message>
    <message>
        <source>Cerrada</source>
        <translation>Tancada</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estat desconegut</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi nou nom...</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Obrir</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
</context>
<context>
    <name>DoorControlClass</name>
    <message>
        <source>DoorControl</source>
        <translation>Control de porta</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associat:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Mode de funcionament:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Canviar icona</translation>
    </message>
    <message>
        <source>Tiempo de apertura / cierre:</source>
        <translation>Temps d&apos;obertura / tancament:</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>tots</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Obrir</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>DoorphoneDialog</name>
    <message>
        <source>Dialog</source>
        <translation>Diàleg</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancel.lar</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Llamada VIDEOPORTERO</source>
        <translation>Trucada VIDEOPORTER</translation>
    </message>
    <message>
        <source>Llamada desde videoportero</source>
        <translation>Trucada des de videoporter</translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation>Trucada a porteria</translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation>Comunicació amb porteria establerta</translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation>No és possible establir comunicació perquè ja s&apos;ha despenjat des d&apos;un altre terminal.</translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation>Videoporter ocupat</translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation>Parlar</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Obrir</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation>Baixar Vol.</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation>Pujar Vol.</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Baixar</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Pujar</translation>
    </message>
    <message utf8="true">
        <source>Portería</source>
        <translation>Porteria</translation>
    </message>
</context>
<context>
    <name>EntryphoneConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message utf8="true">
        <source>Habilitar Desvío</source>
        <translation>Habilitar Desviament</translation>
    </message>
    <message>
        <source>Habilitar Contestador</source>
        <translation>Habilitar Contestador</translation>
    </message>
    <message utf8="true">
        <source>Contacto al que se desvía la llamada:</source>
        <translation>Contacte al que es desvia la trucada:</translation>
    </message>
    <message>
        <source>Habilitar llamada desde puerta de entrada</source>
        <translation>Habilitar trucada des de porta d&apos;entrada</translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation>Missatges
Personals</translation>
    </message>
    <message utf8="true">
        <source>Número de veces que sonara: </source>
        <translation>Nombre de vegades que sonarà: </translation>
    </message>
</context>
<context>
    <name>FileTransfer</name>
    <message>
        <source>Aplicacion DEMO para Windows.Simulando la transferencia de ficheros.</source>
        <translation>Aplicació DEMO per Windows. Simulant la transferència de fitxers.</translation>
    </message>
    <message>
        <source>Se ha encontrado una tarjeta SD.No saque la tarjeta hasta que finalice el intercambio de ficheros.</source>
        <translation>S&apos;ha trobat una targeta Sd.No tregui la targeta fins que finalitzi l&apos;intercanvi de fitxers.</translation>
    </message>
    <message>
        <source>Se ha encontrado un dispositivo USB.No saque el dispositivo hasta que finalice el intercambio de ficheros.</source>
        <translation>S&apos;ha trobat un dispositiu Usb.No tregui el dispositiu fins que finalitzi l&apos;intercanvi de fitxers.</translation>
    </message>
    <message utf8="true">
        <source>No se ha encontrado ningún dispositivo.Pulsa cancelar para salir.</source>
        <translation>No s&apos;ha trobat cap dispositiu.Prem cancel·lar per sortir.</translation>
    </message>
    <message utf8="true">
        <source>La actualización ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation>L&apos;actualització ha finalizado.Es necessari reiniciar el sistema.</translation>
    </message>
    <message utf8="true">
        <source>La exportación ha finalizado.Pulsa Aceptar para continuar.</source>
        <translation>L&apos;exportació ha finalitzat.Prem Acceptar per continuar.</translation>
    </message>
    <message utf8="true">
        <source>La importación ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation>La importació ha finalizado.Es necessari reiniciar el sistema.</translation>
    </message>
    <message>
        <source>No existe un fichero de firmware. Inserte un dispositivo con un fichero de firmware.</source>
        <translation>No existeix un fitxer de firmware. Insereixi un dispositiu amb un fitxer de firmware.</translation>
    </message>
    <message>
        <source>Error a la hora de copiar el nuevo firmware.</source>
        <translation>Error a l&apos;hora de copiar el nou firmware.</translation>
    </message>
    <message utf8="true">
        <source>La copia del programa de calibración ha fallado.</source>
        <translation>La còpia del programa de calibratge ha fallat.</translation>
    </message>
    <message utf8="true">
        <source>No se encuentran todos los ficheros necesarios para la actualizacion del servidor web.
No se ha podido realizar la actualización.</source>
        <translation>No es troben tots els fitxers necessaris per la *actualizacion del servidor web.
No s&apos;ha pogut realitzar l&apos;actualització.</translation>
    </message>
    <message utf8="true">
        <source>La actualización ha fallado. Se mantiene el viejo rcS.</source>
        <translation>L&apos;actualització ha fallat. Es manté el vell rcS.</translation>
    </message>
</context>
<context>
    <name>FileTransferClass</name>
    <message>
        <source>FileTransfer</source>
        <translation>Transferència fitxers</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancel.lar</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>FloorSelectClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Baixar</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Pujar</translation>
    </message>
</context>
<context>
    <name>HistoryWindow</name>
    <message>
        <source>Historial de Eventos</source>
        <translation>Historial d&apos;Esdeveniments</translation>
    </message>
    <message>
        <source>Historial de Errores</source>
        <translation>Historial d&apos;Errors</translation>
    </message>
</context>
<context>
    <name>HistoryWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Historial de Eventos</source>
        <translation>Historial d&apos;Esdeveniments</translation>
    </message>
    <message>
        <source>01/01/2010 13:39:05 &gt; System initialization completed
01/01/2010 13:45:15 &gt; Intrusion alarm armed in total mode: Sergio
01/01/2010 13:50:05 &gt; Intrusion alarm disarmed: Sergio
</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
</context>
<context>
    <name>IRCodeReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>Prova Stacked</translation>
    </message>
    <message>
        <source>Apunte el mando hacia el
receptor y pulse la tecla
correspondiente...</source>
        <translation>Apunta el mando cap al
receptor i prem la tecla
corresponent...</translation>
    </message>
    <message utf8="true">
        <source>Leer código de infrarrojos</source>
        <translation>Llegir codi d&apos;infrarojos</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindow</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation>Executar Escena</translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation>Arm. Intrusió Mode Perimetral</translation>
    </message>
    <message utf8="true">
        <source>Activar pánico</source>
        <translation>Activar Pànic</translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation>Obrir videoporter</translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation>Encendre llum</translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation>Apagar llum</translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation>Pujar llum</translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation>Baixar llum</translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation>Pujar dis. motoritzat</translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation>Baixar dis. motoritzat</translation>
    </message>
    <message>
        <source>Encender clima</source>
        <translation>Encendre clima</translation>
    </message>
    <message>
        <source>Apagar clima</source>
        <translation>Apagar clima</translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation>Encendre endoll</translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation>Apagar endoll</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Acció</translation>
    </message>
    <message utf8="true">
        <source>Código IR</source>
        <translation>Codi IR</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi nou nom...</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la acción.
¿Está seguro?</source>
        <translation>Es va a eliminar l&apos;acció.
¿Està segur?</translation>
    </message>
    <message utf8="true">
        <source>Eliminar acción...</source>
        <translation>Eliminar acció...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Falten dades per omplir.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <source> - ON/OFF -</source>
        <translation> - ON/OFF -</translation>
    </message>
    <message>
        <source> - Regulable -</source>
        <translation>Regulable</translation>
    </message>
    <message>
        <source> - RGB -</source>
        <translation> - RGB -</translation>
    </message>
    <message>
        <source> - Todos los tipos -</source>
        <translation>- Tots els tipus -</translation>
    </message>
    <message>
        <source> Individual - </source>
        <translation>Individual - </translation>
    </message>
    <message>
        <source> Zona - </source>
        <translation>Zona - </translation>
    </message>
    <message>
        <source> Todas las luces</source>
        <translation>Totes les llums</translation>
    </message>
    <message>
        <source> - Individual - </source>
        <translation> - Individual - </translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation> - Tots els climatitzadors</translation>
    </message>
    <message>
        <source> - Zona - </source>
        <translation> - Zona - </translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation> - Tots els endolls</translation>
    </message>
    <message>
        <source> - Persiana normal -</source>
        <translation>- Persiana normal -</translation>
    </message>
    <message>
        <source> - Persiana posicional -</source>
        <translation>- Persiana posicional -</translation>
    </message>
    <message>
        <source> - Persianas agupadas -</source>
        <translation>- Persiana agrupades -</translation>
    </message>
    <message>
        <source> - Cualquier persiana -</source>
        <translation>- Qualsevol persiana -</translation>
    </message>
    <message>
        <source> - Toldo normal -</source>
        <translation>- Tendal normal -</translation>
    </message>
    <message>
        <source> - Toldo posicional -</source>
        <translation>- Tendal posicional -</translation>
    </message>
    <message>
        <source> - Toldos agupados -</source>
        <translation>- Tendals agrupats -</translation>
    </message>
    <message>
        <source> - Cualquier toldo -</source>
        <translation>- Qualsevol Tendal -</translation>
    </message>
    <message>
        <source> - Cortina normal -</source>
        <translation>- Cortina normal -</translation>
    </message>
    <message>
        <source> - Cortina posicional -</source>
        <translation>- Cortina posicional -</translation>
    </message>
    <message>
        <source> - Cortinas agupadas -</source>
        <translation>- Cortines agrupades -</translation>
    </message>
    <message>
        <source> - Cualquier cortina -</source>
        <translation> - Qualsevol cortina -</translation>
    </message>
    <message>
        <source> - Puerta motorizada -</source>
        <translation> - Porta motoritzada -</translation>
    </message>
    <message>
        <source> Todos</source>
        <translation>Tots</translation>
    </message>
    <message utf8="true">
        <source>Conmutar cámara</source>
        <translation>Commutar càmera</translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Acció</translation>
    </message>
    <message utf8="true">
        <source>Código</source>
        <translation>Codi</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialog</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation>Executar Escena</translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation>Arm. Intrusió Mode Perimetral</translation>
    </message>
    <message utf8="true">
        <source>Activar pánico</source>
        <translation>Activar Pànic</translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation>Obrir videoporter</translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation>Encendre llum</translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation>Apagar llum</translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation>Pujar llum</translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation>Baixar llum</translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation>Pujar dis. motoritzat</translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation>Baixar dis. motoritzat</translation>
    </message>
    <message>
        <source>Encender Clima</source>
        <translation>Encendre clima</translation>
    </message>
    <message>
        <source>Apagar Clima</source>
        <translation>Apagar clima</translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation>Encendre endoll</translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation>Apagar endoll</translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation>Llum ON/OFF</translation>
    </message>
    <message>
        <source>Luz regulable</source>
        <translation>Llum regulable</translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation>Tots els tipus</translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation>Llum individual</translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation>Llums de la zona</translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation>Totes les llums</translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation>Climatitzador individual</translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation>Tots els climatitzadors</translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation>Endoll individual</translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation>Endolls de la zona</translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation>Tots els endolls</translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation>Persiana normal</translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation>Persiana posicional</translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation>Persiana agrupades</translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation>Qualsevol persiana</translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation>Tendal normal</translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation>Tendal posicional</translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation>Tendals agrupats</translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation>Qualsevol Tendal</translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation>Cortina normal</translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation>Cortina posicional</translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation>Cortines agrupades</translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation> Qualsevol cortina</translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation>Porta motoritzada</translation>
    </message>
    <message>
        <source>Dispositivo individual</source>
        <translation>Dispositiu individual</translation>
    </message>
    <message>
        <source>Dispositivos de la zona</source>
        <translation>Dispositius de la zona</translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation>Tots els dispositius</translation>
    </message>
    <message>
        <source>Conmutar camara</source>
        <translation>Commutar càmera</translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>ProvaStaked</translation>
    </message>
    <message utf8="true">
        <source>Cambiar acción asociada a la tecla</source>
        <translation>Canviar acció associada a la tecla</translation>
    </message>
    <message utf8="true">
        <source>Acción:</source>
        <translation>Acció:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation>Tipus d&apos;element:</translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation>Tipus de control:</translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation>Element:</translation>
    </message>
</context>
<context>
    <name>IconChangeDialogClass</name>
    <message>
        <source>IconChangeDialog</source>
        <translation>Canvi d&apos;icona</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Canviar icona</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
</context>
<context>
    <name>IrrigatorControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Cap</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>En espera</source>
        <translation>En espera</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estat desconegut</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi nou nom...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
</context>
<context>
    <name>IrrigatorControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>ProvaStacked</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Mode de funcionament:</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associat:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renombrar</translation>
    </message>
    <message utf8="true">
        <source>Detener riego en caso de lluvia o suelo ya húmedo</source>
        <translation>Detenir reg en cas de pluja o sòl ja humit</translation>
    </message>
    <message>
        <source>Sensor de humedad asociado:</source>
        <translation>Sensor d&apos;humitat associat:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Canviar icona</translation>
    </message>
    <message>
        <source>Duracion del riego (minutos):</source>
        <translation>Durada del reg (minuts):</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>tots</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>KeyReadDialog</name>
    <message utf8="true">
        <source>- Código: </source>
        <translation>- Codi: </translation>
    </message>
    <message>
        <source>
- Tipo: </source>
        <translation>
- Tipus: </translation>
    </message>
    <message>
        <source>
- Asignada a: </source>
        <translation>
- Assignada a: </translation>
    </message>
    <message utf8="true">
        <source>Llave desconocida.
- Código: </source>
        <translation>Claus desconeguda.
- Codi: </translation>
    </message>
</context>
<context>
    <name>KeyReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>Prova Stacked</translation>
    </message>
    <message utf8="true">
        <source>Acerque la llave
para ser leída</source>
        <translation>Apropi la clau
per ser llegida</translation>
    </message>
    <message>
        <source>Leer llave</source>
        <translation>Llegir clau</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
</context>
<context>
    <name>KeyRecordDialog</name>
    <message utf8="true">
        <source>El usuario tiene
asociada la llave
con código: </source>
        <translation>L&apos;usuari té
associada la clau
amb codi: </translation>
    </message>
    <message utf8="true">
        <source>No hay espacio
para grabar más llaves</source>
        <translation>No hi ha espai
per gravar més claus</translation>
    </message>
    <message>
        <source>Acerque la llave
para ser grabada</source>
        <translation>Apropi la clau
per ser gravada</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder
a borrar la llave.
¿Está seguro?</source>
        <translation>Es va a procedir
a esborrar la clau.
Està segur?</translation>
    </message>
    <message>
        <source>La llave ya ha
sido grabada antes.</source>
        <translation>La clau ja ha
estat gravada abans.</translation>
    </message>
    <message utf8="true">
        <source>Llave leída.
- Código: </source>
        <translation>Clau llegida.
- Codi:</translation>
    </message>
</context>
<context>
    <name>KeyRecordDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>Prova Stacked</translation>
    </message>
    <message>
        <source>El usuario no tiene
llave asociada</source>
        <translation>L&apos;usuari no té
clau associada</translation>
    </message>
    <message>
        <source>Grabar llave</source>
        <translation>Gravar clau</translation>
    </message>
    <message>
        <source>Tipo de llave:</source>
        <translation>Tipus de clau:</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation>&gt;&gt;</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation>&lt;&lt;</translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>Grabar
llave</source>
        <translation>Gravar clau</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Borrar
llave</source>
        <translation>Esborrar
clau</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
</context>
<context>
    <name>KeyboardClass</name>
    <message>
        <source>Keyboad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&gt;&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bloq May</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Ñ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>J</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ó</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>é</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ş</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ö</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Ó</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>,</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>É</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ü</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>á</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>@</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ú</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Í</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Ç</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Ú</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ǧ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Á</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>*</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ç</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>í</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>f</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>j</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>v</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>i</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ñ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>r</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>g</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>w</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>u</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>e</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ف</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ى</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ح</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ه</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ا</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ع</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>خ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ي</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>م</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ة</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ض</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ب</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ص</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ت</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ث</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>و</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ش</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ق</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>لا</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ؤ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>س</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ن</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>غ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ك</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ل</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ر</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ئ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ء</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ظ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ز</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>د</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ج</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ط</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٨</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٤</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٣</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٧</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ذ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>١</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٢</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٩</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٦</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٥</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LightControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Cap</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estat desconegut</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi nou nom...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
    <message>
        <source>Presencia</source>
        <translation>Presència</translation>
    </message>
    <message>
        <source>Crepuscular</source>
        <translation>Crepuscular</translation>
    </message>
    <message>
        <source>Crep + Pres</source>
        <translation>Crep + Pres</translation>
    </message>
    <message>
        <source>Pres + Prog</source>
        <translation>Pres + Prog</translation>
    </message>
</context>
<context>
    <name>LightControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>Prova Stacked</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associat:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <source>Consigna en modo presencia:</source>
        <translation>Consigna en mode presencia:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Mode de funcionament:</translation>
    </message>
    <message>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <source>Sensor de presencia asociado:</source>
        <translation>Sensor de presència associat:</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la desactivación:</source>
        <translation>Retard a la desactivació:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Canviar icona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>tots</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message utf8="true">
        <source>Cerrar sesión</source>
        <translation>Tancar sessió</translation>
    </message>
    <message>
        <source>inicio</source>
        <translation>inici</translation>
    </message>
    <message>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation>videoporter</translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation>seguretat</translation>
    </message>
    <message>
        <source>escenas</source>
        <translation>escenes</translation>
    </message>
    <message>
        <source>mensajes</source>
        <translation>missatges</translation>
    </message>
    <message>
        <source>configurar</source>
        <translation>configurar</translation>
    </message>
    <message>
        <source>clima</source>
        <translation>clima</translation>
    </message>
    <message utf8="true">
        <source>cámaras</source>
        <translation>càmeres</translation>
    </message>
    <message>
        <source>programas</source>
        <translation>programes</translation>
    </message>
    <message>
        <source>alarmas</source>
        <translation>alarmes</translation>
    </message>
    <message>
        <source>historial</source>
        <translation>historial</translation>
    </message>
    <message>
        <source>fotos</source>
        <translation>fotos</translation>
    </message>
    <message>
        <source>pizarra</source>
        <translation>pissarra</translation>
    </message>
    <message>
        <source>sos</source>
        <translation>sos</translation>
    </message>
    <message utf8="true">
        <source>No es posible visualizar las cámaras porque ya están siendo visualizadas en otro terminal.</source>
        <translation>No és possible visualitzar les càmeres perquè ja estan sent visualitzades en un altre terminal.</translation>
    </message>
    <message utf8="true">
        <source>Cámaras ocupadas</source>
        <translation>Càmeres ocupades</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar</source>
        <translation>Introdueixi contrasenya per desarmar alarme</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para menú de seguridad</source>
        <translation>Introdueixi contrasenya per a menú de seguretat</translation>
    </message>
    <message>
        <source>Sistema bloqueado</source>
        <translation>Sistema bloquejat</translation>
    </message>
    <message>
        <source>Antes de poder usar los mensajes de voz es necesario tener grabados los mensajes personales.</source>
        <translation>Abans de poder usar els missatges de veu és necessari tenir gravats els missatges personals.</translation>
    </message>
    <message>
        <source>Mensajes personales sin grabar</source>
        <translation>Missatges personals sense gravar</translation>
    </message>
    <message>
        <source>LUN </source>
        <translation>DIL </translation>
    </message>
    <message>
        <source>MAR </source>
        <translation>DIM </translation>
    </message>
    <message>
        <source>MIE </source>
        <translation>DIX </translation>
    </message>
    <message>
        <source>JUE </source>
        <translation>DIJ </translation>
    </message>
    <message>
        <source>VIE </source>
        <translation>DIV </translation>
    </message>
    <message>
        <source>SAB </source>
        <translation>DIS </translation>
    </message>
    <message>
        <source>DOM </source>
        <translation>DIU </translation>
    </message>
    <message>
        <source>dd/MM/yyyy</source>
        <translation>dd/MM/yyyy</translation>
    </message>
    <message utf8="true">
        <source>INT %1 ºC</source>
        <translation>INT %1 ºC</translation>
    </message>
    <message utf8="true">
        <source>Los ficheros de configuración no coinciden.
Para sobreescribir los ficheros de la central en la pantalla pulsa Aceptar. En caso contrario, pulsa Cancelar.</source>
        <translation>Els fitxers de configuració no coincideixen.
Per sobreescriure els fitxers de la central en la pantalla prem Acceptar. En cas contrari, prem Cancel·lar.</translation>
    </message>
    <message utf8="true">
        <source>Actualizar configuración</source>
        <translation>Actualitzar configuració</translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código IR:
%1 %2 %3</source>
        <translation>S&apos;ha llegit el codi IR:
%1 %2 %3</translation>
    </message>
    <message utf8="true">
        <source>Código IR leído</source>
        <translation>Codi IR llegit</translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código RFID:
%1 %2 %3 %4</source>
        <translation>S&apos;ha llegit el codi RFID:
%1 %2 %3 %4</translation>
    </message>
    <message utf8="true">
        <source>Llave leída</source>
        <translation>Clau llegida</translation>
    </message>
    <message utf8="true">
        <source>El idioma del sistema ha sido modificado.
¿Desea reiniciar la pantalla?</source>
        <translation>L&apos;idioma del sistema ha estat modificat.
Desitja reiniciar la pantalla?</translation>
    </message>
    <message>
        <source>Actualizar idioma...</source>
        <translation>Actualitzar idioma...</translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 90 segundos.</source>
        <translation>Sistema bloquejat després de tres intents d&apos;introducció de clau fallits.
Per tornar a introduir el password esperi 90 segons.</translation>
    </message>
</context>
<context>
    <name>MainWindowClass</name>
    <message>
        <source>MainWindow</source>
        <translation>Finestra Principal</translation>
    </message>
    <message>
        <source>12:30</source>
        <translation>12:30</translation>
    </message>
    <message>
        <source>MAR 15/11/2009</source>
        <translation>DIM 15/11/2009</translation>
    </message>
    <message utf8="true">
        <source>INT 18ºC</source>
        <translation>INT 18ºC</translation>
    </message>
    <message>
        <source>LL</source>
        <translation>LL</translation>
    </message>
</context>
<context>
    <name>MessageDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation>Finestra Confirmació</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
</context>
<context>
    <name>MessagesWindow</name>
    <message>
        <source>Tipo</source>
        <translation>Tipus</translation>
    </message>
    <message>
        <source>Origen</source>
        <translation>Origen</translation>
    </message>
    <message>
        <source>Fecha/Hora</source>
        <translation>Data/Hora</translation>
    </message>
    <message>
        <source>Videoportero</source>
        <translation>videoporter</translation>
    </message>
    <message>
        <source>Terminal 1</source>
        <translation>Terminal 1</translation>
    </message>
    <message>
        <source>Terminal 2</source>
        <translation>Terminal 2</translation>
    </message>
    <message>
        <source>Terminal 3</source>
        <translation>Terminal 3</translation>
    </message>
    <message>
        <source>Desconocido</source>
        <translation>Desconegut</translation>
    </message>
    <message>
        <source>Voz</source>
        <translation>Veu</translation>
    </message>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>No és possible gravar el missatge, els missatges de veu ja estan sent usats.</translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation>Missatges de veu en ús</translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation>Gravant missatge...</translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>No és possible reproduir el missatge, els missatges de veu ja estan sent usats.</translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation>Reproduint missatge...</translation>
    </message>
    <message utf8="true">
        <source>No es posible borrar los mensajes, los mensajes de voz ya están siendo usados.</source>
        <translation>No és possible esborrar els missatges, els missatges de veu ja estan sent usats.</translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation>Es van a eliminar tots els missatges.
Està segur?</translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation>Eliminar missatges...</translation>
    </message>
</context>
<context>
    <name>MessagesWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Grabar
mensaje</source>
        <translation>Gravar
missatge</translation>
    </message>
    <message>
        <source>Borrar
mensajes</source>
        <translation>Borrar
missatge</translation>
    </message>
</context>
<context>
    <name>MsgProgressDialogClass</name>
    <message>
        <source>RecWindow</source>
        <translation>RecWindow</translation>
    </message>
    <message>
        <source>Parar</source>
        <translation>Parar</translation>
    </message>
</context>
<context>
    <name>PasswordClass</name>
    <message>
        <source>Password</source>
        <translation>Contrasenya</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para continuar...</source>
        <translation>Introdueixi contrasenya per continuar...</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialog</name>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>No és possible gravar el missatge, els missatges de veu ja estan sent usats.</translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation>Missatges de veu en ús</translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation>Es van a eliminar tots els missatges.
Està segur?</translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation>Eliminar missatges...</translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation>Gravant missatge...</translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>No és possible reproduir el missatge, els missatges de veu ja estan sent usats.</translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation>Reproduint missatge...</translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation>Finestra Confirmació</translation>
    </message>
    <message>
        <source>Mensajes de voz personalizados</source>
        <translation>Missatges de veu personalitzats</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Acceptar</translation>
    </message>
    <message>
        <source>Mensaje para llamadas de alarma</source>
        <translation>Missatge per a trucades d&apos;alarma</translation>
    </message>
    <message>
        <source>Reproducir</source>
        <translation>Reproduir</translation>
    </message>
    <message>
        <source>Grabar</source>
        <translation>Gravar</translation>
    </message>
    <message>
        <source>Mensaje para contestador de videoportero</source>
        <translation>Missatge per a contestador de videoporter</translation>
    </message>
    <message utf8="true">
        <source>Para grabar los mensajes de voz personalizados primero se borraran todos los mensajes, después se grabará el mensaje para llamadas de alarma y a continuación el mensaje para contestador de videoportero.</source>
        <translation>Per gravar els missatges de veu personalitzats primer s&apos;esborraran tots els missatges, després es gravarà el missatge per a trucades d&apos;alarma i a continuació el missatge per a contestador de videoporter.</translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindow</name>
    <message>
        <source>Tipo</source>
        <translation>Tipus</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message utf8="true">
        <source>Número</source>
        <translation>Número</translation>
    </message>
    <message>
        <source>TEL</source>
        <translation>TEL</translation>
    </message>
    <message>
        <source>SMS</source>
        <translation>SMS</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>CRA</source>
        <translation>CRA</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi nou nom...</translation>
    </message>
    <message>
        <source>Es necesario introducir primero el tipo de contacto.</source>
        <translation>És necessari introduir primer el tipus de contacte.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message utf8="true">
        <source>Introduzca nuevo número o dirección de correo ...</source>
        <translation>Introdueixi nou nombre o adreça de correu ...</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el contacto.
¿Está seguro?</source>
        <translation>Es va a eliminar el contacte.
Està segur?</translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation>Eliminar contacte...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Falten dades per omplir.</translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindowClass</name>
    <message>
        <source>PhoneConfigWindow</source>
        <translation>finestra configuració Telèfon</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Habilitar avisos</source>
        <translation>Habilitar avisos</translation>
    </message>
    <message>
        <source>Habilitar telecontrol</source>
        <translation>Habilitar telecontrol</translation>
    </message>
    <message>
        <source>Tonos</source>
        <translation>Tons</translation>
    </message>
    <message>
        <source>Configurar
CRA</source>
        <translation>Configurar
CRA</translation>
    </message>
</context>
<context>
    <name>PhotosWindow</name>
    <message>
        <source>Marco de fotos</source>
        <translation>Marc de fotos</translation>
    </message>
    <message>
        <source>No hay fotos disponibles.</source>
        <translation>No hi ha fotos disponibles.</translation>
    </message>
</context>
<context>
    <name>PlugControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Cap</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estat desconegut</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi nou nom...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
</context>
<context>
    <name>PlugControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>Prova Stacked</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Mode de funcionament:</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associat:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Canviar icona</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>tots</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>salida temporizada </source>
        <translation>sortida temporitzada</translation>
    </message>
    <message>
        <source>segundos</source>
        <translation>segons</translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindow</name>
    <message>
        <source>Temperatura</source>
        <translation>Temperatura</translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation>0-100%</translation>
    </message>
    <message>
        <source>ON-OFF</source>
        <translation>ON-OFF</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi nou nom...</translation>
    </message>
    <message utf8="true">
        <source>Las franjas horarias no están bien definidas.</source>
        <translation>Les franges horàries no estan ben definides.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <source>0 = OFF</source>
        <translation>0 = OFF</translation>
    </message>
    <message>
        <source>1 = ON</source>
        <translation>1 = ON</translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Tipus</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message utf8="true">
        <source>Días de ejecución:</source>
        <translation>Dies d&apos;execució:</translation>
    </message>
    <message>
        <source>L</source>
        <translation>DL</translation>
    </message>
    <message>
        <source>M</source>
        <translation>DM</translation>
    </message>
    <message>
        <source>X</source>
        <translation>DX</translation>
    </message>
    <message>
        <source>J</source>
        <translation>DJ</translation>
    </message>
    <message>
        <source>V</source>
        <translation>DV</translation>
    </message>
    <message>
        <source>S</source>
        <translation>DS</translation>
    </message>
    <message>
        <source>D</source>
        <translation>DG</translation>
    </message>
    <message>
        <source>Fin</source>
        <translation>Fi</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:mm</translation>
    </message>
    <message>
        <source>Inicio</source>
        <translation>Inici</translation>
    </message>
    <message>
        <source>Consigna</source>
        <translation>Consigna</translation>
    </message>
    <message>
        <source>Franja 1:</source>
        <translation>Franja 1:</translation>
    </message>
    <message>
        <source>Franja 2:</source>
        <translation>Franja 2:</translation>
    </message>
    <message>
        <source>Franja 3:</source>
        <translation>Franja 3:</translation>
    </message>
    <message>
        <source>Franja 4:</source>
        <translation>Franja 4:</translation>
    </message>
    <message>
        <source>Franja 5:</source>
        <translation>Franja 5:</translation>
    </message>
</context>
<context>
    <name>ProgramsWindow</name>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Tipus</translation>
    </message>
    <message>
        <source>L</source>
        <translation>DL</translation>
    </message>
    <message>
        <source>M</source>
        <translation>DM</translation>
    </message>
    <message>
        <source>X</source>
        <translation>DX</translation>
    </message>
    <message>
        <source>J</source>
        <translation>DJ</translation>
    </message>
    <message>
        <source>V</source>
        <translation>DV</translation>
    </message>
    <message>
        <source>S</source>
        <translation>DS</translation>
    </message>
    <message>
        <source>D</source>
        <translation>DG</translation>
    </message>
    <message>
        <source>Temperatura</source>
        <translation>Temperatura</translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation>0-100%</translation>
    </message>
    <message>
        <source>ON/OFF</source>
        <translation>ON-OFF</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el programa.
¿Está seguro?</source>
        <translation>Es va a eliminar el programa.
Està segur?</translation>
    </message>
    <message>
        <source>Eliminar programa...</source>
        <translation>Eliminar programa...</translation>
    </message>
</context>
<context>
    <name>ProgramsWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Tipus</translation>
    </message>
    <message>
        <source>L</source>
        <translation>DL</translation>
    </message>
    <message>
        <source>M</source>
        <translation>DM</translation>
    </message>
    <message>
        <source>X</source>
        <translation>DX</translation>
    </message>
    <message>
        <source>J</source>
        <translation>DJ</translation>
    </message>
    <message>
        <source>V</source>
        <translation>DV</translation>
    </message>
    <message>
        <source>S</source>
        <translation>DS</translation>
    </message>
    <message>
        <source>D</source>
        <translation>DG</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
</context>
<context>
    <name>RBlindControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Cap</translation>
    </message>
    <message>
        <source>Grupo de toldos</source>
        <translation>Grup de tendals</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estat desconegut</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi nou nom...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
</context>
<context>
    <name>RBlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>Prova Stacked</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associat:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <source>Plegar toldos en caso de viento fuerte</source>
        <translation>Plegar tendals en cas de vent fort</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Temps de pujada / baixada:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Mode de funcionament:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Canviar icona</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>tots</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Plegar toldos en caso de lluvia</source>
        <translation>Plegar tendals en cas de pluja</translation>
    </message>
</context>
<context>
    <name>SOSWindow</name>
    <message utf8="true">
        <source>Alarma de pánico deshabilitada</source>
        <translation>Alarma de pànic deshabilitada</translation>
    </message>
</context>
<context>
    <name>SOSWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>SOS</source>
        <translation>SOS</translation>
    </message>
</context>
<context>
    <name>SceneConditionDialog</name>
    <message>
        <source>Sin condicionar</source>
        <translation>Sense condicionar</translation>
    </message>
    <message>
        <source>Cualquier llave</source>
        <translation>Qualsevol clau</translation>
    </message>
    <message>
        <source>Llave tipo A</source>
        <translation>Clau tipus A</translation>
    </message>
    <message>
        <source>Llave tipo B</source>
        <translation>Clau tipus B</translation>
    </message>
    <message>
        <source>Llave tipo C</source>
        <translation>Clau tipus C</translation>
    </message>
    <message>
        <source>Llave tipo D</source>
        <translation>Clau tipus D</translation>
    </message>
    <message>
        <source>Llave tipo E</source>
        <translation>Clau tipus E</translation>
    </message>
    <message>
        <source>Llave tipo F</source>
        <translation>Clau tipus F</translation>
    </message>
    <message>
        <source>Llave: </source>
        <translation>Clau:</translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation>Data</translation>
    </message>
    <message utf8="true">
        <source>Día semana</source>
        <translation>Dia setmana</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión armada</source>
        <translation>Alarma d&apos;intrusió armada</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión desarmada</source>
        <translation>Alarma d&apos;intrusió desarmada</translation>
    </message>
    <message utf8="true">
        <source>Activación de cualquier alarma</source>
        <translation>Activació de qualsevol alarma</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de intrusión</source>
        <translation>Act. alm. d&apos;intrusió</translation>
    </message>
    <message>
        <source>Act. alm. de fuego</source>
        <translation>Act. alm. de foc</translation>
    </message>
    <message>
        <source>Act. alm. de gas</source>
        <translation>Act. alm. de gas</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de inundación</source>
        <translation>Act. alm. d&apos;inundació</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de corte eléc.</source>
        <translation>Act. alm. de tall eléc.</translation>
    </message>
    <message>
        <source>Act. alm. de corte tlf.</source>
        <translation>Act. alm. de tall tlf.</translation>
    </message>
    <message>
        <source>Act. alm. de sistema</source>
        <translation>Act. alm. de sistema</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. médica</source>
        <translation>Act. alm. médica</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de pánico</source>
        <translation>Act. alm. de pànic</translation>
    </message>
    <message>
        <source>Act. alm. silenciosa</source>
        <translation>Act. alm. silenciosa</translation>
    </message>
    <message>
        <source>Act. alm. de sabotaje</source>
        <translation>Act. alm. de sabotaje</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de coacción</source>
        <translation>Act. alm. de coacció</translation>
    </message>
    <message>
        <source>Entrada en Central</source>
        <translation>Entrada a Central</translation>
    </message>
    <message>
        <source>Entrada en MOD0035</source>
        <translation>Entrada a MOD0035</translation>
    </message>
</context>
<context>
    <name>SceneConditionDialogClass</name>
    <message>
        <source>EventConditionWindow</source>
        <translation>finestra Condició Event</translation>
    </message>
    <message>
        <source>Condiciones</source>
        <translation>Condicions</translation>
    </message>
    <message>
        <source>Condicion de llave:</source>
        <translation>Condicions de clau:</translation>
    </message>
    <message>
        <source>Condicion de hora:</source>
        <translation>Condicions d&apos;hora:</translation>
    </message>
    <message>
        <source>Condicion de Fecha / Dia semana:</source>
        <translation>Condicions de Data / Dia setmana:</translation>
    </message>
    <message>
        <source>Condicion de alarma:</source>
        <translation>Condicions d&apos;alarma:</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:mm</translation>
    </message>
    <message>
        <source>L</source>
        <translation>DL</translation>
    </message>
    <message>
        <source>V</source>
        <translation>DV</translation>
    </message>
    <message>
        <source>X</source>
        <translation>DX</translation>
    </message>
    <message>
        <source>D</source>
        <translation>DG</translation>
    </message>
    <message>
        <source>M</source>
        <translation>DM</translation>
    </message>
    <message>
        <source>J</source>
        <translation>DJ</translation>
    </message>
    <message>
        <source>S</source>
        <translation>DS</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Condicion de entrada:</source>
        <translation>Condicions d&apos;entrada:</translation>
    </message>
    <message>
        <source>Tipo de modulo:</source>
        <translation>Tipus de mòdul:</translation>
    </message>
    <message>
        <source>E/S:</source>
        <translation>E/S:</translation>
    </message>
    <message>
        <source>Mod:</source>
        <translation>Mod:</translation>
    </message>
</context>
<context>
    <name>SceneEventWindow</name>
    <message utf8="true">
        <source>Iluminación</source>
        <translation>Il·luminació</translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation>Dis. motoritzat</translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation>Endoll</translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation>Climatització</translation>
    </message>
    <message>
        <source>Riego</source>
        <translation>Rec</translation>
    </message>
    <message>
        <source>Retardo</source>
        <translation>Retard</translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation>Seguretat</translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation>Llum individual</translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation>Llums de la zona</translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation>Totes les llums</translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation>Llum ON/OFF</translation>
    </message>
    <message>
        <source>Luz Regulable</source>
        <translation>Llum regulable</translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation>Tots els tipus</translation>
    </message>
    <message>
        <source>0%</source>
        <translation>0%</translation>
    </message>
    <message>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <source>20%</source>
        <translation>20%</translation>
    </message>
    <message>
        <source>40%</source>
        <translation>40%</translation>
    </message>
    <message>
        <source>60%</source>
        <translation>60%</translation>
    </message>
    <message>
        <source>80%</source>
        <translation>80%</translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation>Endoll individual</translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation>Endolls de la zona</translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation>Tots els endolls</translation>
    </message>
    <message>
        <source>Encender</source>
        <translation>Encendre</translation>
    </message>
    <message>
        <source>Apagar</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation>Climatitzador individual</translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation>Tots els climatitzadors</translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation>Apagat</translation>
    </message>
    <message>
        <source>Modo manual</source>
        <translation>Mode manual</translation>
    </message>
    <message>
        <source>Modo programa</source>
        <translation>Mode programa</translation>
    </message>
    <message utf8="true">
        <source>Modo económico</source>
        <translation>Mode econòmic</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>Riego individual</source>
        <translation>Rec individual</translation>
    </message>
    <message>
        <source>Riegos de la zona</source>
        <translation>Rec de les zones</translation>
    </message>
    <message>
        <source>Todos los riegos</source>
        <translation>Tots els recs</translation>
    </message>
    <message>
        <source>Activar</source>
        <translation>Activar</translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation>Desactivar</translation>
    </message>
    <message>
        <source>1 seg</source>
        <translation>1 seg</translation>
    </message>
    <message>
        <source>3 seg</source>
        <translation>3 seg</translation>
    </message>
    <message>
        <source>5 seg</source>
        <translation>5 seg</translation>
    </message>
    <message>
        <source>10 seg</source>
        <translation>10 seg</translation>
    </message>
    <message>
        <source>20 seg</source>
        <translation>20 seg</translation>
    </message>
    <message>
        <source>30 seg</source>
        <translation>3 seg</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation>Alarma d&apos;intrusió</translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation>Alarma de foc</translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation>Alarma de gas</translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation>Alarma d&apos;inundació</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation>Alarma de tall elèctric</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte telefónico</source>
        <translation>Alarma de tall telefònic</translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation>Alarma de sistema</translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation>Alarma mèdica</translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation>Alarma de pànic</translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation>Alarma silenciosa</translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation>Alarma de sabotatge</translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation>Armar en mode perimetral</translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation>Armar en mode parcial</translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation>Armar en mode total</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Desarmar</translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation>Desarmar parcialment</translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation>Activar alarma</translation>
    </message>
    <message>
        <source>Dis. individual</source>
        <translation>Dis. individual</translation>
    </message>
    <message>
        <source>Dis. de la zona</source>
        <translation>Dis. de la zona</translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation>Tots els dispositius</translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation>Persiana normal</translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation>Persiana posicional</translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation>Persiana agrupades</translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation>Qualsevol persiana</translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation>Tendal normal</translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation>Tendal posicional</translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation>Tendals agrupats</translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation>Qualsevol Tendal</translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation>Cortina normal</translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation>Cortina posicional</translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation>Cortines agrupades</translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation> Qualsevol cortina</translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation>Porta motoritzada</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Obrir</translation>
    </message>
</context>
<context>
    <name>SceneEventWindowClass</name>
    <message>
        <source>SceneEventWindow</source>
        <translation>finestra configuració Escenes</translation>
    </message>
    <message>
        <source>Modificar evento</source>
        <translation>Modificar esdeveniment</translation>
    </message>
    <message>
        <source>Tipo de evento:</source>
        <translation>Tipus d&apos;esdeveniment:</translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation>Tipus de control:</translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation>Tipus d&apos;element:</translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation>Element:</translation>
    </message>
    <message>
        <source>Valor:</source>
        <translation>Valor:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindow</name>
    <message>
        <source>Evento</source>
        <translation>Esdeveniment</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el evento.
¿Está seguro?</source>
        <translation>Es va a eliminar l&apos;esdeveniment.
Està segur?</translation>
    </message>
    <message>
        <source>Eliminar evento...</source>
        <translation>Eliminar esdeveniment...</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi nou nom...</translation>
    </message>
    <message utf8="true">
        <source>Iluminación</source>
        <translation>Il·luminació</translation>
    </message>
    <message>
        <source> - ON/OFF</source>
        <translation> - ON/OFF</translation>
    </message>
    <message>
        <source> - Regulable</source>
        <translation>Regulable</translation>
    </message>
    <message>
        <source> - RGB</source>
        <translation>RGB</translation>
    </message>
    <message>
        <source> - Todos los tipos</source>
        <translation>Tots els tipus</translation>
    </message>
    <message>
        <source> - Individual: </source>
        <translation> - Individual:</translation>
    </message>
    <message>
        <source> - Zona: </source>
        <translation> - Zona: </translation>
    </message>
    <message>
        <source> - Todas las luces</source>
        <translation> - Totes les llums</translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation>Dis. motoritzat</translation>
    </message>
    <message>
        <source> - Persiana normal</source>
        <translation> - Persiana normal</translation>
    </message>
    <message>
        <source> - Persiana posicional</source>
        <translation> - Persiana posicional</translation>
    </message>
    <message>
        <source> - Persianas agupadas</source>
        <translation> - Persiana agrupades</translation>
    </message>
    <message>
        <source> - Cualquier persiana</source>
        <translation>- Qualsevol persiana</translation>
    </message>
    <message>
        <source> - Toldo normal</source>
        <translation> - Tendal normal</translation>
    </message>
    <message>
        <source> - Toldo posicional</source>
        <translation> - Tendal posicional</translation>
    </message>
    <message>
        <source> - Toldos agupados</source>
        <translation> - Tendals agrupats</translation>
    </message>
    <message>
        <source> - Cualquier toldo</source>
        <translation> - Qualsevol Tendal</translation>
    </message>
    <message>
        <source> - Cortina normal</source>
        <translation> - Cortina normal</translation>
    </message>
    <message>
        <source> - Cortina posicional</source>
        <translation> - Cortina posicional</translation>
    </message>
    <message>
        <source> - Cortinas agupadas</source>
        <translation> - Cortines agrupades</translation>
    </message>
    <message>
        <source> - Cualquier cortina</source>
        <translation> - Qualsevol cortina</translation>
    </message>
    <message>
        <source> - Puerta motorizada</source>
        <translation> - Porta motoritzada</translation>
    </message>
    <message>
        <source> - Todos los dispositivos</source>
        <translation> - Tots els dispositius</translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation>Endoll</translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation> - Tots els endolls</translation>
    </message>
    <message>
        <source> - Encender</source>
        <translation> - Encendre</translation>
    </message>
    <message>
        <source> - Apagar</source>
        <translation> - Apagar</translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation>Climatització</translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation> - Tots els climatitzadors</translation>
    </message>
    <message>
        <source> - Apagado</source>
        <translation> - Apagat</translation>
    </message>
    <message>
        <source> - Modo manual - </source>
        <translation> - Mode manual - </translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source> - Modo programa</source>
        <translation> - Mode programa</translation>
    </message>
    <message utf8="true">
        <source> - Modo económico - </source>
        <translation> - Mode econòmic - </translation>
    </message>
    <message>
        <source>Riego</source>
        <translation>Rec</translation>
    </message>
    <message>
        <source> - Todos los riegos</source>
        <translation> - Tots els recs</translation>
    </message>
    <message>
        <source> - Activar</source>
        <translation> - Activar</translation>
    </message>
    <message>
        <source> - Desactivar</source>
        <translation> - Desactivar</translation>
    </message>
    <message>
        <source>Retardo - </source>
        <translation>Retard - </translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation>Seguretat</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation>Alarma d&apos;intrusió</translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation>Alarma de foc</translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation>Alarma de gas</translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation>Alarma d&apos;inundació</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation>Alarma de tall elèctric</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte de teléfono</source>
        <translation>Alarma de tall telefònic</translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation>Alarma de sistema</translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation>Alarma mèdica</translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation>Alarma de pànic</translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation>Alarma silenciosa</translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation>Alarma de sabotatge</translation>
    </message>
    <message utf8="true">
        <source>Alarma de coacción</source>
        <translation>Alarma de coacció</translation>
    </message>
    <message>
        <source>Deshabilitar alarma</source>
        <translation>Deshabilitar alarma</translation>
    </message>
    <message>
        <source>Habilitar alarma</source>
        <translation>Habilitar alarma</translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation>Activar alarma</translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation>Armar en mode perimetral</translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation>Armar en mode parcial</translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation>Armar en mode total</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Desarmar</translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation>Desarmar parcialment</translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindowClass</name>
    <message>
        <source>ScenesConfigWindow</source>
        <translation>finestra configuració Escenes</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renombrar</translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindow</name>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la escena.
¿Está seguro?</source>
        <translation>Es va a eliminar l&apos;escena.
Està segur?</translation>
    </message>
    <message>
        <source>Eliminar escena...</source>
        <translation>Eliminar escena...</translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
</context>
<context>
    <name>ScenesWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindow</name>
    <message>
        <source>Castellano</source>
        <translation>Castellano</translation>
    </message>
    <message utf8="true">
        <source>Inglés</source>
        <translation>Inglés</translation>
    </message>
    <message utf8="true">
        <source>Portugués</source>
        <translation>Portugués</translation>
    </message>
    <message utf8="true">
        <source>Francés</source>
        <translation>Francés</translation>
    </message>
    <message utf8="true">
        <source>Alemán</source>
        <translation>Alemán</translation>
    </message>
    <message>
        <source>Euskera</source>
        <translation>Euskera</translation>
    </message>
    <message utf8="true">
        <source>Catalán</source>
        <translation>Català</translation>
    </message>
    <message>
        <source>Gallego</source>
        <translation>Gallego</translation>
    </message>
    <message>
        <source>Turco</source>
        <translation>Turc</translation>
    </message>
    <message>
        <source>Italiano</source>
        <translation>Italià</translation>
    </message>
    <message utf8="true">
        <source>Árabe</source>
        <translation>Àrab</translation>
    </message>
    <message>
        <source>0 %</source>
        <translation>0 %</translation>
    </message>
    <message>
        <source>20 %</source>
        <translation>20 %</translation>
    </message>
    <message>
        <source>40 %</source>
        <translation>40 %</translation>
    </message>
    <message>
        <source>60 %</source>
        <translation>60 %</translation>
    </message>
    <message>
        <source>80 %</source>
        <translation>80 %</translation>
    </message>
    <message>
        <source>100 %</source>
        <translation>100 %</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>Taronja</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Cap</translation>
    </message>
    <message>
        <source>Marco de fotos digital</source>
        <translation>Marc de fotos digital</translation>
    </message>
    <message>
        <source>1 minuto</source>
        <translation>1 minut</translation>
    </message>
    <message>
        <source>2 minuto</source>
        <translation>2 minuts</translation>
    </message>
    <message>
        <source>5 minuto</source>
        <translation>5 minuts</translation>
    </message>
    <message>
        <source>10 minuto</source>
        <translation>10 minuts</translation>
    </message>
    <message>
        <source>15 minuto</source>
        <translation>15 minuts</translation>
    </message>
    <message>
        <source>30 minuto</source>
        <translation>30 minuts</translation>
    </message>
    <message>
        <source>Nunca</source>
        <translation>Mai</translation>
    </message>
    <message utf8="true">
        <source>Botón</source>
        <translation>Botó</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Acció</translation>
    </message>
    <message>
        <source>Oscuro</source>
        <translation>Fosc</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation>Verd</translation>
    </message>
    <message>
        <source>(vacio)</source>
        <translation>(buit)</translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source> Identificador de pantalla</source>
        <translation> Identificador de pantalla</translation>
    </message>
    <message>
        <source> Idioma</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source> Volumen</source>
        <translation> Volum</translation>
    </message>
    <message>
        <source> Brillo</source>
        <translation>Brillo</translation>
    </message>
    <message>
        <source>Sonido teclado</source>
        <translation>So Teclat</translation>
    </message>
    <message>
        <source>Sensor de presencia</source>
        <translation>Sensor de presència</translation>
    </message>
    <message>
        <source> Paleta</source>
        <translation> Paleta</translation>
    </message>
    <message>
        <source> Color iconos</source>
        <translation> Color icones</translation>
    </message>
    <message>
        <source>Offset de temperatura</source>
        <translation>Offset de temperatura</translation>
    </message>
    <message>
        <source>Visualizar cursor</source>
        <translation>Visualitza cursor</translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para ejecutar escenas</source>
        <translation>Demanar contrasenya per executar escenes</translation>
    </message>
    <message>
        <source>Salvapantallas</source>
        <translation>Salvapantalles</translation>
    </message>
    <message>
        <source> Salvapantallas</source>
        <translation>Salvapantalles</translation>
    </message>
    <message utf8="true">
        <source> Activación Salvapantallas</source>
        <translation> Activació Salvapantalles</translation>
    </message>
    <message>
        <source> Tiempo entre fotos</source>
        <translation> Temps entre fotos</translation>
    </message>
    <message>
        <source> Autoapagado</source>
        <translation> Autoapagat</translation>
    </message>
    <message>
        <source>Botones</source>
        <translation>Botons</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message utf8="true">
        <source>Habilitación tamper</source>
        <translation>Habilitació tamper</translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindow</name>
    <message>
        <source>Armado total</source>
        <translation>Armat total</translation>
    </message>
    <message>
        <source>Armado parcial</source>
        <translation>Armat parcial</translation>
    </message>
    <message>
        <source>Armado perimetral</source>
        <translation>Armat perimetral</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Cap</translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message utf8="true">
        <source>Intrusión</source>
        <translation>Intrusió</translation>
    </message>
    <message utf8="true">
        <source>Habilitar autoarmado de intrusión</source>
        <translation>Habilitar autoarmat d&apos;intrusió</translation>
    </message>
    <message>
        <source>Programa asociado el autoarmado</source>
        <translation>Programa associat el autoarmat</translation>
    </message>
    <message utf8="true">
        <source>Activar simulación de presencia con el armado total</source>
        <translation>Activar simulació de presència amb l&apos;armat total</translation>
    </message>
    <message>
        <source>Tiempo de salida de la vivienda (seg):</source>
        <translation>Temps de sortida de l&apos;habitatge (seg):</translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para armar la alarma de intrusión</source>
        <translation>Demanar contrasenya per armar l&apos;alarma d&apos;intrusió</translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation>Incendi</translation>
    </message>
    <message>
        <source>Gas</source>
        <translation>Gas</translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation>Inundació</translation>
    </message>
    <message utf8="true">
        <source>Hora de auto limpieza de la electroválvula de agua:</source>
        <translation>Hora d&apos;acte neteja de l&apos;electrovàlvula d&apos;aigua:</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:mm</translation>
    </message>
    <message utf8="true">
        <source>Corte Red Eléctrica</source>
        <translation>Tall Elèctric</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (min):</source>
        <translation>Retard a l&apos;activació (min):</translation>
    </message>
    <message utf8="true">
        <source>Corte teléfono</source>
        <translation>Tall de Telèfon</translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation>Sistema</translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation>Mèdica</translation>
    </message>
    <message utf8="true">
        <source>Detección de inactividad</source>
        <translation>Detecció d&apos;inactivitat</translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation>Pànic</translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation>Silenciosa</translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation>Sabotatge</translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation>Coacció</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Llamar en caso de alarma a:</source>
        <translation>Trucar en cas d&apos;alarma a:</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 1</source>
        <translation>Telèfon 1</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 2</source>
        <translation>Telèfon 2</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 3</source>
        <translation>Telèfon 3</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 4</source>
        <translation>Telèfon 4</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 5</source>
        <translation>Telèfon 5</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 6</source>
        <translation>Telèfon 6</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 7</source>
        <translation>Telèfon 7</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 8</source>
        <translation>Telèfon 8</translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation>Missatges
Personals</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (seg):</source>
        <translation>Retard a l&apos;activació (seg):</translation>
    </message>
</context>
<context>
    <name>SecurityWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Armado Perimetral</source>
        <translation>Armat perimetral</translation>
    </message>
    <message>
        <source>Armado Parcial</source>
        <translation>Armat parcial</translation>
    </message>
    <message>
        <source>Armado Total</source>
        <translation>Armat total</translation>
    </message>
</context>
<context>
    <name>SensorControl</name>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi el nou nom...</translation>
    </message>
</context>
<context>
    <name>SensorControlClass</name>
    <message>
        <source>SensorControl</source>
        <translation>SensorControl</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Deshabilitar sensor</source>
        <translation>Deshabilitar sensor</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <source>Interviene en el armado parcial</source>
        <translation>Intervé en l&apos;armat parcial</translation>
    </message>
    <message>
        <source>Interviene en el armado perimetral</source>
        <translation>Intervé en l&apos;armat perimetral</translation>
    </message>
    <message>
        <source>Tiempo de entrada:</source>
        <translation>Temps d&apos;entrada:</translation>
    </message>
    <message>
        <source>Offset de temperatura:</source>
        <translation>Offset de temperatura:</translation>
    </message>
    <message>
        <source>Retraso a la activacion:</source>
        <translation>Retard a l&apos;activació:</translation>
    </message>
</context>
<context>
    <name>SystemConfigWindow</name>
    <message utf8="true">
        <source>Se va a proceder a importar ficheros.
Por favor, no saque el dispositivo durante la importación.
 ¿Desea continuar?</source>
        <translation>Es va a procedir a importar fitxers.
Per favor, no tregui el dispositiu durant la importació.
Desitja continuar?</translation>
    </message>
    <message>
        <source>Importando...</source>
        <translation>important...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a exportar ficheros.
Por favor, no saque el dispositivo durante la exportación.
¿Desea continuar?</source>
        <translation>Es va a procedir a exportar fitxers.
Per favor, no tregui el dispositiu durant l&apos;exportació.
Desitja continuar?</translation>
    </message>
    <message>
        <source>Exportando...</source>
        <translation>Exportant...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Firmware.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation>Es va a procedir a actualitzar el Firmware.
Per favor, no tregui el dispositiu durant l&apos;actualització.
Desitja continuar?</translation>
    </message>
    <message>
        <source>Actualizando...</source>
        <translation>Actualitzant...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Webserver.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation>Es va a procedir a actualitzar el Webserver.
Per favor, no tregui el dispositiu durant l&apos;actualització.
Desitja continuar?</translation>
    </message>
    <message utf8="true">
        <source>Para proceder a calibrar el touch es necesario reiniciar la pantalla.
¿Desea continuar?</source>
        <translation>Per procedir a calibrar el touch és necessari reiniciar la pantalla.
Desitja continuar?</translation>
    </message>
    <message>
        <source>Calibrar Touch...</source>
        <translation>Calibrar Touch...</translation>
    </message>
    <message>
        <source>Test Alarmas: %1
Pulse para %2</source>
        <translation>Test Alarmas: %1
Premi per %2</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation>Desactivar</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>Activar</source>
        <translation>Activar</translation>
    </message>
</context>
<context>
    <name>SystemConfigWindowClass</name>
    <message>
        <source>SystemConfigWindow</source>
        <translation>SystemConfigWindow</translation>
    </message>
    <message>
        <source>Reset del Sistema</source>
        <translation>Reset del Sistema</translation>
    </message>
    <message>
        <source>Exportar Ficheros</source>
        <translation>Exportar Fitxers</translation>
    </message>
    <message>
        <source>Importar  Ficheros</source>
        <translation>Importar Fitxers</translation>
    </message>
    <message>
        <source>Actualizar
Firmware</source>
        <translation>Actualizar
Firmware</translation>
    </message>
    <message>
        <source>Acceder como
instalador</source>
        <translation>Accedir com
instal.lador</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
    <message>
        <source>Recalibrar Touch</source>
        <translation>Recalibrar Touch</translation>
    </message>
    <message>
        <source>Log de Errores</source>
        <translation>Log d&apos;Errors</translation>
    </message>
    <message>
        <source>Actualizar
WebServer</source>
        <translation>Actualitzar
WebServer</translation>
    </message>
    <message>
        <source>Prueba de alarmas: %1
Pulse para %2</source>
        <translation>Prova d&apos;alarmes: %1
Premi per %2</translation>
    </message>
    <message>
        <source>Test llamadas CRA</source>
        <translation>Test trucades CRA</translation>
    </message>
    <message>
        <source>Licencia...</source>
        <translation>Llicència...</translation>
    </message>
</context>
<context>
    <name>UsersConfigWindow</name>
    <message>
        <source>Nombre</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Clave</source>
        <translation>Clau</translation>
    </message>
    <message>
        <source>Nivel Acceso</source>
        <translation>Nivell Accés</translation>
    </message>
    <message>
        <source>Maestro</source>
        <translation>Mestre</translation>
    </message>
    <message>
        <source>Alto</source>
        <translation>Alt</translation>
    </message>
    <message>
        <source>Medio</source>
        <translation>Mitjà</translation>
    </message>
    <message>
        <source>Bajo</source>
        <translation>Baix</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introdueixi el nou nom ...</translation>
    </message>
    <message utf8="true">
        <source>Introduzca la nueva contraseña</source>
        <translation>Introdueixi la nova contrasenya</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el usuario.
¿Está seguro?</source>
        <translation>Es va a eliminar l&apos;usuari.
Està segur?</translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation>Eliminar contacte...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Falten dades per omplir.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
</context>
<context>
    <name>UsersConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Leer Llave</source>
        <translation>Llegir clau</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Tancar</translation>
    </message>
</context>
<context>
    <name>WarningDialog</name>
    <message utf8="true">
        <source>Fallo en el sistema de avisos telefónicos.</source>
        <translation>Fallada en el sistema d&apos;avisos telefònics.</translation>
    </message>
    <message>
        <source>Test de CRA fallido.</source>
        <translation>Test de CRA fallit.</translation>
    </message>
    <message utf8="true">
        <source>Aviso de cancelación de alarma de intrusión fallido.</source>
        <translation>Avís de cancel·lació d&apos;alarma d&apos;intrusió fallit.</translation>
    </message>
    <message utf8="true">
        <source>Armado de intrusión cancelado. Sensor no temporizado activo:
%1</source>
        <translation>Armat d&apos;intrusió cancel·lat. Sensor no temporitzat actiu:
%1</translation>
    </message>
    <message>
        <source>Climatizador apagado por ventana abierta:
%1</source>
        <translation>Climatitzador apagat per finestra oberta:
%1</translation>
    </message>
    <message>
        <source>Entrada de sensor en circuito abierto:
%1</source>
        <translation>Entrada de sensor en circuit obert:
%1</translation>
    </message>
    <message utf8="true">
        <source>Cámara de videoportería ocupada.</source>
        <translation>Càmera de videoporteria ocupada.</translation>
    </message>
    <message>
        <source>No se ha encontrado el mensaje que se desea reproducir.</source>
        <translation>No s&apos;ha trobat el missatge que es desitja reproduir.</translation>
    </message>
    <message utf8="true">
        <source>No hay espacio para grabar más mensajes de voz, o se ha alcanzado el límite de 10 mensajes.</source>
        <translation>No hi ha espai per gravar més missatges de veu, o s&apos;ha aconseguit el límit de 10 missatges.</translation>
    </message>
    <message utf8="true">
        <source>Error en la comunicación con el módulo %1:
Comando rechazado.</source>
        <translation>Error en la comunicació amb el mòdul %1:
Comando rebutjat.</translation>
    </message>
    <message>
        <source>Error al iniciar el sistema de ficheros. Compruebe si la tarjeta SD de la central funciona correctamente.</source>
        <translation>Error en iniciar el sistema de fitxers. Comprovi si la targeta SD de la central funciona correctament.</translation>
    </message>
    <message utf8="true">
        <source>El estado de la batería es bajo.</source>
        <translation>L&apos;estat de la bateria és baix.</translation>
    </message>
    <message utf8="true">
        <source>Perdidas de tramas en la comunicación.</source>
        <translation>Perdudes de trames en la comunicació.</translation>
    </message>
    <message utf8="true">
        <source>Comunicación recuperada.</source>
        <translation>Comunicació recuperada.</translation>
    </message>
    <message utf8="true">
        <source>Mensaje de Aviso Nº%1</source>
        <translation>Missatge d&apos;Avís Nº%1</translation>
    </message>
    <message utf8="true">
        <source>No hay batería o la batería falla.</source>
        <translation>No hi ha bateria o la bateria falla.</translation>
    </message>
    <message>
        <source>Iniciando el test de CRA...</source>
        <translation>Iniciant el test de CRA...</translation>
    </message>
    <message>
        <source>El test CRA ha sido satisfactorio.</source>
        <translation>El test CRA ha estat satisfactori.</translation>
    </message>
    <message utf8="true">
        <source>Número de mensaje desconocido %1</source>
        <translation>Nombre de missatge desconegut %1</translation>
    </message>
</context>
<context>
    <name>WarningDialogClass</name>
    <message>
        <source>WarningDialog</source>
        <translation>WarningDialog</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation>&lt;&lt;</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation>&gt;&gt;</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Borrar</translation>
    </message>
</context>
<context>
    <name>ZoneSelect</name>
    <message>
        <source>luces</source>
        <translation>llums</translation>
    </message>
    <message>
        <source>clima</source>
        <translation>clima</translation>
    </message>
    <message>
        <source>dispositivos</source>
        <translation>dispositius</translation>
    </message>
    <message>
        <source>persianas</source>
        <translation>persianes</translation>
    </message>
    <message>
        <source>cortinas</source>
        <translation>cortines</translation>
    </message>
    <message>
        <source>puertas</source>
        <translation>portes</translation>
    </message>
    <message>
        <source>riegos</source>
        <translation>regs</translation>
    </message>
    <message>
        <source>toldos</source>
        <translation>Tendall</translation>
    </message>
    <message>
        <source>sensores</source>
        <translation>sensors</translation>
    </message>
</context>
<context>
    <name>ZoneSelectClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
</context>
</TS>
