<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pt_PT" sourcelanguage="es_ES">
<context>
    <name>AlarmDialog</name>
    <message utf8="true">
        <source>ALARMA DE INTRUSIÓN</source>
        <translation>ALARME DE INTRUSÃO</translation>
    </message>
    <message>
        <source>ALARMA DE FUEGO</source>
        <translation>ALARME DE INCÊNDIO</translation>
    </message>
    <message>
        <source>ALARMA DE GAS</source>
        <translation>ALARME DE GÁS</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE INUNDACIÓN</source>
        <translation>ALARME DE INUNDAÇÃO</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE ELÉCTRICO</source>
        <translation>ALARME DE CORTE 230V</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE TELEFÓNICO</source>
        <translation>ALARME DE CORTE DA LINHA TELEFÓNICA</translation>
    </message>
    <message>
        <source>ALARMA DE SISTEMA</source>
        <translation>ALARME DO SISTEMA</translation>
    </message>
    <message utf8="true">
        <source>ALARMA MÉDICA</source>
        <translation>ALARME MÉDICO</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE PÁNICO</source>
        <translation>ALARME DE PÂNICO</translation>
    </message>
    <message>
        <source>ALARMA SILENCIOSA</source>
        <translation>ALARME SILENCIOSO</translation>
    </message>
    <message>
        <source>ALARMA DE SABOTAJE</source>
        <translation>ALARME DE SABOTAGEM</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE COACCIÓN</source>
        <translation>ALARME DE COAÇÃO</translation>
    </message>
    <message>
        <source>
 en las siguientes zonas:
</source>
        <translation>
 nas seguintes zonas:
</translation>
    </message>
    <message>
        <source>REARMAR ALARMAS</source>
        <translation>REARMAR ALARMES</translation>
    </message>
    <message>
        <source>Hay alarmas desarmadas. Pulse rearmar para volver a proteger el sistema.</source>
        <translation>Há alarmes desarmados. Carregue rearmar para voltar a proteger o sistema.</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar alarmas</source>
        <translation>Introduza o código para desarmar os alarmes</translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 90 segundos.</source>
        <translation type="unfinished">Sistema bloqueado após três tentativas falharam entrada de senha. Para voltar a digitar a senha esperar 90 segundos.</translation>
    </message>
    <message>
        <source>Sistema bloqueado</source>
        <translation type="unfinished">Sistema travar</translation>
    </message>
</context>
<context>
    <name>AlarmDialogClass</name>
    <message>
        <source>AlarmDialog</source>
        <translation></translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Desarmar</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation></translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Menú
Alarmas</source>
        <translation>Menu
Alarmes</translation>
    </message>
    <message>
        <source>Rearmar</source>
        <translation>Rearmar</translation>
    </message>
</context>
<context>
    <name>AlarmsWindow</name>
    <message>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
</context>
<context>
    <name>AlarmsWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation>Incêndio</translation>
    </message>
    <message>
        <source>Gas</source>
        <translation>Gás</translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation>Inundação</translation>
    </message>
    <message utf8="true">
        <source>Corte Eléctrico</source>
        <translation>Corte 230V</translation>
    </message>
    <message utf8="true">
        <source>Corte de Teléfono</source>
        <translation>Corte de Linha Teléfonica</translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation>Sistema</translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation>Médico</translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation>Pânico</translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation>Silencioso</translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation>Sabotagem</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation>Coação</translation>
    </message>
</context>
<context>
    <name>ArmingWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Armando...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AssociatedZonesClass</name>
    <message>
        <source>AssociatedZones</source>
        <translation></translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Baixar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Subir</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message utf8="true">
        <source>Zonas asociadas con la unidad climática...</source>
        <translation>Zonas associadas com a unidade de climatização...</translation>
    </message>
</context>
<context>
    <name>BlackboardWindowClass</name>
    <message>
        <source>BlackboardWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation>Gravar</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Apagar</translation>
    </message>
</context>
<context>
    <name>BlindControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>Grupo de persianas</source>
        <translation>Grupo de estores</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estado desconhecido</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
</context>
<context>
    <name>BlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associado:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <source>Bajar persianas en caso de lluvia</source>
        <translation>Baixar os estores em caso de chuva</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Tempo de subida / descida:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo de funcionamento:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Mudar o icon</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>todos</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Bajar persianas en caso de viento fuerte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DOWN</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CRAConfigDialog</name>
    <message>
        <source>ADEMCO CID</source>
        <translation>Protocolo ADEMCO</translation>
    </message>
    <message utf8="true">
        <source>Introduzca el código de abonado ...</source>
        <translation>Introduza o código ...</translation>
    </message>
</context>
<context>
    <name>CRAConfigDialogClass</name>
    <message>
        <source>CRAConfigDialog</source>
        <translation></translation>
    </message>
    <message>
        <source>Configuracion CRA</source>
        <translation>Configuração CRA</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Habilitacion</source>
        <translation>Habilitação</translation>
    </message>
    <message>
        <source>Cambiar
Codigo</source>
        <translation>Mudar 
código</translation>
    </message>
    <message>
        <source>Protocolo</source>
        <translation>Protocolo</translation>
    </message>
    <message>
        <source>Autotest</source>
        <translation>Auto-teste</translation>
    </message>
    <message>
        <source>Cadencia</source>
        <translation>Sequência</translation>
    </message>
    <message>
        <source>Hora del primer test</source>
        <translation>Hora do primeiro teste</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:mm</translation>
    </message>
    <message>
        <source>Codigo de cuenta</source>
        <translation>Código da conta</translation>
    </message>
</context>
<context>
    <name>CamsWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation>Chamar portaria</translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation>Comunicação com portaria estabelecida</translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation>Não é possível estabelecer a comunicação porque já foi desligado a partir de outro painel.</translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation>Videoporteiro ocupado</translation>
    </message>
</context>
<context>
    <name>CamsWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation>Falar</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation>Subir Vol.</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation>Baixar Vol.</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Subir</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Baixar</translation>
    </message>
    <message>
        <source>Izquierda</source>
        <translation>Esquerda</translation>
    </message>
    <message>
        <source>Derecha</source>
        <translation>Direita</translation>
    </message>
</context>
<context>
    <name>ClimaControl</name>
    <message utf8="true">
        <source>Frío</source>
        <translation>Frio</translation>
    </message>
    <message>
        <source>Calor</source>
        <translation>Calor</translation>
    </message>
    <message>
        <source>Climatizador</source>
        <translation>Climatizador</translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation>Desligado</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Nenhum</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
</context>
<context>
    <name>ClimaControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Modo general:</source>
        <translation>Modo geral:</translation>
    </message>
    <message>
        <source>Primer programa asociado:</source>
        <translation>Primeiro programa associado:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renomear</translation>
    </message>
    <message utf8="true">
        <source>Apagar climatización en caso de ventana abierta</source>
        <translation>Desligar climatização em caso de janela aberta</translation>
    </message>
    <message>
        <source>Consig. Min:</source>
        <translation>Setpoint Min:</translation>
    </message>
    <message>
        <source>Consig. Max:</source>
        <translation>Setpoint Max:</translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source>Zonas
Asociadas</source>
        <translation>Zonas 
associadas</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Mudar o icon</translation>
    </message>
    <message>
        <source>Sensor de temperatura asociado:</source>
        <translation>Sensor de temperatura associado:</translation>
    </message>
    <message>
        <source>Histeresis:</source>
        <translation>Histerese:</translation>
    </message>
    <message>
        <source>Segundo programa asociado:</source>
        <translation>Segundo programa associado:</translation>
    </message>
    <message>
        <source>modo</source>
        <translation>modo</translation>
    </message>
    <message utf8="true">
        <source>0ºC</source>
        <translation>0ºC</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>todos</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>ClimaWindow</name>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
</context>
<context>
    <name>ClimaWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>MANUAL</source>
        <translation>MANUAL</translation>
    </message>
    <message>
        <source>PROGRAMA</source>
        <translation>PROGRAMA</translation>
    </message>
    <message>
        <source>ECO</source>
        <translation>ECO</translation>
    </message>
    <message utf8="true">
        <source>--ºC</source>
        <translation>--ºC</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Baixar</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Subir</translation>
    </message>
</context>
<context>
    <name>ConfigWindow</name>
    <message utf8="true">
        <source>Vivimat III

versión %1.%2.%3

[%4]</source>
        <translation>Vivimat III

Versão %1.%2.%3

[%4]</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión 0.2.0</source>
        <translation type="obsolete">Vision Cor 7

Versão 1.0.0</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión %1.%2.%3
</source>
        <translation>Vision Cor 7

Versão %1.%2.%3</translation>
    </message>
    <message utf8="true">
        <source>Sistema de ficheros

Versión: %1</source>
        <translation>Filesystem

Versão %1</translation>
    </message>
    <message utf8="true">
        <source>Vivimat III

versión Demo %1.%2.%3

[%4]</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión Demo %1.%2.%3
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>mando IR</source>
        <translation>comando IV</translation>
    </message>
    <message>
        <source>programas horarios</source>
        <translation>programas de tempo</translation>
    </message>
    <message>
        <source>multimedia</source>
        <translation>multimídia</translation>
    </message>
    <message utf8="true">
        <source>gestión de energía</source>
        <translation>gestão de energia</translation>
    </message>
    <message>
        <source>escenas</source>
        <translation>cenários</translation>
    </message>
    <message utf8="true">
        <source>telefonía</source>
        <translation>telefonia</translation>
    </message>
    <message>
        <source>usuarios</source>
        <translation>utilizadores</translation>
    </message>
    <message>
        <source>sistema</source>
        <translation>sistema</translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation>segurança</translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation>videoporteiro</translation>
    </message>
    <message>
        <source>fecha y hora</source>
        <translation>data e hora</translation>
    </message>
    <message>
        <source>pantalla</source>
        <translation>painel</translation>
    </message>
</context>
<context>
    <name>ConfirmationDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Aceitar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>ConsumptionWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Escala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Semana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mes</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Año</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unidades</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unit3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CurtainControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>Grupo de cortinas</source>
        <translation>Grupo de cortinas</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estado desconhecido</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
</context>
<context>
    <name>CurtainControlClass</name>
    <message>
        <source>CurtainControl</source>
        <translation></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associado:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo de funcionamento:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Mudar o icon</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Tempo de subida / descida:</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>todos</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>DateHourWindow</name>
    <message>
        <source>Lunes</source>
        <translation>Segunda-feira</translation>
    </message>
    <message>
        <source>Martes</source>
        <translation>Terça-feira</translation>
    </message>
    <message utf8="true">
        <source>Miércoles</source>
        <translation>Quarta-feira</translation>
    </message>
    <message>
        <source>Jueves</source>
        <translation>Quinta-feira</translation>
    </message>
    <message>
        <source>Viernes</source>
        <translation>Sexta-feira</translation>
    </message>
    <message utf8="true">
        <source>Sábado</source>
        <translation>Sábado</translation>
    </message>
    <message>
        <source>Domingo</source>
        <translation>Domingo</translation>
    </message>
</context>
<context>
    <name>DateHourWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>/</source>
        <translation>/</translation>
    </message>
    <message>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>DoorControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>Abierta</source>
        <translation>Aberta</translation>
    </message>
    <message>
        <source>Cerrada</source>
        <translation>Fechada</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estado desconhecido</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
</context>
<context>
    <name>DoorControlClass</name>
    <message>
        <source>DoorControl</source>
        <translation></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associado:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo de funcionamento:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Mudar o icon</translation>
    </message>
    <message>
        <source>Tiempo de apertura / cierre:</source>
        <translation>Tempo de abertura / fecho:</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>todos</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>DoorphoneDialog</name>
    <message>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Aceitar</translation>
    </message>
    <message>
        <source>Llamada VIDEOPORTERO</source>
        <translation>chamada video porteiro</translation>
    </message>
    <message>
        <source>Llamada desde videoportero</source>
        <translation>Chamada de entrada de vídeo</translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation>Chamar portaria</translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation>Comunicação com portaria estabelecida</translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation>Não é possivel estabelecer a comunicação porque já foi desligado a partir de outro painel.</translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation>Videoporteiro ocupado</translation>
    </message>
    <message>
        <source>Conserje no contesta.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación, otra lladama en curso.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conserge ocupado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation>Falar</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation type="obsolete">Baixar Vol.</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation type="obsolete">Subir Vol.</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Baixar</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Subir</translation>
    </message>
    <message utf8="true">
        <source>Portería</source>
        <translation>Portão</translation>
    </message>
    <message>
        <source>Ver</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EntryphoneConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message utf8="true">
        <source>Habilitar Desvío</source>
        <translation>Habilitar desvio</translation>
    </message>
    <message>
        <source>Habilitar Contestador</source>
        <translation>Habilitar atendimento</translation>
    </message>
    <message utf8="true">
        <source>Contacto al que se desvía la llamada:</source>
        <translation>Contacto para o desvio da chamada:</translation>
    </message>
    <message>
        <source>Habilitar llamada desde puerta de entrada</source>
        <translation>Habilitar chamada desde a porta de entrada</translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation>Mensagens 
pessoais</translation>
    </message>
    <message utf8="true">
        <source>Número de veces que sonara: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileTransfer</name>
    <message>
        <source>Aplicacion DEMO para Windows.Simulando la transferencia de ficheros.</source>
        <translation>Aplicação DEMO para Windows Simulando a transferência de ficheiros.</translation>
    </message>
    <message>
        <source>Se ha encontrado una tarjeta SD.No saque la tarjeta hasta que finalice el intercambio de ficheros.</source>
        <translation>Foi encontrado um cartão SD. Não retire o cartão antes de terminar a troca de ficheiros.</translation>
    </message>
    <message>
        <source>Se ha encontrado un dispositivo USB.No saque el dispositivo hasta que finalice el intercambio de ficheros.</source>
        <translation>Foi encontrado um dispositivo USB. Não retire o dispositivo antes de terminar a transferencia de ficheiros.</translation>
    </message>
    <message utf8="true">
        <source>No se ha encontrado ningún dispositivo.Pulsa cancelar para salir.</source>
        <translation>Não foi encontrado nenhum dispositivo. Prima cancelar para sair.</translation>
    </message>
    <message utf8="true">
        <source>La actualización ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation>A atualização foi finalizada. É necessario reiniciar o sistema.</translation>
    </message>
    <message utf8="true">
        <source>La exportación ha finalizado.Pulsa Aceptar para continuar.</source>
        <translation>A exportação foi finalizada. Prima Aceitar para continuar.</translation>
    </message>
    <message utf8="true">
        <source>La importación ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation>A importação foi finalizada. É necessario reiniciar o sistema.</translation>
    </message>
    <message>
        <source>No existe un fichero de firmware. Inserte un dispositivo con un fichero de firmware.</source>
        <translation>Não há nenhum arquivo do firmware. Insira um dispositivo com um arquivo de firmware.</translation>
    </message>
    <message>
        <source>Error a la hora de copiar el nuevo firmware.</source>
        <translation>Erro ao copiar o novo firmware.</translation>
    </message>
    <message utf8="true">
        <source>La copia del programa de calibración ha fallado.</source>
        <translation type="obsolete">A cópia do programa de calibração falhou.</translation>
    </message>
    <message utf8="true">
        <source>No se encuentran todos los ficheros necesarios para la actualizacion del servidor web.
No se ha podido realizar la actualización.</source>
        <translation>Não são todos os arquivos necessários para atualizar o servidor web.
Falha ao atualizar.</translation>
    </message>
    <message utf8="true">
        <source>La actualización ha fallado. Se mantiene el viejo rcS.</source>
        <translation>A atualização falhou. Ele mantém a rcS de idade.</translation>
    </message>
    <message>
        <source>cp -rf %1/PantallaColor /App/PantallaColor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileTransferClass</name>
    <message>
        <source>FileTransfer</source>
        <translation></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Aceitar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>FloorSelectClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Baixar</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Subir</translation>
    </message>
</context>
<context>
    <name>HistoryWindow</name>
    <message>
        <source>Historial de Eventos</source>
        <translation>Historial de eventos</translation>
    </message>
    <message>
        <source>Historial de Errores</source>
        <translation>História erro</translation>
    </message>
</context>
<context>
    <name>HistoryWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Historial de Eventos</source>
        <translation>Historial de eventos</translation>
    </message>
    <message>
        <source>01/01/2010 13:39:05 &gt; System initialization completed
01/01/2010 13:45:15 &gt; Intrusion alarm armed in total mode: Sergio
01/01/2010 13:50:05 &gt; Intrusion alarm disarmed: Sergio
</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>IRCodeReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Apunte el mando hacia el
receptor y pulse la tecla
correspondiente...</source>
        <translation>Aponte o comando para
o receptor e prima a tecla
correspondente...</translation>
    </message>
    <message utf8="true">
        <source>Leer código de infrarrojos</source>
        <translation>Leitura de código de IV</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindow</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation>Executar cenário</translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation>Arm. Intrusão Modo Perímetros</translation>
    </message>
    <message utf8="true">
        <source>Activar pánico</source>
        <translation>Ativar pânico</translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation>Abrir videoporteiro</translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation>Acender a luz</translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation>Desligar a luz</translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation>Aumentar luz</translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation>Diminuir luz</translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation>Subir dispositivo motorizado</translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation>Baixar dispositivo motorizado</translation>
    </message>
    <message>
        <source>Encender clima</source>
        <translation>Ligar clima</translation>
    </message>
    <message>
        <source>Apagar clima</source>
        <translation>Desligar climatização</translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation>Ligar a tomada</translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation>Desligar a tomada</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Ação</translation>
    </message>
    <message utf8="true">
        <source>Código IR</source>
        <translation>Código IV</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la acción.
¿Está seguro?</source>
        <translation>A ação vai ser eliminada.
Continuar?</translation>
    </message>
    <message utf8="true">
        <source>Eliminar acción...</source>
        <translation>Eliminar a ação...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Falta preencher dados.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Erro...</translation>
    </message>
    <message>
        <source> - ON/OFF -</source>
        <translation> - ON/OFF -</translation>
    </message>
    <message>
        <source> - Regulable -</source>
        <translation> - Variável -</translation>
    </message>
    <message>
        <source> - RGB -</source>
        <translation> - RGB -</translation>
    </message>
    <message>
        <source> - Todos los tipos -</source>
        <translation> - Todos os tipos -</translation>
    </message>
    <message>
        <source> Individual - </source>
        <translation> Individual - </translation>
    </message>
    <message>
        <source> Zona - </source>
        <translation> Zona - </translation>
    </message>
    <message>
        <source> Todas las luces</source>
        <translation> Todas as luzes</translation>
    </message>
    <message>
        <source> - Individual - </source>
        <translation> - Individual - </translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation> - Todas as climatizações</translation>
    </message>
    <message>
        <source> - Zona - </source>
        <translation> - Zona - </translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation> - Todas as tomadas</translation>
    </message>
    <message>
        <source> - Persiana normal -</source>
        <translation> - Estore normal -</translation>
    </message>
    <message>
        <source> - Persiana posicional -</source>
        <translation> - Estore posicional -</translation>
    </message>
    <message>
        <source> - Persianas agupadas -</source>
        <translation> - Estores agrupados -</translation>
    </message>
    <message>
        <source> - Cualquier persiana -</source>
        <translation> - Qualquer estore - </translation>
    </message>
    <message>
        <source> - Toldo normal -</source>
        <translation> - Toldo normal -</translation>
    </message>
    <message>
        <source> - Toldo posicional -</source>
        <translation> - Toldo posicional -</translation>
    </message>
    <message>
        <source> - Toldos agupados -</source>
        <translation> - Toldos agrupados-</translation>
    </message>
    <message>
        <source> - Cualquier toldo -</source>
        <translation> - Qualquer toldo -</translation>
    </message>
    <message>
        <source> - Cortina normal -</source>
        <translation> - Cortina normal -</translation>
    </message>
    <message>
        <source> - Cortina posicional -</source>
        <translation> - Cortina posicional -</translation>
    </message>
    <message>
        <source> - Cortinas agupadas -</source>
        <translation> - Cortinas agrupadas -</translation>
    </message>
    <message>
        <source> - Cualquier cortina -</source>
        <translation> - Qualquer cortina -</translation>
    </message>
    <message>
        <source> - Puerta motorizada -</source>
        <translation> - Porta motorizada -</translation>
    </message>
    <message>
        <source> Todos</source>
        <translation> Todos</translation>
    </message>
    <message utf8="true">
        <source>Conmutar cámara</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Ação</translation>
    </message>
    <message utf8="true">
        <source>Código</source>
        <translation>Código</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialog</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation>Executar cenário</translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation>Arm. Intrusão Modo Perímetros</translation>
    </message>
    <message utf8="true">
        <source>Activar pánico</source>
        <translation>Ativar pânico</translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation>Abrir videoporteiro</translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation>Acender a luz</translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation>Desligar a luz</translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation>Aumentar luz</translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation>Diminuir luz</translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation>Subir dispositivo motorizado</translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation>Baixar dis. motorizado</translation>
    </message>
    <message>
        <source>Encender Clima</source>
        <translation>Ligar clima</translation>
    </message>
    <message>
        <source>Apagar Clima</source>
        <translation>Desligar climatização</translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation>Ligar a tomada</translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation>Desligar a tomada</translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation>Luz ON/Off</translation>
    </message>
    <message>
        <source>Luz regulable</source>
        <translation>Luz variável</translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation>Todos os tipos</translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation>Luz individual</translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation>Luzes da zona</translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation>Todas as luzes</translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation>Climatização individual</translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation>Todas as climatizações</translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation>Tomada individual</translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation>Tomadas da zona</translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation>Todas as tomadas</translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation>Estore normal</translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation>Estore posicional</translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation>Estores agrupados</translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation>Qualquer estore</translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation>Toldo normal</translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation>Toldo posicional</translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation>Toldos agrupados</translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation>Qualquer toldo</translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation>Cortina normal</translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation>Cortina posicional</translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation>Cortinas agrupadas-</translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation>Qualquer cortina</translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation>Porta motorizada</translation>
    </message>
    <message>
        <source>Dispositivo individual</source>
        <translation>Dispositivo individual</translation>
    </message>
    <message>
        <source>Dispositivos de la zona</source>
        <translation>Dispositivos da zona</translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation>Todos os dispositivos</translation>
    </message>
    <message>
        <source>Conmutar camara</source>
        <translation>Cambiare macchina fotografica</translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Cambiar acción asociada a la tecla</source>
        <translation>Alterar acção associada à tecla</translation>
    </message>
    <message utf8="true">
        <source>Acción:</source>
        <translation>Ação:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation>Tipo de elemento:</translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation>Tipo de controlo:</translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation>Elemento:</translation>
    </message>
</context>
<context>
    <name>IconChangeDialogClass</name>
    <message>
        <source>IconChangeDialog</source>
        <translation></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Mudar o icon</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>IrrigatorControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>En espera</source>
        <translation>Em espera</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estado desconhecido</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
</context>
<context>
    <name>IrrigatorControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo de funcionamento:</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associado:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renomear</translation>
    </message>
    <message utf8="true">
        <source>Detener riego en caso de lluvia o suelo ya húmedo</source>
        <translation>Parar a rega em caso de chuva ou solo já húmido</translation>
    </message>
    <message>
        <source>Sensor de humedad asociado:</source>
        <translation>Sensor de humidade associado:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Mudar o icon</translation>
    </message>
    <message>
        <source>Duracion del riego (minutos):</source>
        <translation>Duração da rega (minutos):</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>todos</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>KeyReadDialog</name>
    <message utf8="true">
        <source>- Código: </source>
        <translation> - Código: </translation>
    </message>
    <message>
        <source>
- Tipo: </source>
        <translation>
- Tipo: </translation>
    </message>
    <message>
        <source>
- Asignada a: </source>
        <translation>
- Atribuida a: </translation>
    </message>
    <message utf8="true">
        <source>Llave desconocida.
- Código: </source>
        <translation>Chave desconhecida 
- Código: </translation>
    </message>
</context>
<context>
    <name>KeyReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Acerque la llave
para ser leída</source>
        <translation>Aproxime a chave
para ser lida</translation>
    </message>
    <message>
        <source>Leer llave</source>
        <translation>Leitura da chave</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>KeyRecordDialog</name>
    <message utf8="true">
        <source>El usuario tiene
asociada la llave
con código: </source>
        <translation>O utilizador tem
associada a chave
com código: </translation>
    </message>
    <message utf8="true">
        <source>No hay espacio
para grabar más llaves</source>
        <translation>Não há espaço
para gravar mais chaves</translation>
    </message>
    <message>
        <source>Acerque la llave
para ser grabada</source>
        <translation>Aproxime a chave
para ser gravada</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder
a borrar la llave.
¿Está seguro?</source>
        <translation>A chave 
vai ser apagada.
Continuar?</translation>
    </message>
    <message>
        <source>La llave ya ha
sido grabada antes.</source>
        <translation>A chave foi
gravada anteriormente.</translation>
    </message>
    <message utf8="true">
        <source>Llave leída.
- Código: </source>
        <translation>Chave lida.
- Código: </translation>
    </message>
</context>
<context>
    <name>KeyRecordDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>El usuario no tiene
llave asociada</source>
        <translation>O utilizador não tem
chave associada</translation>
    </message>
    <message>
        <source>Grabar llave</source>
        <translation>Gravar chave</translation>
    </message>
    <message>
        <source>Tipo de llave:</source>
        <translation>Tipo de chave:</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation>Gravar</translation>
    </message>
    <message>
        <source>Grabar
llave</source>
        <translation>Gravar 
chave</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Borrar
llave</source>
        <translation>Apagar
chave</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Aceitar</translation>
    </message>
</context>
<context>
    <name>KeyboardClass</name>
    <message>
        <source>Keyboad</source>
        <translation>Teclado</translation>
    </message>
    <message>
        <source>&gt;&gt;&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>Bloq May</source>
        <translation></translation>
    </message>
    <message>
        <source>L</source>
        <translation></translation>
    </message>
    <message>
        <source>X</source>
        <translation></translation>
    </message>
    <message>
        <source>U</source>
        <translation></translation>
    </message>
    <message>
        <source>Y</source>
        <translation></translation>
    </message>
    <message>
        <source>8</source>
        <translation></translation>
    </message>
    <message>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <source>5</source>
        <translation></translation>
    </message>
    <message>
        <source>W</source>
        <translation></translation>
    </message>
    <message>
        <source>I</source>
        <translation></translation>
    </message>
    <message>
        <source>R</source>
        <translation></translation>
    </message>
    <message>
        <source>B</source>
        <translation></translation>
    </message>
    <message>
        <source>2</source>
        <translation></translation>
    </message>
    <message>
        <source>D</source>
        <translation></translation>
    </message>
    <message>
        <source>4</source>
        <translation></translation>
    </message>
    <message>
        <source>T</source>
        <translation></translation>
    </message>
    <message>
        <source>F</source>
        <translation></translation>
    </message>
    <message>
        <source>3</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Ñ</source>
        <translation></translation>
    </message>
    <message>
        <source>J</source>
        <translation></translation>
    </message>
    <message>
        <source>A</source>
        <translation></translation>
    </message>
    <message>
        <source>V</source>
        <translation></translation>
    </message>
    <message>
        <source>P</source>
        <translation></translation>
    </message>
    <message>
        <source>7</source>
        <translation></translation>
    </message>
    <message>
        <source>H</source>
        <translation></translation>
    </message>
    <message>
        <source>E</source>
        <translation></translation>
    </message>
    <message>
        <source>Q</source>
        <translation></translation>
    </message>
    <message>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <source>C</source>
        <translation></translation>
    </message>
    <message>
        <source>S</source>
        <translation></translation>
    </message>
    <message>
        <source>M</source>
        <translation></translation>
    </message>
    <message>
        <source>6</source>
        <translation></translation>
    </message>
    <message>
        <source>Z</source>
        <translation></translation>
    </message>
    <message>
        <source>K</source>
        <translation></translation>
    </message>
    <message>
        <source>O</source>
        <translation></translation>
    </message>
    <message>
        <source>G</source>
        <translation></translation>
    </message>
    <message>
        <source>9</source>
        <translation></translation>
    </message>
    <message>
        <source>N</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ó</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>é</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ş</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ö</source>
        <translation></translation>
    </message>
    <message>
        <source>&apos;</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Ó</source>
        <translation></translation>
    </message>
    <message>
        <source>_</source>
        <translation></translation>
    </message>
    <message>
        <source>.</source>
        <translation></translation>
    </message>
    <message>
        <source>,</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>É</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ü</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>á</source>
        <translation></translation>
    </message>
    <message>
        <source>@</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ú</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Í</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Ç</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Ú</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ǧ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Á</source>
        <translation></translation>
    </message>
    <message>
        <source>*</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ç</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>í</source>
        <translation></translation>
    </message>
    <message>
        <source>#</source>
        <translation></translation>
    </message>
    <message>
        <source>-</source>
        <translation></translation>
    </message>
    <message>
        <source>y</source>
        <translation></translation>
    </message>
    <message>
        <source>s</source>
        <translation></translation>
    </message>
    <message>
        <source>f</source>
        <translation></translation>
    </message>
    <message>
        <source>j</source>
        <translation></translation>
    </message>
    <message>
        <source>v</source>
        <translation></translation>
    </message>
    <message>
        <source>t</source>
        <translation></translation>
    </message>
    <message>
        <source>b</source>
        <translation></translation>
    </message>
    <message>
        <source>z</source>
        <translation></translation>
    </message>
    <message>
        <source>c</source>
        <translation></translation>
    </message>
    <message>
        <source>k</source>
        <translation></translation>
    </message>
    <message>
        <source>i</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ñ</source>
        <translation></translation>
    </message>
    <message>
        <source>r</source>
        <translation></translation>
    </message>
    <message>
        <source>g</source>
        <translation></translation>
    </message>
    <message>
        <source>w</source>
        <translation></translation>
    </message>
    <message>
        <source>a</source>
        <translation></translation>
    </message>
    <message>
        <source>x</source>
        <translation></translation>
    </message>
    <message>
        <source>p</source>
        <translation></translation>
    </message>
    <message>
        <source>l</source>
        <translation></translation>
    </message>
    <message>
        <source>m</source>
        <translation></translation>
    </message>
    <message>
        <source>n</source>
        <translation></translation>
    </message>
    <message>
        <source>h</source>
        <translation></translation>
    </message>
    <message>
        <source>u</source>
        <translation></translation>
    </message>
    <message>
        <source>d</source>
        <translation></translation>
    </message>
    <message>
        <source>q</source>
        <translation></translation>
    </message>
    <message>
        <source>o</source>
        <translation></translation>
    </message>
    <message>
        <source>e</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ف</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ى</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ح</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ه</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ا</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ع</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>خ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ي</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>م</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ة</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ض</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ب</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ص</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ت</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ث</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>و</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ش</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ق</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>لا</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ؤ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>س</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ن</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>غ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ك</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ل</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ر</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ئ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ء</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ظ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ز</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>د</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ج</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ط</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٨</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٤</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٣</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٧</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ذ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>١</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٢</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٩</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٦</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٥</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
</context>
<context>
    <name>LicenseSystem</name>
    <message>
        <source>Introduzca licencia...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>La licencia caducará en %1 días. 
Para poder seguir usando el sistema Vivimat III deberá llamar a su instalador para que le proporcione una licencia 
 válida. Deberá indicarle el número de licencia que aparece a continuación para poder activar el sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Número de licencia:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licencia....</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LightControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estado desconhecido</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
    <message>
        <source>Presencia</source>
        <translation>Presença</translation>
    </message>
    <message>
        <source>Crepuscular</source>
        <translation>Crepuscular</translation>
    </message>
    <message>
        <source>Crep + Pres</source>
        <translation>Crep + Pres</translation>
    </message>
    <message>
        <source>Pres + Prog</source>
        <translation>Pres + Prog</translation>
    </message>
</context>
<context>
    <name>LightControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associado:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <source>Consigna en modo presencia:</source>
        <translation>Setpoint em modo presença:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo de funcionamento:</translation>
    </message>
    <message>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <source>Sensor de presencia asociado:</source>
        <translation>Sensor de presença associado:</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la desactivación:</source>
        <translation>Atraso da ativação:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Mudar o icon</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>todos</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>inicio</source>
        <translation>inicial</translation>
    </message>
    <message>
        <source>---</source>
        <translation></translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation>videoporteiro</translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation>segurança</translation>
    </message>
    <message>
        <source>escenas</source>
        <translation>cenários</translation>
    </message>
    <message>
        <source>mensajes</source>
        <translation>mensagens</translation>
    </message>
    <message>
        <source>configurar</source>
        <translation>configurar</translation>
    </message>
    <message>
        <source>clima</source>
        <translation>climatização</translation>
    </message>
    <message utf8="true">
        <source>cámaras</source>
        <translation>câmaras</translation>
    </message>
    <message>
        <source>programas</source>
        <translation>programas</translation>
    </message>
    <message>
        <source>alarmas</source>
        <translation>alarmes</translation>
    </message>
    <message>
        <source>historial</source>
        <translation>historial</translation>
    </message>
    <message>
        <source>fotos</source>
        <translation>fotos</translation>
    </message>
    <message>
        <source>pizarra</source>
        <translation>Quadro</translation>
    </message>
    <message>
        <source>sos</source>
        <translation>sos</translation>
    </message>
    <message utf8="true">
        <source>No es posible visualizar las cámaras porque ya están siendo visualizadas en otro terminal.</source>
        <translation>Não é possivel visualizar as câmaras porque estão a ser visualizadas noutro painel.</translation>
    </message>
    <message utf8="true">
        <source>Cámaras ocupadas</source>
        <translation>Câmaras ocupadas</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar</source>
        <translation>Introduza contra-senha para desarmar</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para menú de seguridad</source>
        <translation>Introduza contra-senha para aceder ao menu de segurança</translation>
    </message>
    <message>
        <source>Antes de poder usar los mensajes de voz es necesario tener grabados los mensajes personales.</source>
        <translation>Antes de poder usar  as mensagens de voz devem ser registadas as mensagens pessoais.</translation>
    </message>
    <message>
        <source>Mensajes personales sin grabar</source>
        <translation>Mensagens pessoais sem gravar</translation>
    </message>
    <message>
        <source>LUN </source>
        <translation>SEG </translation>
    </message>
    <message>
        <source>MAR </source>
        <translation>TER </translation>
    </message>
    <message>
        <source>MIE </source>
        <translation>QUA </translation>
    </message>
    <message>
        <source>JUE </source>
        <translation>QUI </translation>
    </message>
    <message>
        <source>VIE </source>
        <translation>SEX </translation>
    </message>
    <message>
        <source>SAB </source>
        <translation>SAB </translation>
    </message>
    <message>
        <source>DOM </source>
        <translation>DOM </translation>
    </message>
    <message>
        <source>dd/MM/yyyy</source>
        <translation>dd/MM/yyyy</translation>
    </message>
    <message utf8="true">
        <source>INT %1 ºC</source>
        <translation>INT %1 ºC</translation>
    </message>
    <message utf8="true">
        <source>Los ficheros de configuración no coinciden.
Para sobreescribir los ficheros de la central en la pantalla pulsa Aceptar. En caso contrario, pulsa Cancelar.</source>
        <translation>Os ficheiros de configuração não coincidem.
Para substituir os ficheiros da central no painel prima Aceitar. Caso contrario, prima Cancelar.</translation>
    </message>
    <message utf8="true">
        <source>Actualizar configuración</source>
        <translation>Actualizar configuração</translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código IR:
%1 %2 %3</source>
        <translation>Foi lido o código IR:
%1 %2 %3</translation>
    </message>
    <message utf8="true">
        <source>Código IR leído</source>
        <translation>Código IV lido</translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código RFID:
%1 %2 %3 %4</source>
        <translation>Foi lido o código RFID:
%1 %2 %3 %4</translation>
    </message>
    <message utf8="true">
        <source>Llave leída</source>
        <translation>Chave lida</translation>
    </message>
    <message utf8="true">
        <source>El idioma del sistema ha sido modificado.
¿Desea reiniciar la pantalla?</source>
        <translation>O idioma do sistema foi modificado.
Deseja reiniciar o painel?</translation>
    </message>
    <message>
        <source>Actualizar idioma...</source>
        <translation>Actualizar idioma...</translation>
    </message>
    <message utf8="true">
        <source>Cerrar sesión</source>
        <translation>Fechar sessão</translation>
    </message>
    <message>
        <source>Sistema bloqueado</source>
        <translation>Sistema travar</translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 90 segundos.</source>
        <translation>Sistema bloqueado após três tentativas falharam entrada de senha. Para voltar a digitar a senha esperar 90 segundos.</translation>
    </message>
</context>
<context>
    <name>MainWindowClass</name>
    <message>
        <source>MainWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>12:30</source>
        <translation>12:30</translation>
    </message>
    <message>
        <source>MAR 15/11/2009</source>
        <translation>MAR 15/11/2009</translation>
    </message>
    <message utf8="true">
        <source>INT 18ºC</source>
        <translation>INT 18ºC</translation>
    </message>
    <message>
        <source>T</source>
        <translation type="obsolete">T</translation>
    </message>
    <message>
        <source>LL</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>MessageDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Aceitar</translation>
    </message>
</context>
<context>
    <name>MessagesWindow</name>
    <message>
        <source>Tipo</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Origen</source>
        <translation>Origem</translation>
    </message>
    <message>
        <source>Fecha/Hora</source>
        <translation>Data/Hora</translation>
    </message>
    <message>
        <source>Videoportero</source>
        <translation>Videoporteiro</translation>
    </message>
    <message>
        <source>Terminal 1</source>
        <translation>Painel 1</translation>
    </message>
    <message>
        <source>Terminal 2</source>
        <translation>Painel 2</translation>
    </message>
    <message>
        <source>Terminal 3</source>
        <translation>Painel 3</translation>
    </message>
    <message>
        <source>Desconocido</source>
        <translation>Desconhecido</translation>
    </message>
    <message>
        <source>Voz</source>
        <translation>Voz</translation>
    </message>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>Não é possível gravar a mensagem, as mensagens de voz estão em uso.</translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation>Mensagens de voz em uso</translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation>Gravando a mensagem...</translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>Não é possível reproduzir a mensagem, as mensagens de voz estão em uso.</translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation>Reproduzindo a mensagem...</translation>
    </message>
    <message utf8="true">
        <source>No es posible borrar los mensajes, los mensajes de voz ya están siendo usados.</source>
        <translation>Não é possível apagar as mensagens, as mensagens de voz estão em uso.</translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation>A mensagem vai ser eliminada.
Continuar?</translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation>Eliminar a mensagem...</translation>
    </message>
</context>
<context>
    <name>MessagesWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Grabar
mensaje</source>
        <translation>Gravar
mensagem</translation>
    </message>
    <message>
        <source>Borrar
mensajes</source>
        <translation>Apagar 
mensagens</translation>
    </message>
</context>
<context>
    <name>MsgProgressDialogClass</name>
    <message>
        <source>RecWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Parar</source>
        <translation>Parar</translation>
    </message>
</context>
<context>
    <name>PasswordClass</name>
    <message>
        <source>Password</source>
        <translation>Palavra-passe</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para continuar...</source>
        <translation>Introduza contra-senha para continuar...</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>5</source>
        <translation></translation>
    </message>
    <message>
        <source>6</source>
        <translation></translation>
    </message>
    <message>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <source>2</source>
        <translation></translation>
    </message>
    <message>
        <source>3</source>
        <translation></translation>
    </message>
    <message>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <source>7</source>
        <translation></translation>
    </message>
    <message>
        <source>8</source>
        <translation></translation>
    </message>
    <message>
        <source>9</source>
        <translation></translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>4</source>
        <translation></translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialog</name>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>Não é possível gravar a mensagem, as mensagens de voz estão em uso.</translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation>Mensagens de voz em uso</translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation>A mensagem vai ser eliminada.
Continuar?</translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation>Eliminar a mensagem...</translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation>Gravando a mensagem...</translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>Não é possível reproduzir a mensagem, as mensagens de voz estão em uso.</translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation>Reproduzindo a mensagem...</translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Mensajes de voz personalizados</source>
        <translation>Mensagens de voz personalizadas</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Aceitar</translation>
    </message>
    <message>
        <source>Mensaje para llamadas de alarma</source>
        <translation>Mensagem para as chamadas de alarme</translation>
    </message>
    <message>
        <source>Reproducir</source>
        <translation>Reproduzir</translation>
    </message>
    <message>
        <source>Grabar</source>
        <translation>Gravar</translation>
    </message>
    <message>
        <source>Mensaje para contestador de videoportero</source>
        <translation>Mensagem de resposta para videoporteiro</translation>
    </message>
    <message utf8="true">
        <source>Para grabar los mensajes de voz personalizados primero se borraran todos los mensajes, después se grabará el mensaje para llamadas de alarma y a continuación el mensaje para contestador de videoportero.</source>
        <translation>Para gravar as mensagens de voz personalizadas primeiro serão apagadas todas as mensagens, em seguida, se grava a mensagem para as chamadas de alarme e respectivamente a mensagem de resposta para o videoporteiro.</translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindow</name>
    <message>
        <source>Tipo</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message utf8="true">
        <source>Número</source>
        <translation>Número</translation>
    </message>
    <message>
        <source>TEL</source>
        <translation>TEL</translation>
    </message>
    <message>
        <source>SMS</source>
        <translation>SMS</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>CRA</source>
        <translation>CRA</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
    <message>
        <source>Es necesario introducir primero el tipo de contacto.</source>
        <translation>É necessário introduzir primeiro o tipo de contacto.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Erro...</translation>
    </message>
    <message utf8="true">
        <source>Introduzca nuevo número o dirección de correo ...</source>
        <translation>Introduza novo número ou endereço de e-mail ...</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el contacto.
¿Está seguro?</source>
        <translation>O contacto será eliminado.
Continuar?</translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation>Eliminar o contacto...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Falta introduzir dados.</translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindowClass</name>
    <message>
        <source>PhoneConfigWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Habilitar avisos</source>
        <translation>Habilitar os avisos</translation>
    </message>
    <message>
        <source>Habilitar telecontrol</source>
        <translation>Habilitar o telecontrolo</translation>
    </message>
    <message>
        <source>Tonos</source>
        <translation>Tons</translation>
    </message>
    <message>
        <source>Configurar
CRA</source>
        <translation>Configurar
CRA</translation>
    </message>
</context>
<context>
    <name>PhotosWindow</name>
    <message>
        <source>Marco de fotos</source>
        <translation>Moldura digital</translation>
    </message>
    <message>
        <source>No hay fotos disponibles.</source>
        <translation>Não há fotos disponíveis.</translation>
    </message>
    <message>
        <source>Reducir la resolucion de la imagen para su correcta visualizacion.</source>
        <translation type="obsolete">Reduzir a resolução da imagem para visualização de imagens.</translation>
    </message>
    <message>
        <source>No se puede mostrar la foto (%1).</source>
        <translation>Não é possível exibir imagem (%1).</translation>
    </message>
</context>
<context>
    <name>PlugControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estado desconhecido</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
</context>
<context>
    <name>PlugControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo de funcionamento:</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associado:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Mudar o icon</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>todos</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>salida temporizada </source>
        <translation type="unfinished">Tempo esgotado</translation>
    </message>
    <message>
        <source>segundos</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindow</name>
    <message>
        <source>Temperatura</source>
        <translation>Temperatura</translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation>0-100%</translation>
    </message>
    <message>
        <source>ON-OFF</source>
        <translation>ON-OFF</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
    <message utf8="true">
        <source>Las franjas horarias no están bien definidas.</source>
        <translation>Os intervalos não estão bem definidos.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Erro...</translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>0 = OFF</source>
        <translation>0 = OFF</translation>
    </message>
    <message>
        <source>1 = ON</source>
        <translation>1 = ON</translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message utf8="true">
        <source>Días de ejecución:</source>
        <translation>Dias de execução:</translation>
    </message>
    <message>
        <source>L</source>
        <translation>2</translation>
    </message>
    <message>
        <source>M</source>
        <translation>3</translation>
    </message>
    <message>
        <source>X</source>
        <translation>4</translation>
    </message>
    <message>
        <source>J</source>
        <translation>5</translation>
    </message>
    <message>
        <source>V</source>
        <translation>6</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <source>Fin</source>
        <translation>Fim</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:mm</translation>
    </message>
    <message>
        <source>Inicio</source>
        <translation>Começar</translation>
    </message>
    <message>
        <source>Consigna</source>
        <translation>Setpoint</translation>
    </message>
    <message>
        <source>Franja 1:</source>
        <translation>Intervalo 1:</translation>
    </message>
    <message>
        <source>Franja 2:</source>
        <translation>Intervalo 2:</translation>
    </message>
    <message>
        <source>Franja 3:</source>
        <translation>Intervalo 3:</translation>
    </message>
    <message>
        <source>Franja 4:</source>
        <translation>Intervalo 4:</translation>
    </message>
    <message>
        <source>Franja 5:</source>
        <translation>Intervalo 5:</translation>
    </message>
</context>
<context>
    <name>ProgramsWindow</name>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>L</source>
        <translation>2</translation>
    </message>
    <message>
        <source>M</source>
        <translation>3</translation>
    </message>
    <message>
        <source>X</source>
        <translation>4</translation>
    </message>
    <message>
        <source>J</source>
        <translation>5</translation>
    </message>
    <message>
        <source>V</source>
        <translation>6</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Temperatura</source>
        <translation>Temperatura</translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation>0-100%</translation>
    </message>
    <message>
        <source>ON/OFF</source>
        <translation>ON/OFF</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el programa.
¿Está seguro?</source>
        <translation>O programa será eliminado.
Continuar?</translation>
    </message>
    <message>
        <source>Eliminar programa...</source>
        <translation>Eliminar o programa...</translation>
    </message>
</context>
<context>
    <name>ProgramsWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>L</source>
        <translation>2</translation>
    </message>
    <message>
        <source>M</source>
        <translation>3</translation>
    </message>
    <message>
        <source>X</source>
        <translation>4</translation>
    </message>
    <message>
        <source>J</source>
        <translation>5</translation>
    </message>
    <message>
        <source>V</source>
        <translation>6</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>RBlindControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>Grupo de toldos</source>
        <translation>Grupo de toldos</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Estado desconhecido</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programa</translation>
    </message>
</context>
<context>
    <name>RBlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programa associado:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <source>Plegar toldos en caso de viento fuerte</source>
        <translation>Recolher os toldos em caso de vento forte</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Tempo de subida / descida:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo de funcionamento:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Mudar o icon</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>todos</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Plegar toldos en caso de lluvia</source>
        <translation type="unfinished">Dobre caso toldosen de chuva</translation>
    </message>
</context>
<context>
    <name>SOSWindow</name>
    <message utf8="true">
        <source>Alarma de pánico deshabilitada</source>
        <translation>Alarme de pânico desabilitado</translation>
    </message>
</context>
<context>
    <name>SOSWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>SOS</source>
        <translation>SOS</translation>
    </message>
    <message>
        <source>STOP</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SceneConditionDialog</name>
    <message>
        <source>Sin condicionar</source>
        <translation>Sem condicionar</translation>
    </message>
    <message>
        <source>Cualquier llave</source>
        <translation>Qualquer chave</translation>
    </message>
    <message>
        <source>Llave tipo A</source>
        <translation>Chave tipo A</translation>
    </message>
    <message>
        <source>Llave tipo B</source>
        <translation>Chave tipo B</translation>
    </message>
    <message>
        <source>Llave tipo C</source>
        <translation>Chave tipo C</translation>
    </message>
    <message>
        <source>Llave tipo D</source>
        <translation>Chave tipo D</translation>
    </message>
    <message>
        <source>Llave tipo E</source>
        <translation>Chave tipo E</translation>
    </message>
    <message>
        <source>Llave tipo F</source>
        <translation>Chave tipo F</translation>
    </message>
    <message>
        <source>Llave: </source>
        <translation>Chave: </translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation>Data</translation>
    </message>
    <message utf8="true">
        <source>Día semana</source>
        <translation>Dia de semana</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión armada</source>
        <translation>Alarme de intrusão armada</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión desarmada</source>
        <translation>Alarme de intrusão Desligado</translation>
    </message>
    <message utf8="true">
        <source>Activación de cualquier alarma</source>
        <translation>Ativação de qualquer alarme</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de intrusión</source>
        <translation>Act. do alarme de intrusão</translation>
    </message>
    <message>
        <source>Act. alm. de fuego</source>
        <translation>Act. do alarme de incêndio</translation>
    </message>
    <message>
        <source>Act. alm. de gas</source>
        <translation>Act. do alarme de gás</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de inundación</source>
        <translation>Act. do alarme de inundação</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de corte eléc.</source>
        <translation>Act. do alarme de corte 230V</translation>
    </message>
    <message>
        <source>Act. alm. de corte tlf.</source>
        <translation>Act. do alarme de corte da linha telefónica </translation>
    </message>
    <message>
        <source>Act. alm. de sistema</source>
        <translation>Act. do alarme do sistema</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. médica</source>
        <translation>Act. do alarme de médico</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de pánico</source>
        <translation>Act. do alarme de pânico</translation>
    </message>
    <message>
        <source>Act. alm. silenciosa</source>
        <translation>Act. do alarme silencioso</translation>
    </message>
    <message>
        <source>Act. alm. de sabotaje</source>
        <translation>Act. do alarme de sabotagem</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de coacción</source>
        <translation>Act. do alarme de coação</translation>
    </message>
    <message>
        <source>Entrada en Central</source>
        <translation>Entrada na central</translation>
    </message>
    <message>
        <source>Entrada en MOD0035</source>
        <translation>Entrada no MOD-0035</translation>
    </message>
    <message>
        <source>Intrusion en armado total</source>
        <translation>intrusão armada total</translation>
    </message>
    <message>
        <source>Intrusion en armado perimetral</source>
        <translation>intrusão armada perimetral</translation>
    </message>
    <message>
        <source>Intrusion en armado parcial</source>
        <translation>intrusão armada parcial</translation>
    </message>
</context>
<context>
    <name>SceneConditionDialogClass</name>
    <message>
        <source>EventConditionWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Condiciones</source>
        <translation>Condições</translation>
    </message>
    <message>
        <source>Condicion de llave:</source>
        <translation>Condição de chave:</translation>
    </message>
    <message>
        <source>Condicion de hora:</source>
        <translation>Condição de hora:</translation>
    </message>
    <message>
        <source>Condicion de Fecha / Dia semana:</source>
        <translation>Condição de Data / Dia de semana:</translation>
    </message>
    <message>
        <source>Condicion de alarma:</source>
        <translation>Condição de alarme:</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:mm</translation>
    </message>
    <message>
        <source>L</source>
        <translation>2</translation>
    </message>
    <message>
        <source>V</source>
        <translation>6</translation>
    </message>
    <message>
        <source>X</source>
        <translation>4</translation>
    </message>
    <message>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <source>M</source>
        <translation>3</translation>
    </message>
    <message>
        <source>J</source>
        <translation>5</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Condicion de entrada:</source>
        <translation>Condição de entrada:</translation>
    </message>
    <message>
        <source>Tipo de modulo:</source>
        <translation>Tipo de módulo:</translation>
    </message>
    <message>
        <source>E/S:</source>
        <translation>E/S:</translation>
    </message>
    <message>
        <source>Mod:</source>
        <translation>Mód:</translation>
    </message>
</context>
<context>
    <name>SceneEventWindow</name>
    <message utf8="true">
        <source>Iluminación</source>
        <translation>Iluminação</translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation>Apa. motorizado</translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation>Tomada</translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation>Climatização</translation>
    </message>
    <message>
        <source>Riego</source>
        <translation>Rega</translation>
    </message>
    <message>
        <source>Retardo</source>
        <translation>Atraso</translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation>Segurança</translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation>Luz individual</translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation>Luzes da zona</translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation>Todas as luzes</translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation>Luz ON/Off</translation>
    </message>
    <message>
        <source>Luz Regulable</source>
        <translation>Luz variável</translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation>Todos os tipos</translation>
    </message>
    <message>
        <source>0%</source>
        <translation>0%</translation>
    </message>
    <message>
        <source>100%</source>
        <translation>100 %</translation>
    </message>
    <message>
        <source>20%</source>
        <translation>20 %</translation>
    </message>
    <message>
        <source>40%</source>
        <translation>40 %</translation>
    </message>
    <message>
        <source>60%</source>
        <translation>60 %</translation>
    </message>
    <message>
        <source>80%</source>
        <translation>80 %</translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation>Tomada individual</translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation>Tomadas da zona</translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation>Todas as tomadas</translation>
    </message>
    <message>
        <source>Encender</source>
        <translation>Ligar</translation>
    </message>
    <message>
        <source>Apagar</source>
        <translation>Desligar</translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation>Climatização individual</translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation>Todas as climatizações</translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation>Desligado</translation>
    </message>
    <message>
        <source>Modo manual</source>
        <translation>Modo MANUAL</translation>
    </message>
    <message>
        <source>Modo programa</source>
        <translation>Modo PROGRAMA</translation>
    </message>
    <message utf8="true">
        <source>Modo económico</source>
        <translation>Modo ECO</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>Riego individual</source>
        <translation>Rega individual</translation>
    </message>
    <message>
        <source>Riegos de la zona</source>
        <translation>Regas da zona</translation>
    </message>
    <message>
        <source>Todos los riegos</source>
        <translation>Todas as regas</translation>
    </message>
    <message>
        <source>Activar</source>
        <translation>Ativar</translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation>Desativar</translation>
    </message>
    <message>
        <source>1 seg</source>
        <translation>1 s</translation>
    </message>
    <message>
        <source>3 seg</source>
        <translation>3 s</translation>
    </message>
    <message>
        <source>5 seg</source>
        <translation>5 s</translation>
    </message>
    <message>
        <source>10 seg</source>
        <translation>10 s</translation>
    </message>
    <message>
        <source>20 seg</source>
        <translation>20 s</translation>
    </message>
    <message>
        <source>30 seg</source>
        <translation>30 s</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation>Alarme de intrusão</translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation>Alarme de incêndio</translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation>Alarme de gás</translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation>Alarme de inundação</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation>Alarme de corte 230V</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte telefónico</source>
        <translation>Alarme de corte da linha telefónica</translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation>Alarme do sistema</translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation>Alarme médico</translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation>Alarme de pânico</translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation>Alarme silencioso</translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation>Alarme de sabotagem</translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation>Armar em modo perímetro</translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation>Armar em modo parcial</translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation>Armar em modo total</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Desarmar</translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation>Desarmar parcial</translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation>Ativar o alarme</translation>
    </message>
    <message>
        <source>Dis. individual</source>
        <translation>Dis. individual</translation>
    </message>
    <message>
        <source>Dis. de la zona</source>
        <translation>Dis. da zona</translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation>Todos os dispositivos</translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation>Estore normal</translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation>Estore posicional</translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation>Estores agrupados</translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation>Qualquer estore</translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation>Toldo normal</translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation>Toldo posicional</translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation>Toldos agrupados</translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation>Qualquer toldo</translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation>Cortina normal</translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation>Cortina posicional</translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation>Cortinas agrupadas</translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation>Qualquer cortina</translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation>Porta motorizada</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Enchufe normal</source>
        <translation type="unfinished">Dispositivo não cronometrada</translation>
    </message>
    <message>
        <source>Enchufes temporizados</source>
        <translation type="unfinished">dispositivo Temporário</translation>
    </message>
</context>
<context>
    <name>SceneEventWindowClass</name>
    <message>
        <source>SceneEventWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Modificar evento</source>
        <translation>Modificar o evento</translation>
    </message>
    <message>
        <source>Tipo de evento:</source>
        <translation>Tipo de evento:</translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation>Tipo de controlo:</translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation>Tipo de elemento:</translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation>Elemento:</translation>
    </message>
    <message>
        <source>Valor:</source>
        <translation>Valor:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindow</name>
    <message>
        <source>Evento</source>
        <translation>Evento</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el evento.
¿Está seguro?</source>
        <translation>O evento será eliminado.
Continuar?</translation>
    </message>
    <message>
        <source>Eliminar evento...</source>
        <translation>Eliminar o evento...</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
    <message utf8="true">
        <source>Iluminación</source>
        <translation>Iluminação</translation>
    </message>
    <message>
        <source> - ON/OFF</source>
        <translation> - ON/OFF</translation>
    </message>
    <message>
        <source> - Regulable</source>
        <translation> - Variável</translation>
    </message>
    <message>
        <source> - RGB</source>
        <translation> - RGB</translation>
    </message>
    <message>
        <source> - Todos los tipos</source>
        <translation> - Todos os tipos</translation>
    </message>
    <message>
        <source> - Individual: </source>
        <translation> - Individual: </translation>
    </message>
    <message>
        <source> - Zona: </source>
        <translation> - Zona: </translation>
    </message>
    <message>
        <source> - Todas las luces</source>
        <translation> - Todas as luzes</translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation>Dis. motorizado</translation>
    </message>
    <message>
        <source> - Persiana normal</source>
        <translation> - Estore normal</translation>
    </message>
    <message>
        <source> - Persiana posicional</source>
        <translation> - Estore posicional</translation>
    </message>
    <message>
        <source> - Persianas agupadas</source>
        <translation> - Estores agrupados</translation>
    </message>
    <message>
        <source> - Cualquier persiana</source>
        <translation> - Qualquer estore</translation>
    </message>
    <message>
        <source> - Toldo normal</source>
        <translation> - Toldo normal</translation>
    </message>
    <message>
        <source> - Toldo posicional</source>
        <translation> - Toldo posicional</translation>
    </message>
    <message>
        <source> - Toldos agupados</source>
        <translation> - Toldos agrupados</translation>
    </message>
    <message>
        <source> - Cualquier toldo</source>
        <translation> - Qualquer toldo</translation>
    </message>
    <message>
        <source> - Cortina normal</source>
        <translation> - Cortina normal</translation>
    </message>
    <message>
        <source> - Cortina posicional</source>
        <translation> - Cortina posicional</translation>
    </message>
    <message>
        <source> - Cortinas agupadas</source>
        <translation> - Cortinas agrupadas</translation>
    </message>
    <message>
        <source> - Cualquier cortina</source>
        <translation> - Qualquer cortina</translation>
    </message>
    <message>
        <source> - Puerta motorizada</source>
        <translation> - Porta motorizada</translation>
    </message>
    <message>
        <source> - Todos los dispositivos</source>
        <translation> - Todos os dispositivos</translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation>Tomada</translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation> - Todas as tomadas</translation>
    </message>
    <message>
        <source> - Encender</source>
        <translation> - Ligar</translation>
    </message>
    <message>
        <source> - Apagar</source>
        <translation> - Desligar</translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation>Climatização</translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation> - Todos os climatizadores</translation>
    </message>
    <message>
        <source> - Apagado</source>
        <translation> - Desligado</translation>
    </message>
    <message>
        <source> - Modo manual - </source>
        <translation> - Modo manual - </translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source> - Modo programa</source>
        <translation> - Modo programa</translation>
    </message>
    <message utf8="true">
        <source> - Modo económico - </source>
        <translation> - Modo eco - </translation>
    </message>
    <message>
        <source>Riego</source>
        <translation>Rega</translation>
    </message>
    <message>
        <source> - Todos los riegos</source>
        <translation> - Todas as regas</translation>
    </message>
    <message>
        <source> - Activar</source>
        <translation> - Ativar</translation>
    </message>
    <message>
        <source> - Desactivar</source>
        <translation> - Desativar</translation>
    </message>
    <message>
        <source>Retardo - </source>
        <translation>Atraso - </translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation>Segurança</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation>Alarme de intrusão</translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation>Alarme de incêndio</translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation>Alarme de gás</translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation>Alarme de inundação</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation>Alarme de corte 230V</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte de teléfono</source>
        <translation>Alarme de Corte de linha telefónica</translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation>Alarme do sistema</translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation>Alarme médico</translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation>Alarme de Pânico</translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation>Alarme silencioso</translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation>Alarme de sabotagem</translation>
    </message>
    <message utf8="true">
        <source>Alarma de coacción</source>
        <translation>Alarme de coação</translation>
    </message>
    <message>
        <source>Deshabilitar alarma</source>
        <translation>Desabilitar o alarme</translation>
    </message>
    <message>
        <source>Habilitar alarma</source>
        <translation>Habilitar o alarme</translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation>Ativar o alarme</translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation>Armar em modo perímetro</translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation>Armar em modo parcial</translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation>Armar em modo total</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Desarmar</translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation>Desarmar parcial</translation>
    </message>
    <message>
        <source> - Todos </source>
        <translation type="unfinished">- Tudo</translation>
    </message>
    <message>
        <source> - Temporizados </source>
        <translation type="obsolete">- Temporário</translation>
    </message>
    <message>
        <source> - No temporizados</source>
        <translation type="unfinished">- Não temporário</translation>
    </message>
    <message>
        <source> - Temporizados</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindowClass</name>
    <message>
        <source>ScenesConfigWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renomear</translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindow</name>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la escena.
¿Está seguro?</source>
        <translation>O cenário será eliminado.
Continuar?</translation>
    </message>
    <message>
        <source>Eliminar escena...</source>
        <translation>Eliminar o cenário...</translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>ScenesWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindow</name>
    <message>
        <source>Castellano</source>
        <translation>Castelhano</translation>
    </message>
    <message utf8="true">
        <source>Inglés</source>
        <translation>Inglês</translation>
    </message>
    <message utf8="true">
        <source>Portugués</source>
        <translation>Português</translation>
    </message>
    <message utf8="true">
        <source>Francés</source>
        <translation>Francês</translation>
    </message>
    <message utf8="true">
        <source>Alemán</source>
        <translation>Alemão</translation>
    </message>
    <message>
        <source>Euskera</source>
        <translation>Euskera</translation>
    </message>
    <message utf8="true">
        <source>Catalán</source>
        <translation>Catalão</translation>
    </message>
    <message>
        <source>Gallego</source>
        <translation>Galego</translation>
    </message>
    <message>
        <source>Turco</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Italiano</source>
        <translation>Italiano</translation>
    </message>
    <message utf8="true">
        <source>Árabe</source>
        <translation>Árabe</translation>
    </message>
    <message>
        <source>0 %</source>
        <translation>0 %</translation>
    </message>
    <message>
        <source>20 %</source>
        <translation>20 %</translation>
    </message>
    <message>
        <source>40 %</source>
        <translation>40 %</translation>
    </message>
    <message>
        <source>60 %</source>
        <translation>60 %</translation>
    </message>
    <message>
        <source>80 %</source>
        <translation>80 %</translation>
    </message>
    <message>
        <source>100 %</source>
        <translation>100 %</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation type="obsolete">Escuro</translation>
    </message>
    <message>
        <source>Green</source>
        <translation type="obsolete">Verde</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>Laranja</translation>
    </message>
    <message>
        <source>Azul</source>
        <translation type="unfinished">Azul</translation>
    </message>
    <message>
        <source>Negro</source>
        <translation type="unfinished">Preto</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation>Verde</translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation type="unfinished">Vermelho</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>Marco de fotos digital</source>
        <translation>Moldura de fotos digitais</translation>
    </message>
    <message>
        <source>1 minuto</source>
        <translation>1 minuto</translation>
    </message>
    <message>
        <source>2 minuto</source>
        <translation>2 minutos</translation>
    </message>
    <message>
        <source>5 minuto</source>
        <translation>5 minutos</translation>
    </message>
    <message>
        <source>10 minuto</source>
        <translation>10 minutos</translation>
    </message>
    <message>
        <source>15 minuto</source>
        <translation>15 minutos</translation>
    </message>
    <message>
        <source>30 minuto</source>
        <translation>30 minutos</translation>
    </message>
    <message>
        <source>Nunca</source>
        <translation>Nunca</translation>
    </message>
    <message utf8="true">
        <source>Botón</source>
        <translation>Botão</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Ação</translation>
    </message>
    <message>
        <source>Oscuro</source>
        <translation>Escuro</translation>
    </message>
    <message>
        <source>(vacio)</source>
        <translation>(vazio)</translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <source> Identificador de pantalla</source>
        <translation> Identificação de painel</translation>
    </message>
    <message>
        <source> Idioma</source>
        <translation> Idioma</translation>
    </message>
    <message>
        <source> Volumen</source>
        <translation> Volume</translation>
    </message>
    <message>
        <source> Brillo</source>
        <translation type="obsolete"> Brilho</translation>
    </message>
    <message>
        <source>Sonido teclado</source>
        <translation>Som do teclado</translation>
    </message>
    <message>
        <source>Sensor de presencia</source>
        <translation>Sensor de presença</translation>
    </message>
    <message>
        <source> Paleta</source>
        <translation> Paleta</translation>
    </message>
    <message>
        <source> Color iconos</source>
        <translation> Cor dos icons</translation>
    </message>
    <message>
        <source>Offset de temperatura</source>
        <translation>Offset da temperatura</translation>
    </message>
    <message>
        <source>Visualizar cursor</source>
        <translation>Visualizar o cursor</translation>
    </message>
    <message>
        <source>Salvapantallas</source>
        <translation>Screensavers</translation>
    </message>
    <message>
        <source> Salvapantallas</source>
        <translation> Screensavers</translation>
    </message>
    <message utf8="true">
        <source> Activación Salvapantallas</source>
        <translation> Ativação Screensaver</translation>
    </message>
    <message>
        <source> Tiempo entre fotos</source>
        <translation> Tempo entre fotos</translation>
    </message>
    <message>
        <source> Autoapagado</source>
        <translation> Auto OFF</translation>
    </message>
    <message>
        <source>Botones</source>
        <translation>Botões</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para ejecutar escenas</source>
        <translation>Exigir senha para executar cenas</translation>
    </message>
    <message utf8="true">
        <source>Habilitación tamper</source>
        <translation type="unfinished">Ativar adulteração</translation>
    </message>
    <message>
        <source>IP</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindow</name>
    <message>
        <source>Armado total</source>
        <translation>Armar total</translation>
    </message>
    <message>
        <source>Armado parcial</source>
        <translation>Armar parcial</translation>
    </message>
    <message>
        <source>Armado perimetral</source>
        <translation>Armar perímetro</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Nenhum</translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Intrusión</source>
        <translation>Intrusão</translation>
    </message>
    <message utf8="true">
        <source>Habilitar autoarmado de intrusión</source>
        <translation>Habilitar o auto-armado da intrusão</translation>
    </message>
    <message>
        <source>Programa asociado el autoarmado</source>
        <translation>Programa associado ao auto-armado</translation>
    </message>
    <message utf8="true">
        <source>Activar simulación de presencia con el armado total</source>
        <translation>Ativar simulação de presença com armado total</translation>
    </message>
    <message>
        <source>Tiempo de salida de la vivienda (seg):</source>
        <translation>Tempo mínimo para armar (seg):</translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para armar la alarma de intrusión</source>
        <translation>Pedir senha para armar o alarme de intrusão</translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation>Incêndio</translation>
    </message>
    <message>
        <source>Gas</source>
        <translation>Gás</translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation>Inundação</translation>
    </message>
    <message utf8="true">
        <source>Hora de auto limpieza de la electroválvula de agua:</source>
        <translation>Hora de auto-limpeza da válvula de agua:</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:mm</translation>
    </message>
    <message utf8="true">
        <source>Corte Red Eléctrica</source>
        <translation>Corte 230V</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (min):</source>
        <translation>Atraso à ativação (min):</translation>
    </message>
    <message utf8="true">
        <source>Corte teléfono</source>
        <translation>Corte de linha telefónica</translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation>Sistema</translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation>Médico</translation>
    </message>
    <message utf8="true">
        <source>Detección de inactividad</source>
        <translation>Deteção de inatividade</translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation>Pânico</translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation>Silenciosa</translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation>Sabotagem</translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation>Coação</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Llamar en caso de alarma a:</source>
        <translation>Chamar em caso de alarme a:</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 1</source>
        <translation>Telefone 1</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 2</source>
        <translation>Telefone 2</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 3</source>
        <translation>Telefone 3</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 4</source>
        <translation>Telefone 4</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 5</source>
        <translation>Telefone 5</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 6</source>
        <translation>Telefone 6</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 7</source>
        <translation>Telefone 7</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 8</source>
        <translation>Telefone 8</translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation>Mensagens 
pessoais</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (seg):</source>
        <translation type="unfinished">Ativação retardada (seg):</translation>
    </message>
</context>
<context>
    <name>SecurityWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Armado Perimetral</source>
        <translation>Armado Perímetro</translation>
    </message>
    <message>
        <source>Armado Parcial</source>
        <translation>Armado Parcial</translation>
    </message>
    <message>
        <source>Armado Total</source>
        <translation>Armado Total</translation>
    </message>
</context>
<context>
    <name>SensorControl</name>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
</context>
<context>
    <name>SensorControlClass</name>
    <message>
        <source>SensorControl</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Deshabilitar sensor</source>
        <translation>Desabilitar o sensor</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <source>Interviene en el armado parcial</source>
        <translation>Intervém em armado parcial</translation>
    </message>
    <message>
        <source>Interviene en el armado perimetral</source>
        <translation>Intervém em armado perímetro</translation>
    </message>
    <message>
        <source>Tiempo de entrada:</source>
        <translation>Tempo de entrada:</translation>
    </message>
    <message>
        <source>Offset de temperatura:</source>
        <translation>Offset da temperatura:</translation>
    </message>
    <message>
        <source>Retraso a la activacion:</source>
        <translation>Atraso à ativação:</translation>
    </message>
</context>
<context>
    <name>SystemConfigWindow</name>
    <message utf8="true">
        <source>Se va a proceder a importar ficheros.
Por favor, no saque el dispositivo durante la importación.
 ¿Desea continuar?</source>
        <translation>Vai se proceder à importação de ficheiros.
Por favor, não retire o dispositivo
durante a importação. Continuar?</translation>
    </message>
    <message>
        <source>Importando...</source>
        <translation>A importar...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a exportar ficheros.
Por favor, no saque el dispositivo durante la exportación.
¿Desea continuar?</source>
        <translation>Vai se proceder à exportação de ficheiros.
Por favor, não retire o dispositivo
durante a exportação. Continuar?</translation>
    </message>
    <message>
        <source>Exportando...</source>
        <translation>A exportar...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Firmware.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation>Vai se proceder à actualização do Firmware.
Por favor, nao retire o dispositivo
durante a actualização. Continuar?</translation>
    </message>
    <message>
        <source>Actualizando...</source>
        <translation>A actualizar...</translation>
    </message>
    <message utf8="true">
        <source>Para proceder a calibrar el touch es necesario reiniciar la pantalla.
¿Desea continuar?</source>
        <translation>O painel terá que ser reiniciado para se calibrar a sensibilidade. 
Continuar?</translation>
    </message>
    <message>
        <source>Calibrar Touch...</source>
        <translation>Sensibilidade em calibração...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Webserver.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation>Ele vai continuar a atualizar o servidor web.
Por favor, não remova o dispositivo durante a atualização.
  Continuar?</translation>
    </message>
    <message>
        <source>Test Alarmas: %1
Pulse para %2</source>
        <translation>Teste de Alarme: %1
Pressione para %2</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation>Desativar</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>Activar</source>
        <translation>Ativar</translation>
    </message>
    <message>
        <source>Activar licencia</source>
        <translation type="unfinished">Ativar licença</translation>
    </message>
</context>
<context>
    <name>SystemConfigWindowClass</name>
    <message>
        <source>SystemConfigWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Reset del Sistema</source>
        <translation>Reset do Sistema</translation>
    </message>
    <message>
        <source>Exportar Ficheros</source>
        <translation>Exportar Ficheiros</translation>
    </message>
    <message>
        <source>Importar  Ficheros</source>
        <translation>Importar Ficheiros</translation>
    </message>
    <message>
        <source>Actualizar Firmware</source>
        <translation type="obsolete">Actualizar Firmware</translation>
    </message>
    <message>
        <source>Acceder como
instalador</source>
        <translation>conectar-se como
 um instalador</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Recalibrar Touch</source>
        <translation>Calibrar sensibilidade</translation>
    </message>
    <message>
        <source>Actualizar
Firmware</source>
        <translation>atualizar
 Firmware</translation>
    </message>
    <message>
        <source>Log de Errores</source>
        <translation>registo de erros</translation>
    </message>
    <message>
        <source>Actualizar
WebServer</source>
        <translation>atualizar
WebServer</translation>
    </message>
    <message>
        <source>Prueba de alarmas: %1
Pulse para %2</source>
        <translation>Teste de Alarme: %1
Pressione para %2</translation>
    </message>
    <message>
        <source>Test llamadas CRA</source>
        <translation>Teste chama CRA</translation>
    </message>
    <message>
        <source>Licencia...</source>
        <translation type="unfinished">Licença...</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UsersConfigWindow</name>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Clave</source>
        <translation>Chave</translation>
    </message>
    <message>
        <source>Nivel Acceso</source>
        <translation>Nivel de Acesso</translation>
    </message>
    <message>
        <source>Maestro</source>
        <translation>Administrador</translation>
    </message>
    <message>
        <source>Alto</source>
        <translation>Alto</translation>
    </message>
    <message>
        <source>Medio</source>
        <translation>Médio</translation>
    </message>
    <message>
        <source>Bajo</source>
        <translation>Baixo</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduza um novo nome ...</translation>
    </message>
    <message utf8="true">
        <source>Introduzca la nueva contraseña</source>
        <translation>Digite a nova senha</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el usuario.
¿Está seguro?</source>
        <translation>O utilizador será eliminado.
Continuar?</translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation>Eliminar o contacto...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Falta preencher dados.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Erro...</translation>
    </message>
    <message utf8="true">
        <source>No se puede eliminar el único usuario maestro del sistema.</source>
        <translation type="unfinished">Não é possível excluir o único mestre do usuário do sistema.</translation>
    </message>
    <message utf8="true">
        <source>Eliminación de usuario interrumpida.</source>
        <translation type="unfinished">Excluindo usuário interrompido.</translation>
    </message>
</context>
<context>
    <name>UsersConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Leer Llave</source>
        <translation>ler a chave</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>WarningDialog</name>
    <message utf8="true">
        <source>Fallo en el sistema de avisos telefónicos.</source>
        <translation>Falha no sistema de avisos telefónicos.</translation>
    </message>
    <message>
        <source>Test de CRA fallido.</source>
        <translation>O teste para CRA falhou.</translation>
    </message>
    <message utf8="true">
        <source>Aviso de cancelación de alarma de intrusión fallido.</source>
        <translation>Falha no aviso de cancelamento do alarme de intrusão.</translation>
    </message>
    <message utf8="true">
        <source>Armado de intrusión cancelado. Sensor no temporizado activo:
%1</source>
        <translation>Cancelado o armar da intrusão. Sensor não temporizado activo:
%1</translation>
    </message>
    <message>
        <source>Climatizador apagado por ventana abierta:
%1</source>
        <translation>Climatização desligada pela janela aberta:
%1</translation>
    </message>
    <message>
        <source>Entrada de sensor en circuito abierto:
%1</source>
        <translation>Entrada do sensor em circuito aberto:
%1</translation>
    </message>
    <message utf8="true">
        <source>Cámara de videoportería ocupada.</source>
        <translation>Câmera do videoporteiro ocupada.</translation>
    </message>
    <message>
        <source>No se ha encontrado el mensaje que se desea reproducir.</source>
        <translation>A mensagem que quer reproduzir não foi encontrada.</translation>
    </message>
    <message utf8="true">
        <source>No hay espacio para grabar más mensajes de voz, o se ha alcanzado el límite de 10 mensajes.</source>
        <translation>Não há espaço para gravar mais mensagens de voz, ou já foi atingido o limite de 10 mensagens.</translation>
    </message>
    <message utf8="true">
        <source>Mensaje de Aviso Nº%1</source>
        <translation>Mensagem de Aviso Nº%1</translation>
    </message>
    <message utf8="true">
        <source>Error en la comunicación con el módulo %1:
Comando rechazado.</source>
        <translation>Erro de comunicação com o módulo %1:
Comando recusou.</translation>
    </message>
    <message>
        <source>Error al iniciar el sistema de ficheros. Compruebe si la tarjeta SD de la central funciona correctamente.</source>
        <translation>Falha ao iniciar o sistema de arquivos. Verifique se o cartão SD está funcionando corretamente planta.</translation>
    </message>
    <message utf8="true">
        <source>El estado de la batería es bajo.</source>
        <translation>O estado da bateria é baixo.</translation>
    </message>
    <message utf8="true">
        <source>Perdidas de tramas en la comunicación.</source>
        <translation>Perdas na estrutura de comunicação.</translation>
    </message>
    <message utf8="true">
        <source>Comunicación recuperada.</source>
        <translation>Comunicação recuperado.</translation>
    </message>
    <message utf8="true">
        <source>No hay batería o la batería falla.</source>
        <translation>Sem bateria ou falha de bateria.</translation>
    </message>
    <message>
        <source>Iniciando el test de CRA...</source>
        <translation type="obsolete">Iniciar o teste CRA ...</translation>
    </message>
    <message>
        <source>El test CRA ha sido satisfactorio.</source>
        <translation>O teste de PCR foi bem sucedida.</translation>
    </message>
    <message utf8="true">
        <source>Número de mensaje desconocido %1</source>
        <translation>Número de mensagem desconhecido %1</translation>
    </message>
    <message>
        <source>Test de CRA...</source>
        <translation>Teste CRA...</translation>
    </message>
</context>
<context>
    <name>WarningDialogClass</name>
    <message>
        <source>WarningDialog</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation></translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Apagar</translation>
    </message>
</context>
<context>
    <name>ZoneSelect</name>
    <message>
        <source>luces</source>
        <translation>luzes</translation>
    </message>
    <message>
        <source>clima</source>
        <translation>climatização</translation>
    </message>
    <message>
        <source>dispositivos</source>
        <translation>tomadas</translation>
    </message>
    <message>
        <source>persianas</source>
        <translation>estores</translation>
    </message>
    <message>
        <source>cortinas</source>
        <translation>cortinas</translation>
    </message>
    <message>
        <source>puertas</source>
        <translation>portas</translation>
    </message>
    <message>
        <source>riegos</source>
        <translation>regas</translation>
    </message>
    <message>
        <source>toldos</source>
        <translation>toldos</translation>
    </message>
    <message>
        <source>sensores</source>
        <translation>sensores</translation>
    </message>
</context>
<context>
    <name>ZoneSelectClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
</context>
</TS>
