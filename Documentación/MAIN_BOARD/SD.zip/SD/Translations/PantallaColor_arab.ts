<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AlarmDialog</name>
    <message utf8="true">
        <source>ALARMA DE INTRUSIÓN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALARMA DE FUEGO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALARMA DE GAS</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE INUNDACIÓN</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE ELÉCTRICO</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE TELEFÓNICO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALARMA DE SISTEMA</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ALARMA MÉDICA</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE PÁNICO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALARMA SILENCIOSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALARMA DE SABOTAJE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>REARMAR ALARMAS</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar alarmas</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE COACCIÓN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
 en las siguientes zonas:
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hay alarmas desarmadas. Pulse rearmar para volver a proteger el sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 90 segundos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sistema bloqueado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AlarmDialogClass</name>
    <message>
        <source>AlarmDialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6</source>
        <translation type="obsolete">6</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="obsolete">3</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>8</source>
        <translation type="obsolete">8</translation>
    </message>
    <message>
        <source>9</source>
        <translation type="obsolete">9</translation>
    </message>
    <message>
        <source>4</source>
        <translation type="obsolete">4</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <source>5</source>
        <translation type="obsolete">5</translation>
    </message>
    <message>
        <source>Introduzca clave de acceso</source>
        <translation type="obsolete">أدخل رمز الدخول</translation>
    </message>
    <message>
        <source>7</source>
        <translation type="obsolete">7</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation type="unfinished"> نزع جهاز الإنذار </translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation type="unfinished">&lt;&lt;</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation type="unfinished">&gt;&gt;</translation>
    </message>
    <message>
        <source>Rearmar</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Menú
Alarmas</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AlarmsWindow</name>
    <message>
        <source>---</source>
        <translation>تشغيل</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>تشغيل</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>إيقاف </translation>
    </message>
</context>
<context>
    <name>AlarmsWindowClass</name>
    <message>
        <source>Form</source>
        <translation>الصّيغة</translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation>حريق</translation>
    </message>
    <message>
        <source>Gas</source>
        <translation>غاز </translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation>طوفان </translation>
    </message>
    <message utf8="true">
        <source>Corte de Red Eléctrica</source>
        <translation type="obsolete">إنقطاع التيار الكهربائي</translation>
    </message>
    <message utf8="true">
        <source>Corte de teléfono</source>
        <translation type="obsolete">Telephone fail</translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation>النّظام</translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation>الطّبّيّة</translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation>هلع</translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation>كتم الصّوت</translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation>تخريب   </translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation>Textlabel</translation>
    </message>
    <message utf8="true">
        <source>Corte de Teléfono</source>
        <translation>إنقطاع خطّ الهاتف</translation>
    </message>
    <message utf8="true">
        <source>Corte Eléctrico</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ArmingWindowClass</name>
    <message>
        <source>Form</source>
        <translation>الصّيغة</translation>
    </message>
    <message>
        <source>Armando...</source>
        <translation>تشغيل جهاز الإنذر </translation>
    </message>
</context>
<context>
    <name>AssociatedZones</name>
    <message>
        <source>Zonas asociadas</source>
        <translation type="obsolete">Associated zones</translation>
    </message>
</context>
<context>
    <name>AssociatedZonesClass</name>
    <message>
        <source>AssociatedZones</source>
        <translation>المناطق المرتبطة بوحدة التحكم بالمناخ</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>تخفيض </translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق  </translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>تصعيد</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message utf8="true">
        <source>Indique las zonas de la vivienda asociadas con la unidad climática ...</source>
        <translation type="obsolete">Indicate zones associated to the climate control unit</translation>
    </message>
    <message utf8="true">
        <source>Zonas asociadas con la unidad climática...</source>
        <translation>المناطق المرتبطة بوحدة التحكم بالمناخ</translation>
    </message>
</context>
<context>
    <name>AudioVideoConfigWindow</name>
    <message>
        <source>Modo visualizacion 1</source>
        <translation type="obsolete">طريقة النظرة 1</translation>
    </message>
    <message>
        <source>Modo visualizacion 2</source>
        <translation type="obsolete">طريقة النظرة 2</translation>
    </message>
    <message>
        <source>Modo visualizacion 3</source>
        <translation type="obsolete">طريقة النظرة 3</translation>
    </message>
</context>
<context>
    <name>AudioVideoConfigWindowClass</name>
    <message>
        <source>Aplicar</source>
        <translation type="obsolete">تطبيق  </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="obsolete">إغلاق </translation>
    </message>
    <message>
        <source>Y/N</source>
        <translation type="obsolete">نعم/كلّا</translation>
    </message>
    <message>
        <source>Dispositivo</source>
        <translation type="obsolete">الجهاز </translation>
    </message>
    <message>
        <source>Visualizacion</source>
        <translation type="obsolete">إلقاء نظرة </translation>
    </message>
</context>
<context>
    <name>AudioVideoWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">الصّيغة</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation type="obsolete">تصعيد</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation type="obsolete">تخفيض </translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="obsolete">2</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="obsolete">3</translation>
    </message>
    <message>
        <source>4</source>
        <translation type="obsolete">4</translation>
    </message>
    <message>
        <source>5</source>
        <translation type="obsolete">5</translation>
    </message>
    <message>
        <source>6</source>
        <translation type="obsolete">6</translation>
    </message>
    <message>
        <source>7</source>
        <translation type="obsolete">7</translation>
    </message>
    <message>
        <source>8</source>
        <translation type="obsolete">8</translation>
    </message>
    <message>
        <source>9</source>
        <translation type="obsolete">9</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>Channel</source>
        <translation type="obsolete">القناة</translation>
    </message>
    <message>
        <source>+</source>
        <translation type="obsolete">+</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="obsolete">الصوت</translation>
    </message>
    <message>
        <source>SELECT</source>
        <translation type="obsolete">إختيار</translation>
    </message>
    <message>
        <source>MENU</source>
        <translation type="obsolete">القائمة</translation>
    </message>
    <message>
        <source>EXIT</source>
        <translation type="obsolete">الخروج</translation>
    </message>
    <message>
        <source>EJECT</source>
        <translation type="obsolete">طرد</translation>
    </message>
    <message>
        <source>Tune</source>
        <translation type="obsolete">تفتيش</translation>
    </message>
</context>
<context>
    <name>BarometerWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">الصّيغة</translation>
    </message>
</context>
<context>
    <name>BlackboardWindowClass</name>
    <message>
        <source>BlackboardWindow</source>
        <translation>لوح تدوين الملاحظات </translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation>تحفيظ </translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>إلغاء </translation>
    </message>
</context>
<context>
    <name>BlindControl</name>
    <message>
        <source>Manual</source>
        <translation>غير اتوماتيكي</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>برمجة </translation>
    </message>
    <message>
        <source>Arriba</source>
        <translation type="obsolete">إلى أعلى</translation>
    </message>
    <message>
        <source>Abajo</source>
        <translation type="obsolete">إلى أسفل</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>أدخل الإسم الجديد</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished">لا شيء </translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grupo de persianas</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>الأنظمة المترابطة</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>إعادة تسمية</translation>
    </message>
    <message>
        <source>Bajar persianas en caso de lluvia</source>
        <translation>إنزال الأباجور في حال هطول الأمطار</translation>
    </message>
    <message>
        <source>Consigna en modo programa:</source>
        <translation type="obsolete">نقطة الإرتكاز المبرمجة</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>نظام التشغيل</translation>
    </message>
    <message>
        <source>%</source>
        <translation type="obsolete">%</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message>
        <source>zona</source>
        <translation>المنطقة </translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>الجهاز </translation>
    </message>
    <message>
        <source>todos</source>
        <translation>الكل</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajar persianas en caso de viento fuerte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DOWN</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CRAConfigDialog</name>
    <message>
        <source>ADEMCO CID</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Introduzca el código de abonado ...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CRAConfigDialogClass</name>
    <message>
        <source>CRAConfigDialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuracion CRA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Habilitacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar
Codigo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Protocolo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autotest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cadencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hora del primer test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Codigo de cuenta</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CamsWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CamsWindowClass</name>
    <message>
        <source>Form</source>
        <translation>أعلى</translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation>تكلم</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>فتح  </translation>
    </message>
    <message>
        <source>+</source>
        <translation type="obsolete">+</translation>
    </message>
    <message>
        <source>-</source>
        <translation type="obsolete">-</translation>
    </message>
    <message>
        <source>&lt;</source>
        <translation type="obsolete">&lt;</translation>
    </message>
    <message>
        <source>&gt;</source>
        <translation type="obsolete">&gt;</translation>
    </message>
    <message>
        <source>^</source>
        <translation type="obsolete">^</translation>
    </message>
    <message>
        <source>v</source>
        <translation type="obsolete">v</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation>رفع الصوت </translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation>تخفيض الصوت</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>أعلى</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>أسفل</translation>
    </message>
    <message>
        <source>Izquierda</source>
        <translation>يسار </translation>
    </message>
    <message>
        <source>Derecha</source>
        <translation>يمين  </translation>
    </message>
</context>
<context>
    <name>ClimaControl</name>
    <message utf8="both">
        <source>Frío</source>
        <translation type="unfinished">Cold</translation>
    </message>
    <message>
        <source>Calor</source>
        <translation>حرّ</translation>
    </message>
    <message>
        <source>Climatizador</source>
        <translation>تحكم بالمناخ  </translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>أدخل الإسم الجديد</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished">لا شيء </translation>
    </message>
</context>
<context>
    <name>ClimaControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Modo general:</source>
        <translation>نظام التشغيل العام </translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation type="obsolete"> البرنامج  المترابط </translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>إعادة تسمية</translation>
    </message>
    <message utf8="true">
        <source>Apagar climatización en caso de ventana abierta</source>
        <translation>إطفاء برنامج التحكم بالمناخ في حال وجود نافذة مفتوحة </translation>
    </message>
    <message>
        <source>Consigna Min:</source>
        <translation type="obsolete">القيمة الأدنى المبرمجة</translation>
    </message>
    <message>
        <source>Consigna Max:</source>
        <translation type="obsolete">القيمة الأقصى المبرمجة </translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source>Zonas Asociadas</source>
        <translation type="obsolete">المناطق المترابطة </translation>
    </message>
    <message>
        <source>Consigna en modo programa:</source>
        <translation type="obsolete">القيمة المبرمجة </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق </translation>
    </message>
    <message>
        <source>modo</source>
        <translation>نظام التشغيل </translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message utf8="true">
        <source>0ºC</source>
        <translation>0ºC</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sensor de temperatura asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Histeresis:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Primer programa asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Consig. Min:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Consig. Max:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zonas
Asociadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Segundo programa asociado:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClimaWindow</name>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
</context>
<context>
    <name>ClimaWindowClass</name>
    <message>
        <source>Form</source>
        <translation>الصيغة </translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>إطفاء </translation>
    </message>
    <message>
        <source>MANUAL</source>
        <translation>غير اتوماتيكي</translation>
    </message>
    <message>
        <source>PROGRAMA</source>
        <translation>البرنامج</translation>
    </message>
    <message>
        <source>ECO</source>
        <translation>إقتصادي </translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="obsolete">Textlabel</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message utf8="true">
        <source>20ºC</source>
        <translation type="obsolete">20ºC</translation>
    </message>
    <message utf8="true">
        <source>23ºC</source>
        <translation type="obsolete">23ºC</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>تخفيض</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>تصعيد </translation>
    </message>
    <message utf8="true">
        <source>--ºC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>--</source>
        <translation type="unfinished">--</translation>
    </message>
</context>
<context>
    <name>Communication</name>
    <message utf8="true">
        <source>Los ficheros de configuración no coinciden.
Para sobreescribir los ficheros de la central en la pantalla
pulsa Aceptar. En caso contrario, pulsa Cancelar.</source>
        <translation type="obsolete">Configuration files are different.
To overwrite the central&apos;s files into the display
click Accept. Otherwise, click Cancel</translation>
    </message>
    <message utf8="true">
        <source>Actualizar configuración</source>
        <translation type="obsolete">Configuration update</translation>
    </message>
</context>
<context>
    <name>ConfigWindow</name>
    <message utf8="true">
        <source>Vivimat III

versión 1.0.0</source>
        <translation type="obsolete">Vivimat III

version 1.0.0</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión 1.0.0</source>
        <translation type="obsolete">Vision Color 7

version 1.0.0</translation>
    </message>
    <message utf8="true">
        <source>Vivimat III

versión %1.%2.%3

[%4]</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión 0.6.4</source>
        <translation type="obsolete">Vision Color 7

version 0.6.4 {7
?}</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión %1.%2.%3
</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Sistema de ficheros

Versión: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Vivimat III

versión Demo %1.%2.%3

[%4]</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión Demo %1.%2.%3
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;Vivimat III&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;versión 1.0.0&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;Vivimat III&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;version 1.0.0&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;Vision Color 7&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;versión 1.0.0&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;Vision Color 7&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;version 1.0.0&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>mando IR</source>
        <translation>جهاز التحكم عن بعد </translation>
    </message>
    <message>
        <source>programas horarios</source>
        <translation>برامج التوقيت  </translation>
    </message>
    <message>
        <source>multimedia</source>
        <translation>وسائط متعددة </translation>
    </message>
    <message utf8="true">
        <source>gestión de energía</source>
        <translation>إدارة الطاقة</translation>
    </message>
    <message>
        <source>escenas</source>
        <translation>سيناريو </translation>
    </message>
    <message utf8="true">
        <source>telefonía</source>
        <translation>التليفون </translation>
    </message>
    <message>
        <source>usuarios</source>
        <translation>المستخدم  </translation>
    </message>
    <message>
        <source>sistema</source>
        <translation>النظام </translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation>الأمن</translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation>النظام المرئي لمراقبة الدخول</translation>
    </message>
    <message>
        <source>fecha y hora</source>
        <translation>التاريخ والتوقيت</translation>
    </message>
    <message>
        <source>pantalla</source>
        <translation>الشاشة   </translation>
    </message>
    <message utf8="true">
        <source>Vivimat III

versión 1.0.0</source>
        <translation type="obsolete">Vivimat III

version 1.0.0</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión 1.0.0</source>
        <translation type="obsolete">Vision Color 7

version 1.0.0</translation>
    </message>
</context>
<context>
    <name>ConfirmationDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation>ConfirmationWindow</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية : qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>قبول </translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>إلغاء  </translation>
    </message>
</context>
<context>
    <name>ConfirmationWindowClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation type="obsolete">ConfirmationWindow</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="obsolete">Accept</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="obsolete">Cancel</translation>
    </message>
</context>
<context>
    <name>ConsumptionWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Escala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Semana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mes</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Año</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unidades</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unit3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConsumptionsConfigWindow</name>
    <message>
        <source>Visualizacion</source>
        <translation type="obsolete">View</translation>
    </message>
    <message>
        <source>S/N</source>
        <translation type="obsolete">نعم/كلّا</translation>
    </message>
    <message>
        <source>Diario</source>
        <translation type="obsolete">يومي</translation>
    </message>
    <message>
        <source>Semanal</source>
        <translation type="obsolete">أسبوعي   </translation>
    </message>
    <message>
        <source>Mensual</source>
        <translation type="obsolete">شهري</translation>
    </message>
    <message>
        <source>Anual</source>
        <translation type="obsolete">سنوي </translation>
    </message>
    <message>
        <source>Ultima factura</source>
        <translation type="obsolete">Last bill</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="obsolete">2</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="obsolete">3</translation>
    </message>
    <message>
        <source>4</source>
        <translation type="obsolete">4</translation>
    </message>
    <message>
        <source>5</source>
        <translation type="obsolete">5</translation>
    </message>
    <message>
        <source>6</source>
        <translation type="obsolete">6</translation>
    </message>
    <message>
        <source>7</source>
        <translation type="obsolete">7</translation>
    </message>
    <message>
        <source>8</source>
        <translation type="obsolete">8</translation>
    </message>
    <message>
        <source>9</source>
        <translation type="obsolete">9</translation>
    </message>
    <message>
        <source>10</source>
        <translation type="obsolete">10</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="obsolete">أدخل الإسم الجديد </translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Prioridad</source>
        <translation type="obsolete">الأولويّة</translation>
    </message>
    <message>
        <source>Coste/Unidad</source>
        <translation type="obsolete">كلفة الوحدة </translation>
    </message>
    <message>
        <source>Alarma</source>
        <translation type="obsolete">تحذير  </translation>
    </message>
    <message>
        <source>Umbral alarma</source>
        <translation type="obsolete">العتبة </translation>
    </message>
    <message>
        <source>euros
/unidad</source>
        <translation type="obsolete">يورو لكل وحدة </translation>
    </message>
    <message>
        <source>Modificar fecha ultima factura</source>
        <translation type="obsolete">Modify date of last bill</translation>
    </message>
    <message utf8="true">
        <source>Visualización</source>
        <translation type="obsolete">إلقاء نظرة </translation>
    </message>
    <message utf8="true">
        <source>Contaminación CO2</source>
        <translation type="obsolete">تلوّث ثاني أوكسيد الكربون </translation>
    </message>
    <message utf8="true">
        <source>Última factura</source>
        <translation type="obsolete">الفاتورة الأخيرة </translation>
    </message>
    <message>
        <source>m3</source>
        <translation type="obsolete">m3</translation>
    </message>
    <message>
        <source>SUBCIRCUITO </source>
        <translation type="obsolete">SUBCIRCUIT</translation>
    </message>
    <message utf8="true">
        <source>Modificar fecha última factura</source>
        <translation type="obsolete">تعديل تاريخ الفاتورة الأخيرة </translation>
    </message>
</context>
<context>
    <name>ConsumptionsConfigWindowClass</name>
    <message>
        <source>GAS</source>
        <translation type="obsolete">غاز </translation>
    </message>
    <message>
        <source>AGUA</source>
        <translation type="obsolete">مياه </translation>
    </message>
    <message>
        <source>ELECTRICIDAD</source>
        <translation type="obsolete">الكهرباء </translation>
    </message>
    <message>
        <source>SUBCIRCUITO 1</source>
        <translation type="obsolete">SUBCIRCUIT 1</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 2</source>
        <translation type="obsolete">SUBCIRCUIT 2</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 3</source>
        <translation type="obsolete">SUBCIRCUIT 3</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 4</source>
        <translation type="obsolete">SUBCIRCUIT 4</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 5</source>
        <translation type="obsolete">SUBCIRCUIT 5</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 6</source>
        <translation type="obsolete">SUBCIRCUIT 6</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 7</source>
        <translation type="obsolete">SUBCIRCUIT 7</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 8</source>
        <translation type="obsolete">SUBCIRCUIT 8</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 9</source>
        <translation type="obsolete">SUBCIRCUIT 9</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 10</source>
        <translation type="obsolete">SUBCIRCUIT 10</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="obsolete">تطبيق </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="obsolete">إغلاق</translation>
    </message>
    <message>
        <source>Fecha
ultima factura</source>
        <translation type="obsolete">تاريخ الفاتورة الأخيرة </translation>
    </message>
</context>
<context>
    <name>ConsumptionsDisplayWindow</name>
    <message>
        <source>Consumo diario</source>
        <translation type="obsolete">الإستهلاك اليومي </translation>
    </message>
    <message>
        <source>Consumo semanal</source>
        <translation type="obsolete">الإستهلاك الأسبوعي </translation>
    </message>
    <message>
        <source>Consumo mensual</source>
        <translation type="obsolete">الإستهلاك الشهري</translation>
    </message>
    <message>
        <source>Consumo anual</source>
        <translation type="obsolete">الإستهلاك السنوي  </translation>
    </message>
    <message utf8="true">
        <source>Consumo desde última factura</source>
        <translation type="obsolete">الإستهلاك منذ الفاتورة الأخيرة </translation>
    </message>
    <message>
        <source> m3</source>
        <translation type="obsolete">m3</translation>
    </message>
    <message>
        <source> Kw</source>
        <translation type="obsolete">Kw</translation>
    </message>
    <message>
        <source> L</source>
        <translation type="obsolete">L</translation>
    </message>
    <message>
        <source>Consumo desde ultima factura</source>
        <translation type="obsolete">الإستهلاك منذ الفاتورة الأخيرة </translation>
    </message>
</context>
<context>
    <name>ConsumptionsDisplayWindowClass</name>
    <message>
        <source>ConsumptionsDisplayWindow</source>
        <translation type="obsolete">ملفّ الإستهلاك</translation>
    </message>
    <message>
        <source>Consumo diario</source>
        <translation type="obsolete">Daily consumption</translation>
    </message>
    <message>
        <source>Consumo semanal</source>
        <translation type="obsolete">Weekly consumption</translation>
    </message>
    <message>
        <source>Consumo mensual</source>
        <translation type="obsolete">Monthly consumption</translation>
    </message>
    <message>
        <source>Consumo anual</source>
        <translation type="obsolete">Yearly consumption</translation>
    </message>
    <message>
        <source>Consumo desde ultima factura</source>
        <translation type="obsolete">Consumption since last bill</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="obsolete">Textlabel</translation>
    </message>
</context>
<context>
    <name>ConsumptionsWindow</name>
    <message>
        <source>GAS
12l</source>
        <translation type="obsolete">GAS
12l</translation>
    </message>
    <message>
        <source>AGUA
55m3</source>
        <translation type="obsolete">WATER
55m3</translation>
    </message>
    <message>
        <source>ELECTRICIDAD
172Kw</source>
        <translation type="obsolete">ELECTRICITY
172Kw</translation>
    </message>
    <message>
        <source>SUBCIRCUITO </source>
        <translation type="obsolete">الدّورة الكهربائيّة  </translation>
    </message>
    <message>
        <source>
Consumo diario:</source>
        <translation type="obsolete">الإستهلاك اليومي  </translation>
    </message>
    <message>
        <source>
1 L</source>
        <translation type="obsolete">
1 L</translation>
    </message>
    <message>
        <source>
0.09 m3</source>
        <translation type="obsolete">
0.09 m3</translation>
    </message>
    <message>
        <source>
155 Kw</source>
        <translation type="obsolete">
155 Kw</translation>
    </message>
    <message>
        <source>
Consumo semanal:</source>
        <translation type="obsolete">الإستهلاك الأسبوعي</translation>
    </message>
    <message>
        <source>
2.3 L</source>
        <translation type="obsolete">
2.3 L</translation>
    </message>
    <message>
        <source>
0.27 m3</source>
        <translation type="obsolete">
0.27 m3</translation>
    </message>
    <message>
        <source>
680 Kw</source>
        <translation type="obsolete">
680 Kw</translation>
    </message>
    <message>
        <source>
Consumo mensual:</source>
        <translation type="obsolete">الإستهلاك الشّهري</translation>
    </message>
    <message>
        <source>
7.1 L</source>
        <translation type="obsolete">
7.1 L</translation>
    </message>
    <message>
        <source>
0.63 m3</source>
        <translation type="obsolete">
0.63 m3</translation>
    </message>
    <message>
        <source>
1182 Kw</source>
        <translation type="obsolete">
1182 Kw</translation>
    </message>
    <message>
        <source>
Consumo anual:</source>
        <translation type="obsolete">الإستهلاك السّنوي</translation>
    </message>
    <message>
        <source>
84.7 L</source>
        <translation type="obsolete">
84.7 L</translation>
    </message>
    <message>
        <source>
3.82 m3</source>
        <translation type="obsolete">
3.82 m3</translation>
    </message>
    <message>
        <source>
5711 Kw</source>
        <translation type="obsolete">
5711 Kw</translation>
    </message>
    <message utf8="true">
        <source>
Consumo última factura:</source>
        <translation type="obsolete">
الإستهلاك منذ الفاتورة الأخيرة </translation>
    </message>
    <message>
        <source>
4.9 L</source>
        <translation type="obsolete">
4.9 L</translation>
    </message>
    <message>
        <source>
0.21 m3</source>
        <translation type="obsolete">
0.21 m3</translation>
    </message>
    <message>
        <source>
711 Kw</source>
        <translation type="obsolete">
711 Kw</translation>
    </message>
    <message>
        <source>CIRC. </source>
        <translation type="obsolete">الدئرة الكهربائية</translation>
    </message>
</context>
<context>
    <name>ConsumptionsWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">الصّيغة</translation>
    </message>
</context>
<context>
    <name>CurtainControl</name>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished">لا شيء </translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grupo de cortinas</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CurtainControlClass</name>
    <message>
        <source>CurtainControl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zona</source>
        <translation type="unfinished">المنطقة </translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>todos</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DateHourWindow</name>
    <message>
        <source>Lunes</source>
        <translation>الإثنين </translation>
    </message>
    <message>
        <source>Martes</source>
        <translation>الثّلاثاء</translation>
    </message>
    <message utf8="both">
        <source>Miércoles</source>
        <translation type="unfinished">Wednesday</translation>
    </message>
    <message>
        <source>Jueves</source>
        <translation>الخميس </translation>
    </message>
    <message>
        <source>Viernes</source>
        <translation>الجمعة</translation>
    </message>
    <message utf8="both">
        <source>Sábado</source>
        <translation type="unfinished">Saturday</translation>
    </message>
    <message>
        <source>Domingo</source>
        <translation>الأحد  </translation>
    </message>
</context>
<context>
    <name>DateHourWindowClass</name>
    <message>
        <source>Form</source>
        <translation>الصّيغة</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>/</source>
        <translation>/</translation>
    </message>
    <message>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
</context>
<context>
    <name>DoorControl</name>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished">لا شيء </translation>
    </message>
    <message>
        <source>Abierta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DoorControlClass</name>
    <message>
        <source>DoorControl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo de apertura / cierre:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zona</source>
        <translation type="unfinished">المنطقة </translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DoorphoneDialog</name>
    <message>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llamada VIDEOPORTERO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llamada desde videoportero</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conserje no contesta.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación, otra lladama en curso.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conserge ocupado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindowClass</name>
    <message>
        <source>Form</source>
        <translation>الصّيغة</translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation>تكلّم</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>فتح </translation>
    </message>
    <message>
        <source>+</source>
        <translation type="obsolete">+</translation>
    </message>
    <message>
        <source>-</source>
        <translation type="obsolete">-</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation type="obsolete">تخفيض الصّوت</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation type="obsolete">رفع  الصّوت</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>تخفيض </translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>تصعيد </translation>
    </message>
    <message utf8="true">
        <source>Portería</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ver</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EntryphoneConfigWindow</name>
    <message>
        <source>Grabando mensaje...</source>
        <translation type="obsolete">تسجيل الرّسالة</translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation type="obsolete">سماع الرّسالة</translation>
    </message>
</context>
<context>
    <name>EntryphoneConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>الصّيغة</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message>
        <source>Grabar</source>
        <translation type="obsolete">تسجيل </translation>
    </message>
    <message>
        <source>Reproducir</source>
        <translation type="obsolete">السّماع</translation>
    </message>
    <message utf8="true">
        <source>Habilitar Desvío</source>
        <translation>تفعيل التّحويل</translation>
    </message>
    <message>
        <source>Habilitar Contestador</source>
        <translation>تفعيل عاملة الهاتف</translation>
    </message>
    <message utf8="true">
        <source>Contacto al que se
desvía la llamada:</source>
        <translation type="obsolete">تحويل الإتّصال إلى...</translation>
    </message>
    <message>
        <source>Juan</source>
        <translation type="obsolete">Kemal</translation>
    </message>
    <message>
        <source>Pedro</source>
        <translation type="obsolete">Nicola</translation>
    </message>
    <message>
        <source>Mensaje para contestador</source>
        <translation type="obsolete">الرّجاء ترك رسالة</translation>
    </message>
    <message utf8="true">
        <source>Contacto al que se desvía la llamada:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Habilitar llamada desde puerta de entrada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Número de veces que sonara: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileTransfer</name>
    <message>
        <source>Aplicacion DEMO para Windows.Simulando la transferencia de ficheros.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Se ha encontrado una tarjeta SD.No saque la tarjeta hasta que finalice el intercambio de ficheros.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Se ha encontrado un dispositivo USB.No saque el dispositivo hasta que finalice el intercambio de ficheros.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No se ha encontrado ningún dispositivo.Pulsa cancelar para salir.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>La actualización ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>La exportación ha finalizado.Pulsa Aceptar para continuar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>La importación ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No existe un fichero de firmware. Inserte un dispositivo con un fichero de firmware.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error a la hora de copiar el nuevo firmware.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No se encuentran todos los ficheros necesarios para la actualizacion del servidor web.
No se ha podido realizar la actualización.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>La actualización ha fallado. Se mantiene el viejo rcS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cp -rf %1/PantallaColor /App/PantallaColor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileTransferClass</name>
    <message>
        <source>FileTransfer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FloorSelectClass</name>
    <message>
        <source>Form</source>
        <translation>الصّيغة</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>تخفيض </translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>تصعيد </translation>
    </message>
</context>
<context>
    <name>HistoryWindow</name>
    <message>
        <source>Mensaje</source>
        <translation type="obsolete">الرّسالة</translation>
    </message>
    <message>
        <source>Fecha/Hora</source>
        <translation type="obsolete">التّاريخ والتّوقيت</translation>
    </message>
    <message>
        <source>Historial de Eventos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Historial de Errores</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HistoryWindowClass</name>
    <message>
        <source>Form</source>
        <translation>الصّيغة</translation>
    </message>
    <message>
        <source>Mensaje</source>
        <translation type="obsolete">الرّسالة</translation>
    </message>
    <message>
        <source>Fecha / Hora</source>
        <translation type="obsolete">التّاريخ والتّوقيت</translation>
    </message>
    <message utf8="true">
        <source>Alm. intrusión armada por Eugenio</source>
        <translation type="obsolete">جهاز الإقتحام  المفعّل من قبل محمّد</translation>
    </message>
    <message>
        <source>05/01/2008 9:50</source>
        <translation type="obsolete">2008/01/05 9:50</translation>
    </message>
    <message utf8="true">
        <source>Alm. intrusión en Salón</source>
        <translation type="obsolete">جهاز الإقتحام الغرفة الجلوس </translation>
    </message>
    <message>
        <source>05/01/2008 9:55</source>
        <translation type="obsolete">2008/01/05 9:55</translation>
    </message>
    <message utf8="true">
        <source>Alm. intrusión desarmada</source>
        <translation type="obsolete">تعطيل جهاز الإقتحام </translation>
    </message>
    <message>
        <source>05/01/2008 10:45</source>
        <translation type="obsolete">2008/01/05 10:45</translation>
    </message>
    <message utf8="true">
        <source>Alm. Pánico activada</source>
        <translation type="obsolete">تفعيل جهاز الهلع </translation>
    </message>
    <message>
        <source>10/01/2008 9:50</source>
        <translation type="obsolete">2008/01/10 9:50</translation>
    </message>
    <message utf8="true">
        <source>Alm. Pánico desactivada</source>
        <translation type="obsolete">تعطيل جهاز الهلع</translation>
    </message>
    <message>
        <source>11/01/2008 13:50</source>
        <translation type="obsolete">2008/01/11 13:50</translation>
    </message>
    <message>
        <source>Historial de Eventos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>01/01/2010 13:39:05 &gt; System initialization completed
01/01/2010 13:45:15 &gt; Intrusion alarm armed in total mode: Sergio
01/01/2010 13:50:05 &gt; Intrusion alarm disarmed: Sergio
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IRCodeReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Apunte el mando hacia el
receptor y pulse la tecla
correspondiente...</source>
        <translation>جهاز التّحكّم المباشر نحو المتلقّي عبر ضغط المفتاح المناسب</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق   </translation>
    </message>
    <message utf8="true">
        <source>Leer código de infrarrojos</source>
        <translation>IRقرآءة رمز ال</translation>
    </message>
    <message>
        <source>R</source>
        <translation type="obsolete">R</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية  : qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindow</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation>تنفيذ السّيناريو</translation>
    </message>
    <message>
        <source>Arm. Intr. Peri.</source>
        <translation type="obsolete">Arm. Peripheral Intr.</translation>
    </message>
    <message utf8="both">
        <source>Activar pánico</source>
        <translation type="unfinished">Activate panic</translation>
    </message>
    <message>
        <source>Abrir puerta</source>
        <translation type="obsolete">فتح الباب  </translation>
    </message>
    <message utf8="both">
        <source>Cambiar cámara</source>
        <translation type="obsolete">Switch camera</translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation type="unfinished">Light on</translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation type="unfinished">Light off</translation>
    </message>
    <message>
        <source>Subir persiana</source>
        <translation type="obsolete">Raise blind</translation>
    </message>
    <message>
        <source>Bajar persiana</source>
        <translation type="obsolete">Lower blind</translation>
    </message>
    <message>
        <source>Encender clima</source>
        <translation type="unfinished">Climate control on</translation>
    </message>
    <message>
        <source>Apagar clima</source>
        <translation type="unfinished">Climate control off</translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation type="unfinished">Plug on</translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation type="unfinished">Plug off</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>أدخل الإسم الجديد </translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>الإسم </translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>حركة </translation>
    </message>
    <message utf8="true">
        <source>Código IR</source>
        <translation>IRرمز ال</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>الرّجاء إدخال المعلومات النّاقصة...</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>خلل </translation>
    </message>
    <message>
        <source>Luz ON</source>
        <translation type="obsolete">النّور مضاء</translation>
    </message>
    <message>
        <source>Luz OFF</source>
        <translation type="obsolete">النّور مطفأ</translation>
    </message>
    <message>
        <source>Incrementar luz</source>
        <translation type="obsolete">زيادة مستوى الإنارة </translation>
    </message>
    <message>
        <source>Decrementar luz</source>
        <translation type="obsolete">تخفيض مستوى الإنارة</translation>
    </message>
    <message>
        <source>Subir elemento motorizado</source>
        <translation type="obsolete">رفع العنصر المزوِّد للحركة</translation>
    </message>
    <message>
        <source>Bajar elemento motorizado</source>
        <translation type="obsolete">تخفيض العنصر المزوّد للحركة</translation>
    </message>
    <message>
        <source>Clima ON</source>
        <translation type="obsolete">نظام التّحكّم بالمناخ شغّال</translation>
    </message>
    <message>
        <source>Clima OFF</source>
        <translation type="obsolete">نظام التّحكّم بالمناخ مطفأ</translation>
    </message>
    <message>
        <source>Enchufe ON</source>
        <translation type="obsolete">المقبس  شغّال</translation>
    </message>
    <message>
        <source>Enchufe OFF</source>
        <translation type="obsolete">المقبس  مطفأ</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la acción.
¿Está seguro?</source>
        <translation>العمليّة على وشك المحو ... هل تودّ الإستئناف؟ </translation>
    </message>
    <message utf8="true">
        <source>Eliminar acción...</source>
        <translation>إلغاء العمليّة</translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Individual - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Zona - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Individual - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Zona - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - ON/OFF -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Regulable -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - RGB -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los tipos -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Todas las luces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Persiana normal -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Persiana posicional -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Persianas agupadas -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cualquier persiana -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Toldo normal -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Toldo posicional -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Toldos agupados -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cualquier toldo -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cortina normal -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cortina posicional -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cortinas agupadas -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cualquier cortina -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Puerta motorizada -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Conmutar cámara</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>الصّيغة</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>الإسم </translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation> العمليّة </translation>
    </message>
    <message utf8="true">
        <source>Código</source>
        <translation>الرّمز</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق      </translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialog</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation>تنفيذ سيناريو </translation>
    </message>
    <message>
        <source>Arm. Intr. Peri.</source>
        <translation type="obsolete">Arm. Peripheral Intr.</translation>
    </message>
    <message utf8="true">
        <source>Activar pánico</source>
        <translation>تشغيل الهلع</translation>
    </message>
    <message>
        <source>Abrir puerta</source>
        <translation type="obsolete">فتح الباب </translation>
    </message>
    <message utf8="true">
        <source>Cambiar cámara</source>
        <translation type="obsolete">Switch camera</translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation type="unfinished">Light on</translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation type="unfinished">Light off</translation>
    </message>
    <message>
        <source>Subir persiana</source>
        <translation type="obsolete">Raise blind</translation>
    </message>
    <message>
        <source>Bajar persiana</source>
        <translation type="obsolete">Lower blind</translation>
    </message>
    <message>
        <source>Encender clima</source>
        <translation type="obsolete">Climate control on</translation>
    </message>
    <message>
        <source>Apagar clima</source>
        <translation type="obsolete">Climate control off</translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation type="unfinished">Plug on</translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation type="unfinished">Plug off</translation>
    </message>
    <message utf8="true">
        <source>Cambiar acción asociada a la tecla</source>
        <translation type="obsolete">تعديل الوظيفة  المكلّفة للمفتاح</translation>
    </message>
    <message>
        <source>Luz ON</source>
        <translation type="obsolete">النّور مضاء</translation>
    </message>
    <message>
        <source>Luz OFF</source>
        <translation type="obsolete">النّور مطفأ</translation>
    </message>
    <message>
        <source>Incrementar luz</source>
        <translation type="obsolete">رفع مستوى الإنارة  </translation>
    </message>
    <message>
        <source>Decrementar luz</source>
        <translation type="obsolete">تخفيض مستوى الإنارة </translation>
    </message>
    <message>
        <source>Subir elemento motorizado</source>
        <translation type="obsolete">رفع العنصر  المزوّد للحركة</translation>
    </message>
    <message>
        <source>Bajar elemento motorizado</source>
        <translation type="obsolete">تخفيض العنصر  المزوّد للحركة</translation>
    </message>
    <message>
        <source>Clima ON</source>
        <translation type="obsolete">التّحكّم بالمناخ مضاء</translation>
    </message>
    <message>
        <source>Clima OFF</source>
        <translation type="obsolete">التّحكّم بالمناخ مطفأ</translation>
    </message>
    <message>
        <source>Enchufe ON</source>
        <translation type="obsolete">المقبس مضاء </translation>
    </message>
    <message>
        <source>Enchufe OFF</source>
        <translation type="obsolete">المقبس مطفأ</translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation>الضّوء تشغيل/تعطيل  </translation>
    </message>
    <message>
        <source>Luz dimeada</source>
        <translation type="obsolete">تخفيت الضّوء</translation>
    </message>
    <message>
        <source>Persiana</source>
        <translation type="obsolete">الأباجور </translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation>الأباجور الّذي يمكن تحديد موقعه </translation>
    </message>
    <message>
        <source>Toldo</source>
        <translation type="obsolete"> المظلّة</translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation>المظلّة الّتي يمكن  تحديد موقعها </translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation type="unfinished">الباب  المزوّد بالحركة </translation>
    </message>
    <message>
        <source>Vivimat</source>
        <translation type="obsolete">Vivimat</translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation>الضّوء المستقلّ </translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation>أضواء المنطقة </translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation>جميع الأضواء </translation>
    </message>
    <message>
        <source>Elemento individual</source>
        <translation type="obsolete">الضّوء المفرد </translation>
    </message>
    <message>
        <source>Elementos de la zona</source>
        <translation type="obsolete">الأجهزة في المنطقة </translation>
    </message>
    <message>
        <source>Todos los elementos</source>
        <translation type="obsolete">جميع الأجهزة </translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation>المقبس  المستقلّ</translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation>المقابس في المنطقة </translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation>جميع المقابس </translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encender Clima</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apagar Clima</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Luz regulable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dispositivo individual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dispositivos de la zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conmutar camara</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message utf8="true">
        <source>Cambiar acción asociada a la tecla</source>
        <translation type="unfinished">Modify function assigned to  key</translation>
    </message>
    <message utf8="true">
        <source>Tipo de acción:</source>
        <translation type="obsolete">Function type:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق </translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message utf8="true">
        <source>Acción:</source>
        <translation>الحركة  </translation>
    </message>
    <message>
        <source>Tipo:</source>
        <translation type="obsolete">النّوع</translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation>نوع التّحكّم</translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation>العنصر </translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IconChangeDialogClass</name>
    <message>
        <source>IconChangeDialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IntercomWindow</name>
    <message>
        <source>Terminal1</source>
        <translation type="obsolete">Terminal1</translation>
    </message>
    <message>
        <source>Terminal2</source>
        <translation type="obsolete">Terminal2</translation>
    </message>
    <message>
        <source>Terminal3</source>
        <translation type="obsolete">Terminal3</translation>
    </message>
    <message>
        <source>Terminal 1</source>
        <translation type="obsolete">Terminal 1</translation>
    </message>
    <message>
        <source>Terminal 2</source>
        <translation type="obsolete">Terminal 2</translation>
    </message>
    <message>
        <source>Terminal 3</source>
        <translation type="obsolete">Terminal 3</translation>
    </message>
    <message utf8="both">
        <source>NO EXISTEN MÁS TERMINALES</source>
        <translation type="obsolete">NO MORE TERMINAL</translation>
    </message>
    <message>
        <source>DESCONECTADO</source>
        <translation type="obsolete">مقطوع </translation>
    </message>
    <message>
        <source>CONECTADO</source>
        <translation type="obsolete">المتّصل</translation>
    </message>
</context>
<context>
    <name>IntercomWindowClass</name>
    <message>
        <source>Llamar</source>
        <translation type="obsolete">إتّصل</translation>
    </message>
    <message>
        <source>+</source>
        <translation type="obsolete">+</translation>
    </message>
    <message>
        <source>-</source>
        <translation type="obsolete">-</translation>
    </message>
    <message>
        <source>Colgar</source>
        <translation type="obsolete">إنهاء الإتّصال</translation>
    </message>
    <message>
        <source>Volumen</source>
        <translation type="obsolete">Volume</translation>
    </message>
    <message>
        <source>Terminal 1</source>
        <translation type="obsolete">Terminal 1</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation type="obsolete">رفع</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation type="obsolete">تخفيض   </translation>
    </message>
</context>
<context>
    <name>InternetWindow</name>
    <message>
        <source>Tiempo</source>
        <translation type="obsolete">الطقس</translation>
    </message>
    <message>
        <source>Noticias</source>
        <translation type="obsolete">الا خبار</translation>
    </message>
    <message>
        <source>Bolsa</source>
        <translation type="obsolete">البورصة</translation>
    </message>
    <message>
        <source>Trafico</source>
        <translation type="obsolete">حركة السير</translation>
    </message>
</context>
<context>
    <name>InvoiceWindow</name>
    <message utf8="both">
        <source>Introduzca el año ...</source>
        <translation type="obsolete">Introduce the year</translation>
    </message>
    <message>
        <source>Introduzca el mes ...</source>
        <translation type="obsolete">أدخل  الشّهر </translation>
    </message>
    <message>
        <source>Introduzca el dia ...</source>
        <translation type="obsolete">Introduce the day</translation>
    </message>
    <message utf8="true">
        <source>Introduzca el día ...</source>
        <translation type="obsolete">أدخل اليوم   </translation>
    </message>
</context>
<context>
    <name>InvoiceWindowClass</name>
    <message>
        <source>Cerrar</source>
        <translation type="obsolete">إغلاق </translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="obsolete">تطبيق</translation>
    </message>
    <message>
        <source>Introduzca la fecha de la ultima factura:</source>
        <translation type="obsolete">أدخل تاريخ الفاتورة الأخيرة </translation>
    </message>
    <message utf8="true">
        <source>Año</source>
        <translation type="obsolete"> السّنة </translation>
    </message>
    <message>
        <source>Mes</source>
        <translation type="obsolete">الشّهر</translation>
    </message>
    <message>
        <source>Dia</source>
        <translation type="obsolete">اليوم</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
</context>
<context>
    <name>IrrigatorControl</name>
    <message>
        <source>Manual</source>
        <translation>غير اتوماتيكي  </translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>البرنامج </translation>
    </message>
    <message>
        <source>ON</source>
        <translation>تشغيل </translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>إيقاف </translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>أدخل الإسم الجديد </translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished">لا شيء </translation>
    </message>
    <message>
        <source>En espera</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IrrigatorControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>صيغة العمل </translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>البرنامج المترابط </translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>إعادة تسمية </translation>
    </message>
    <message utf8="true">
        <source>Detener riego en caso de lluvia o suelo ya húmedo</source>
        <translation>عدم الرّيّ في حال هطول المطر أو الأرض  الرّطبة</translation>
    </message>
    <message>
        <source>Sensor de humedad asociado:</source>
        <translation>جهاز كشف  الرّطوبة المترابط</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق </translation>
    </message>
    <message>
        <source>ON</source>
        <translation>مضاء </translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>مطفأ</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>المنطقة </translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>جهاز </translation>
    </message>
    <message>
        <source>todos</source>
        <translation>الكلّ</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية : qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duracion del riego (minutos):</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyReadDialog</name>
    <message>
        <source>- Codigo: </source>
        <translation type="obsolete">-Code:</translation>
    </message>
    <message>
        <source>
- Tipo: </source>
        <translation>النّوع</translation>
    </message>
    <message>
        <source>
- Asignada a: </source>
        <translation>مكلّف إلى</translation>
    </message>
    <message utf8="both">
        <source>Llave desconocida.
- Código: </source>
        <translation type="unfinished">Unknown key.
- Code:</translation>
    </message>
    <message utf8="true">
        <source>- Código: </source>
        <translation>الرّمز  </translation>
    </message>
</context>
<context>
    <name>KeyReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Acerque la llave
para ser leída</source>
        <translation>أدخل المفتاح في بطاقة  القرآءة</translation>
    </message>
    <message>
        <source>Leer llave</source>
        <translation>إقرأ المفتاح </translation>
    </message>
    <message>
        <source>R</source>
        <translation type="obsolete">R</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية : qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
</context>
<context>
    <name>KeyRecordDialog</name>
    <message utf8="both">
        <source>El usuario tiene
asociada la llave
con código: </source>
        <translation type="unfinished">User has key 
associated with code:</translation>
    </message>
    <message>
        <source>
del tipo: </source>
        <translation type="obsolete">من نوع </translation>
    </message>
    <message utf8="both">
        <source>No hay espacio
para grabar más llaves</source>
        <translation type="unfinished">No space to record
 new messages</translation>
    </message>
    <message>
        <source>Acerque la llave
para ser grabada</source>
        <translation>أدخل في بطاقة القرآءة</translation>
    </message>
    <message utf8="both">
        <source>Se va a proceder
a borrar la llave.
¿Está seguro?</source>
        <translation type="unfinished">Key is about 
to be deleted...
do you wish to proceed?</translation>
    </message>
    <message>
        <source>La llave ya ha
sido grabada antes.</source>
        <translation>قد تمّ تحفيظ المفتاح مسبقاً</translation>
    </message>
    <message utf8="both">
        <source>Llave leída.
- Código: </source>
        <translation type="unfinished">Key read.
- Code:</translation>
    </message>
</context>
<context>
    <name>KeyRecordDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>El usuario no tiene
llave asociada</source>
        <translation>لا يوجد مفتاح مرتبط بالمستخدم </translation>
    </message>
    <message>
        <source>Grabar llave</source>
        <translation> سجّل  المفتاح</translation>
    </message>
    <message>
        <source>R</source>
        <translation type="obsolete">R</translation>
    </message>
    <message>
        <source>Tipo de llave:</source>
        <translation>نوع المفتاح </translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation>&gt;&gt;</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation>&lt;&lt;</translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation>تحفيظ </translation>
    </message>
    <message>
        <source>Grabar
llave</source>
        <translation>تحفيظ المفتاح </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message>
        <source>Borrar
llave</source>
        <translation>مسح المفتاح </translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>موافقة </translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية : qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
</context>
<context>
    <name>KeyboardClass</name>
    <message>
        <source>Keyboad</source>
        <translation></translation>
    </message>
    <message>
        <source>&gt;&gt;&gt;</source>
        <translation>&gt;&gt;&gt;</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>مسح </translation>
    </message>
    <message>
        <source>Bloq May</source>
        <translation></translation>
    </message>
    <message>
        <source>L</source>
        <translation></translation>
    </message>
    <message>
        <source>X</source>
        <translation></translation>
    </message>
    <message>
        <source>U</source>
        <translation></translation>
    </message>
    <message>
        <source>Y</source>
        <translation></translation>
    </message>
    <message>
        <source>8</source>
        <translation></translation>
    </message>
    <message>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <source>5</source>
        <translation></translation>
    </message>
    <message>
        <source>W</source>
        <translation></translation>
    </message>
    <message>
        <source>I</source>
        <translation></translation>
    </message>
    <message>
        <source>R</source>
        <translation></translation>
    </message>
    <message>
        <source>B</source>
        <translation></translation>
    </message>
    <message>
        <source>2</source>
        <translation></translation>
    </message>
    <message>
        <source>D</source>
        <translation></translation>
    </message>
    <message>
        <source>4</source>
        <translation></translation>
    </message>
    <message>
        <source>T</source>
        <translation></translation>
    </message>
    <message>
        <source>F</source>
        <translation></translation>
    </message>
    <message>
        <source>3</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Ñ</source>
        <translation></translation>
    </message>
    <message>
        <source>J</source>
        <translation></translation>
    </message>
    <message>
        <source>A</source>
        <translation></translation>
    </message>
    <message>
        <source>V</source>
        <translation></translation>
    </message>
    <message>
        <source>P</source>
        <translation></translation>
    </message>
    <message>
        <source>7</source>
        <translation></translation>
    </message>
    <message>
        <source>H</source>
        <translation></translation>
    </message>
    <message>
        <source>E</source>
        <translation></translation>
    </message>
    <message>
        <source>Q</source>
        <translation></translation>
    </message>
    <message>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <source>C</source>
        <translation></translation>
    </message>
    <message>
        <source>S</source>
        <translation></translation>
    </message>
    <message>
        <source>M</source>
        <translation></translation>
    </message>
    <message>
        <source>6</source>
        <translation></translation>
    </message>
    <message>
        <source>Z</source>
        <translation></translation>
    </message>
    <message>
        <source>K</source>
        <translation></translation>
    </message>
    <message>
        <source>O</source>
        <translation></translation>
    </message>
    <message>
        <source>G</source>
        <translation></translation>
    </message>
    <message>
        <source>9</source>
        <translation></translation>
    </message>
    <message>
        <source>N</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ó</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>é</source>
        <translation></translation>
    </message>
    <message>
        <source>&apos;</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Ó</source>
        <translation></translation>
    </message>
    <message>
        <source>_</source>
        <translation></translation>
    </message>
    <message>
        <source>.</source>
        <translation></translation>
    </message>
    <message>
        <source>,</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>É</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>á</source>
        <translation></translation>
    </message>
    <message>
        <source>@</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ú</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Í</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Ç</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Ú</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Á</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ç</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>í</source>
        <translation></translation>
    </message>
    <message>
        <source>-</source>
        <translation></translation>
    </message>
    <message>
        <source>y</source>
        <translation></translation>
    </message>
    <message>
        <source>s</source>
        <translation></translation>
    </message>
    <message>
        <source>f</source>
        <translation></translation>
    </message>
    <message>
        <source>j</source>
        <translation></translation>
    </message>
    <message>
        <source>v</source>
        <translation></translation>
    </message>
    <message>
        <source>t</source>
        <translation></translation>
    </message>
    <message>
        <source>b</source>
        <translation></translation>
    </message>
    <message>
        <source>z</source>
        <translation></translation>
    </message>
    <message>
        <source>c</source>
        <translation></translation>
    </message>
    <message>
        <source>k</source>
        <translation></translation>
    </message>
    <message>
        <source>i</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ñ</source>
        <translation></translation>
    </message>
    <message>
        <source>r</source>
        <translation></translation>
    </message>
    <message>
        <source>g</source>
        <translation></translation>
    </message>
    <message>
        <source>w</source>
        <translation></translation>
    </message>
    <message>
        <source>a</source>
        <translation></translation>
    </message>
    <message>
        <source>x</source>
        <translation></translation>
    </message>
    <message>
        <source>p</source>
        <translation></translation>
    </message>
    <message>
        <source>l</source>
        <translation></translation>
    </message>
    <message>
        <source>m</source>
        <translation></translation>
    </message>
    <message>
        <source>n</source>
        <translation></translation>
    </message>
    <message>
        <source>h</source>
        <translation></translation>
    </message>
    <message>
        <source>u</source>
        <translation></translation>
    </message>
    <message>
        <source>d</source>
        <translation></translation>
    </message>
    <message>
        <source>q</source>
        <translation></translation>
    </message>
    <message>
        <source>o</source>
        <translation></translation>
    </message>
    <message>
        <source>e</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق </translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية : qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>*</source>
        <translation>*</translation>
    </message>
    <message>
        <source>#</source>
        <translation>#</translation>
    </message>
    <message utf8="true">
        <source>ş</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ö</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ü</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ǧ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ف</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ى</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ح</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ه</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ا</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ع</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>خ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ي</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>م</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ة</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ض</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ب</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ص</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ت</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ث</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>و</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ش</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ق</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>لا</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ؤ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>س</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ن</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>غ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ك</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ل</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ر</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ئ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ء</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ظ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ز</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>د</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ج</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ط</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٨</source>
        <translation type="unfinished">٨</translation>
    </message>
    <message utf8="true">
        <source>٤</source>
        <translation type="unfinished">٤</translation>
    </message>
    <message utf8="true">
        <source>٣</source>
        <translation type="unfinished">٣</translation>
    </message>
    <message utf8="true">
        <source>٧</source>
        <translation type="unfinished">٧</translation>
    </message>
    <message utf8="true">
        <source>ذ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>١</source>
        <translation type="unfinished">١</translation>
    </message>
    <message utf8="true">
        <source>٢</source>
        <translation type="unfinished">٢</translation>
    </message>
    <message utf8="true">
        <source>٩</source>
        <translation type="unfinished">٩</translation>
    </message>
    <message utf8="true">
        <source>٦</source>
        <translation type="unfinished">٦</translation>
    </message>
    <message utf8="true">
        <source>٥</source>
        <translation type="unfinished">٥</translation>
    </message>
</context>
<context>
    <name>LicenseSystem</name>
    <message>
        <source>Introduzca licencia...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>La licencia caducará en %1 días. 
Para poder seguir usando el sistema Vivimat III deberá llamar a su instalador para que le proporcione una licencia 
 válida. Deberá indicarle el número de licencia que aparece a continuación para poder activar el sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Número de licencia:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licencia....</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LightControl</name>
    <message>
        <source>Manual</source>
        <translation>غير اتوماتيكي </translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>البرنامج </translation>
    </message>
    <message>
        <source>Presencia</source>
        <translation>حضور</translation>
    </message>
    <message>
        <source>Crepuscular</source>
        <translation>غسق </translation>
    </message>
    <message>
        <source>Pres + Crep</source>
        <translation type="obsolete">Pres + Twl</translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="obsolete">تشغيل </translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="obsolete">توقيف </translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>أدخل الإسم الجديد </translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished">لا شيء </translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crep + Pres</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pres + Prog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LightControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>البرنامج المترابط </translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>إعادة تسمية</translation>
    </message>
    <message>
        <source>Consigna en modo programa:</source>
        <translation type="obsolete">نقطة الإرتكاز المبرمجة</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>صيغة العمل</translation>
    </message>
    <message>
        <source>%</source>
        <translation></translation>
    </message>
    <message>
        <source>Sensor de presencia asociado:</source>
        <translation>كاشف الحضور المترابط </translation>
    </message>
    <message utf8="true">
        <source>Retraso a la desactivación:</source>
        <translation>مفتاح التعطيل </translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>الجهاز </translation>
    </message>
    <message>
        <source>zona</source>
        <translation>المنطقة </translation>
    </message>
    <message>
        <source>todos</source>
        <translation> الكلّ</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية : qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Consigna en modo presencia:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>inicio</source>
        <translation>إنطلاق</translation>
    </message>
    <message>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation>النظام المرئي لمراقبة الدخول</translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation>أمن </translation>
    </message>
    <message>
        <source>escenas</source>
        <translation>السناريوهات </translation>
    </message>
    <message>
        <source>mensajes</source>
        <translation>الرسائل</translation>
    </message>
    <message utf8="both">
        <source>configuración</source>
        <translation type="obsolete">Configuration</translation>
    </message>
    <message>
        <source>telefono</source>
        <translation type="obsolete">Telephone</translation>
    </message>
    <message utf8="both">
        <source>audio/vídeo</source>
        <translation type="obsolete">A/V</translation>
    </message>
    <message>
        <source>clima</source>
        <translation>المناخ</translation>
    </message>
    <message>
        <source>consumos</source>
        <translation type="obsolete">الإستهلاك </translation>
    </message>
    <message utf8="both">
        <source>cámaras</source>
        <translation type="unfinished">Cameras</translation>
    </message>
    <message>
        <source>internet</source>
        <translation type="obsolete">انترنت </translation>
    </message>
    <message>
        <source>programas</source>
        <translation>البرامج </translation>
    </message>
    <message>
        <source>intercom.</source>
        <translation type="obsolete">الهاتف الداخلي </translation>
    </message>
    <message>
        <source>alarmas</source>
        <translation>جهازات الإنذار </translation>
    </message>
    <message>
        <source>historial</source>
        <translation> سجلّ الإنذارات</translation>
    </message>
    <message>
        <source>fotos</source>
        <translation>الصّور</translation>
    </message>
    <message utf8="both">
        <source>barómetro</source>
        <translation type="obsolete">Baromether</translation>
    </message>
    <message>
        <source>pizarra</source>
        <translation> اللّوح</translation>
    </message>
    <message>
        <source>sos</source>
        <translation>SOS</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>teléfono</source>
        <translation type="obsolete">الهاتف </translation>
    </message>
    <message>
        <source>LUN </source>
        <translation>الإثنين </translation>
    </message>
    <message>
        <source>MAR </source>
        <translation>الثلاثاء </translation>
    </message>
    <message>
        <source>MIE </source>
        <translation>الأربعاء </translation>
    </message>
    <message>
        <source>JUE </source>
        <translation> الخميس</translation>
    </message>
    <message>
        <source>VIE </source>
        <translation>الجمعة</translation>
    </message>
    <message>
        <source>SAB </source>
        <translation>السبت</translation>
    </message>
    <message>
        <source>DOM </source>
        <translation>الأحد </translation>
    </message>
    <message>
        <source>dd/MM/yyyy</source>
        <translation>yyyy/MM/dd</translation>
    </message>
    <message>
        <source>INT </source>
        <translation type="obsolete">INT</translation>
    </message>
    <message utf8="true">
        <source> ºC</source>
        <translation type="obsolete">ºC</translation>
    </message>
    <message utf8="true">
        <source>Los ficheros de configuración no coinciden.
Para sobreescribir los ficheros de la central en la pantalla
pulsa Aceptar. En caso contrario, pulsa Cancelar.</source>
        <translation type="obsolete">Configuration files are different.
To overwrite the central&apos;s files into the display
click Accept. Otherwise, click Cancel</translation>
    </message>
    <message utf8="true">
        <source>Actualizar configuración</source>
        <translation>تجديد التكوين</translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código IR:
%1
%2
%3</source>
        <translation type="obsolete">تمت قراءة الرمز ال إ/ر 
%1
%2
%3</translation>
    </message>
    <message utf8="true">
        <source>Código IR leido</source>
        <translation type="obsolete">تمت قراءة الرمز ال إ/ر</translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código RF:
%1
%2
%3
%4</source>
        <translation type="obsolete">تمت قراءة الرمز ال ر/ف 
%1
%2
%3
%4</translation>
    </message>
    <message>
        <source>Llave leida</source>
        <translation type="obsolete">تمت قراءة المفتح</translation>
    </message>
    <message utf8="true">
        <source>INT %1 ºC</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código IR:
%1 %2 %3</source>
        <translation type="unfinished">تمت قراءة الرمز ال إ/ر 
%1 %2 %3</translation>
    </message>
    <message utf8="true">
        <source>Código IR leído</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código RFID:
%1 %2 %3 %4</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Llave leída</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Cerrar sesión</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>configurar</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible visualizar las cámaras porque ya están siendo visualizadas en otro terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Cámaras ocupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para menú de seguridad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sistema bloqueado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Antes de poder usar los mensajes de voz es necesario tener grabados los mensajes personales.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensajes personales sin grabar</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Los ficheros de configuración no coinciden.
Para sobreescribir los ficheros de la central en la pantalla pulsa Aceptar. En caso contrario, pulsa Cancelar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>El idioma del sistema ha sido modificado.
¿Desea reiniciar la pantalla?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actualizar idioma...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 90 segundos.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindowClass</name>
    <message>
        <source>MAR 03/02/2009</source>
        <translation type="obsolete">TUE 03/02/2009</translation>
    </message>
    <message>
        <source>12:30</source>
        <translation>12:30</translation>
    </message>
    <message>
        <source>MAR 15/11/2009</source>
        <translation>TUE 2009/11/15</translation>
    </message>
    <message utf8="true">
        <source>INT 18ºC</source>
        <translation>INT 18ºC</translation>
    </message>
    <message>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation> ملفّ التّكوين</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية : qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>قبول </translation>
    </message>
</context>
<context>
    <name>MessagesWindow</name>
    <message>
        <source>Tipo</source>
        <translation>نوع </translation>
    </message>
    <message>
        <source>Origen</source>
        <translation>المصدر </translation>
    </message>
    <message>
        <source>Fecha/Hora</source>
        <translation>التاريخ والتوقيت </translation>
    </message>
    <message>
        <source>Voz</source>
        <translation>صوت </translation>
    </message>
    <message>
        <source>Desconocido</source>
        <translation>مجهول </translation>
    </message>
    <message>
        <source>Videoportero</source>
        <translation>النظام المرئي لمراقبة الدخول</translation>
    </message>
    <message>
        <source>Terminal 1</source>
        <translation>Terminal1</translation>
    </message>
    <message>
        <source>Terminal 2</source>
        <translation>Terminal2</translation>
    </message>
    <message>
        <source>Terminal 3</source>
        <translation>Terminal3</translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation>تحفيظ الرسالة</translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation>إعادة إنشاء الرسالة</translation>
    </message>
    <message utf8="both">
        <source>Se va a eliminar el mensaje.
¿Está seguro?</source>
        <translation type="obsolete">Message is about to be deleted.
do you wish to proceed?</translation>
    </message>
    <message>
        <source>Eliminar mensaje...</source>
        <translation type="obsolete">مسح الرسالة </translation>
    </message>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible borrar los mensajes, los mensajes de voz ya están siendo usados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessagesWindowClass</name>
    <message>
        <source>Form</source>
        <translation>الصيغة </translation>
    </message>
    <message>
        <source>Grabar
mensaje</source>
        <translation>تحفيظ الرسالة </translation>
    </message>
    <message>
        <source>Borrar
mensajes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MsgProgressDialogClass</name>
    <message>
        <source>RecWindow</source>
        <translation>ملفّ التحفيظ </translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية : qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Parar</source>
        <translation>قف </translation>
    </message>
</context>
<context>
    <name>MsgProgressWindowClass</name>
    <message>
        <source>Parar</source>
        <translation type="obsolete">Stop</translation>
    </message>
</context>
<context>
    <name>PasswordClass</name>
    <message>
        <source>Password</source>
        <translation></translation>
    </message>
    <message>
        <source>Introduzca clave de acceso</source>
        <translation type="obsolete">أدخل رمز الدخول</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message>
        <source>5</source>
        <translation></translation>
    </message>
    <message>
        <source>6</source>
        <translation></translation>
    </message>
    <message>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <source>2</source>
        <translation></translation>
    </message>
    <message>
        <source>3</source>
        <translation></translation>
    </message>
    <message>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <source>7</source>
        <translation></translation>
    </message>
    <message>
        <source>8</source>
        <translation></translation>
    </message>
    <message>
        <source>9</source>
        <translation></translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>محو </translation>
    </message>
    <message>
        <source>4</source>
        <translation></translation>
    </message>
    <message>
        <source>OK</source>
        <translation></translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية : qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para continuar...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialog</name>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensajes de voz personalizados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensaje para llamadas de alarma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reproducir</source>
        <translation type="unfinished">السّماع</translation>
    </message>
    <message>
        <source>Grabar</source>
        <translation type="unfinished">تسجيل </translation>
    </message>
    <message>
        <source>Mensaje para contestador de videoportero</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Para grabar los mensajes de voz personalizados primero se borraran todos los mensajes, después se grabará el mensaje para llamadas de alarma y a continuación el mensaje para contestador de videoportero.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindow</name>
    <message>
        <source>Tipo</source>
        <translation>النوع </translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>الإسم </translation>
    </message>
    <message>
        <source>Numero</source>
        <translation type="obsolete">Number</translation>
    </message>
    <message>
        <source>CRA</source>
        <translation>ARC</translation>
    </message>
    <message>
        <source>SMS</source>
        <translation>SMS</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>TEL</source>
        <translation>هاتف</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>أدخل الإسم الجديد</translation>
    </message>
    <message>
        <source>Introduzca nuevo numero o direccion de correo ...</source>
        <translation type="obsolete">Introduce new number or e-mail address ...</translation>
    </message>
    <message utf8="both">
        <source>Se va a eliminar el contacto.
¿Está seguro?</source>
        <translation type="unfinished">Contact is about to be deleted.
do you wish to proceed?</translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation>إلغاء علاقة </translation>
    </message>
    <message utf8="true">
        <source>Número</source>
        <translation>رقم</translation>
    </message>
    <message>
        <source>Es necesario introducir primero el tipo de contacto.</source>
        <translation>أدخل أوّلاً نوع العلاقة </translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>خلل </translation>
    </message>
    <message utf8="true">
        <source>Introduzca nuevo número o dirección de correo ...</source>
        <translation>أدخل الإسم الجديد 
 email</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>الرّجاء إدخال المعلومات النّاقصة...</translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindowClass</name>
    <message>
        <source>PhoneConfigWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق  </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق</translation>
    </message>
    <message>
        <source>Habilitar avisos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Habilitar telecontrol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tonos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configurar
CRA</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PhoneWindow</name>
    <message>
        <source>Llamando...</source>
        <translation type="obsolete">Calling ...</translation>
    </message>
    <message>
        <source>LLAMANDO...</source>
        <translation type="obsolete">عمليات الإتصال جارية </translation>
    </message>
    <message>
        <source>COLGADO</source>
        <translation type="obsolete">إنتهاء الإتصال </translation>
    </message>
</context>
<context>
    <name>PhoneWindowClass</name>
    <message>
        <source>Llamar</source>
        <translation type="obsolete">إتّصل</translation>
    </message>
    <message>
        <source>Colgar</source>
        <translation type="obsolete">إنهاء الإتّصال</translation>
    </message>
    <message>
        <source>B</source>
        <translation type="obsolete">Erase</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation type="obsolete">محو </translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation type="obsolete">تخفيض   </translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation type="obsolete">رفع</translation>
    </message>
</context>
<context>
    <name>PhotosWindow</name>
    <message>
        <source>Marco de fotos</source>
        <translation type="unfinished">إطار  الصّورة</translation>
    </message>
    <message>
        <source>No hay fotos disponibles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No se puede mostrar la foto (%1).</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PhotosWindowClass</name>
    <message>
        <source>Marco de fotos</source>
        <translation type="obsolete">إطار  الصّورة</translation>
    </message>
</context>
<context>
    <name>PlugControl</name>
    <message>
        <source>Manual</source>
        <translation>غير اتوماتيكي</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>البرنامج </translation>
    </message>
    <message>
        <source>ON</source>
        <translation>تشغيل</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>إيقاف </translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>أدخل الإسم الجديد</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished">لا شيء </translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlugControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>نظام التشغيل</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation> البرنامج  المترابط </translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>إعادة تسمية</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message>
        <source>ON</source>
        <translation>تشغيل </translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>إيقاف </translation>
    </message>
    <message>
        <source>zona</source>
        <translation>المنطقة </translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>الجهاز </translation>
    </message>
    <message>
        <source>todos</source>
        <translation>الكلّ</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>salida temporizada </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>segundos</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindow</name>
    <message>
        <source>24 Franjas</source>
        <translation type="obsolete">24 الوقت المخصص </translation>
    </message>
    <message>
        <source>5 Franjas</source>
        <translation type="obsolete">5الوقت المخصص </translation>
    </message>
    <message>
        <source>Temperatura</source>
        <translation>الحرارة </translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation></translation>
    </message>
    <message>
        <source>ON-OFF</source>
        <translation></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>أدخل الإسم الجديد</translation>
    </message>
    <message>
        <source>%1:00</source>
        <translation type="obsolete">%1:00</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation type="obsolete">%1ºC</translation>
    </message>
    <message>
        <source>100%</source>
        <translation type="obsolete">100%</translation>
    </message>
    <message>
        <source>0%</source>
        <translation type="obsolete">0%</translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="obsolete">تشغيل</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="obsolete">إيقاف </translation>
    </message>
    <message>
        <source>%1%</source>
        <translation type="obsolete">%1%</translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation type="unfinished">ºC</translation>
    </message>
    <message>
        <source>%</source>
        <translation type="unfinished">%</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>0 = OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 = ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Las franjas horarias no están bien definidas.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error...</source>
        <translation type="unfinished">خلل </translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindowClass</name>
    <message>
        <source>Form</source>
        <translation>الصّيغة</translation>
    </message>
    <message>
        <source>Modo</source>
        <translation type="obsolete">نظام التشغيل </translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>النوع </translation>
    </message>
    <message>
        <source>Franja 1:</source>
        <translation>Slot 1:</translation>
    </message>
    <message>
        <source>Franja 2:</source>
        <translation>Slot 2:</translation>
    </message>
    <message>
        <source>Franja 3:</source>
        <translation>Slot 3:</translation>
    </message>
    <message>
        <source>Franja 4:</source>
        <translation>Slot 4:</translation>
    </message>
    <message>
        <source>Franja 5:</source>
        <translation>Slot 5:</translation>
    </message>
    <message>
        <source>Inicio</source>
        <translation>إنطلاق</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>س/د </translation>
    </message>
    <message>
        <source>Fin</source>
        <translation>إنهاء </translation>
    </message>
    <message utf8="true">
        <source>20ºC</source>
        <translation type="obsolete">20ºC</translation>
    </message>
    <message>
        <source>+</source>
        <translation type="obsolete">+</translation>
    </message>
    <message>
        <source>-</source>
        <translation type="obsolete">-</translation>
    </message>
    <message>
        <source>00:00</source>
        <translation type="obsolete">00:00</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>إعادة تسمية </translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق  </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message utf8="true">
        <source>Días de ejecución:</source>
        <translation>أيّام التّشغيل</translation>
    </message>
    <message>
        <source>L</source>
        <translation>الإثنين</translation>
    </message>
    <message>
        <source>M</source>
        <translation>الثلاثاء </translation>
    </message>
    <message>
        <source>X</source>
        <translation>الأربعاء  </translation>
    </message>
    <message>
        <source>J</source>
        <translation>الخميس</translation>
    </message>
    <message>
        <source>V</source>
        <translation>الجمعة</translation>
    </message>
    <message>
        <source>S</source>
        <translation>السبت</translation>
    </message>
    <message>
        <source>D</source>
        <translation>الأحد </translation>
    </message>
    <message>
        <source>QToolButton{
border: 2px inset palette(dark);
background-color: rgba(255,255,255,0);
}</source>
        <translation type="obsolete">QToolButton{border: 2px inset palette(dark);background-color: rgba(255,255,255,0);}</translation>
    </message>
    <message>
        <source>Consigna</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgramsWindow</name>
    <message>
        <source>24 Franjas</source>
        <translation type="obsolete">24 slots</translation>
    </message>
    <message>
        <source>Temperatura</source>
        <translation>الحرارة </translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation></translation>
    </message>
    <message>
        <source>ON/OFF</source>
        <translation></translation>
    </message>
    <message>
        <source>5 Franjas</source>
        <translation type="obsolete">5 slots</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>الإسم </translation>
    </message>
    <message>
        <source>Modo</source>
        <translation type="obsolete">نظام التشغيل </translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>النوع </translation>
    </message>
    <message>
        <source>L</source>
        <translation>الإثنين</translation>
    </message>
    <message>
        <source>M</source>
        <translation>الثلاثاء </translation>
    </message>
    <message>
        <source>X</source>
        <translation>الأربعاء  </translation>
    </message>
    <message>
        <source>J</source>
        <translation>الخميس</translation>
    </message>
    <message>
        <source>V</source>
        <translation>الجمعة</translation>
    </message>
    <message>
        <source>S</source>
        <translation>السبت</translation>
    </message>
    <message>
        <source>D</source>
        <translation>الأحد </translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>--</source>
        <translation type="obsolete">--</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el programa.
¿Está seguro?</source>
        <translation>البرنامج على وشك المحو ... هل تودّ الإستئناف؟ </translation>
    </message>
    <message>
        <source>Eliminar programa...</source>
        <translation>.مسح البرنامج </translation>
    </message>
</context>
<context>
    <name>ProgramsWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>الإسم </translation>
    </message>
    <message>
        <source>Modo</source>
        <translation type="obsolete">نظام التشغيل </translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>النوع </translation>
    </message>
    <message>
        <source>L</source>
        <translation>الإثنين</translation>
    </message>
    <message>
        <source>M</source>
        <translation>الثلاثاء </translation>
    </message>
    <message>
        <source>X</source>
        <translation>الأربعاء  </translation>
    </message>
    <message>
        <source>J</source>
        <translation>الخميس</translation>
    </message>
    <message>
        <source>V</source>
        <translation>الجمعة</translation>
    </message>
    <message>
        <source>S</source>
        <translation>السبت</translation>
    </message>
    <message>
        <source>D</source>
        <translation>الأحد </translation>
    </message>
    <message>
        <source>Modificar</source>
        <translation type="obsolete">Modify</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation type="obsolete">Erase</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق   </translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
</context>
<context>
    <name>RBlindControl</name>
    <message>
        <source>Manual</source>
        <translation>غير اتوماتيكي</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>البرنامج</translation>
    </message>
    <message>
        <source>Desplegado</source>
        <translation type="obsolete">غير مطوي </translation>
    </message>
    <message>
        <source>Plegado</source>
        <translation type="obsolete">مطوي</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>أدخل الإسم الجديد</translation>
    </message>
    <message>
        <source>Arriba</source>
        <translation type="obsolete">إلى أعلى</translation>
    </message>
    <message>
        <source>Abajo</source>
        <translation type="obsolete">إلى أسفل</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished">لا شيء </translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grupo de toldos</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RBlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation> البرنامج  المترابط </translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>إعادة تسمية</translation>
    </message>
    <message>
        <source>Plegar toldos en caso de viento fuerte</source>
        <translation>إغلاق في حال وجود رياح</translation>
    </message>
    <message>
        <source>Consigna en modo programa:</source>
        <translation type="obsolete">نقطة الإرتكاز المبرمجة</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>نظام التشغيل</translation>
    </message>
    <message>
        <source>%</source>
        <translation type="obsolete">%</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق  </translation>
    </message>
    <message>
        <source>zona</source>
        <translation>المنطقة </translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>الجهاز </translation>
    </message>
    <message>
        <source>todos</source>
        <translation>الكلّ</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plegar toldos en caso de lluvia</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SOSWindow</name>
    <message utf8="true">
        <source>PÁNICO ACTIVADO</source>
        <translation type="obsolete">تفعيل جهاز الهلع </translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico deshabilitada</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SOSWindowClass</name>
    <message>
        <source>Form</source>
        <translation>الصّيغة</translation>
    </message>
    <message>
        <source>SOS</source>
        <translation>SOS</translation>
    </message>
    <message>
        <source>STOP</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneConditionDialog</name>
    <message>
        <source>Sin condicionar</source>
        <translation>غير مشروط </translation>
    </message>
    <message>
        <source>A</source>
        <translation type="obsolete">A</translation>
    </message>
    <message>
        <source>B</source>
        <translation type="obsolete">B</translation>
    </message>
    <message>
        <source>C</source>
        <translation type="obsolete">C</translation>
    </message>
    <message>
        <source>D</source>
        <translation type="obsolete">D</translation>
    </message>
    <message>
        <source>E</source>
        <translation type="obsolete">E</translation>
    </message>
    <message>
        <source>F</source>
        <translation type="obsolete">F</translation>
    </message>
    <message utf8="true">
        <source>Día semana</source>
        <translation>يوم الأسبوع </translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation>التاريخ </translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión Armada</source>
        <translation type="obsolete">ضبط جهاز الإقتحام </translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión Desarmada</source>
        <translation type="obsolete">تعطيل جهاز الإقتحام </translation>
    </message>
    <message utf8="true">
        <source>Activación de cualquier alarma</source>
        <translation>تفعيل أيّ  جهاز إنذار </translation>
    </message>
    <message utf8="true">
        <source>Parámetros erroneos.
</source>
        <translation type="obsolete">Wrong parameters
</translation>
    </message>
    <message utf8="true">
        <source>Parámetros erroneos...</source>
        <translation type="obsolete">Wrong parameters</translation>
    </message>
    <message>
        <source>Cualquier llave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave tipo A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave tipo B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave tipo C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave tipo D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave tipo E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave tipo F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave: </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión armada</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión desarmada</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de intrusión</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Act. alm. de fuego</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Act. alm. de gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de inundación</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de corte eléc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Act. alm. de corte tlf.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Act. alm. de sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Act. alm. médica</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de pánico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Act. alm. silenciosa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Act. alm. de sabotaje</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de coacción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entrada en Central</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entrada en MOD0035</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Intrusion en armado total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Intrusion en armado perimetral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Intrusion en armado parcial</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneConditionDialogClass</name>
    <message>
        <source>EventConditionWindow</source>
        <translation>Event ConditionWindow</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Condiciones</source>
        <translation>الشّروط</translation>
    </message>
    <message>
        <source>Llave:</source>
        <translation type="obsolete">المفتاح </translation>
    </message>
    <message>
        <source>Hora:</source>
        <translation type="obsolete">التوقيت </translation>
    </message>
    <message>
        <source>Fecha / Dia semana</source>
        <translation type="obsolete">التاريخ/يوم الأسبوع </translation>
    </message>
    <message>
        <source>Condicion de alarma</source>
        <translation type="obsolete">شروط جهاز الإنذار </translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>س/د </translation>
    </message>
    <message>
        <source>Condicion de entrada</source>
        <translation type="obsolete">شروط المدخلات </translation>
    </message>
    <message>
        <source>Tipo de modulo</source>
        <translation type="obsolete">نوع النّموذج</translation>
    </message>
    <message>
        <source>E/S</source>
        <translation type="obsolete">I/O</translation>
    </message>
    <message>
        <source>Mes</source>
        <translation type="obsolete">الشّهر</translation>
    </message>
    <message utf8="true">
        <source>Año</source>
        <translation type="obsolete"> السّنة </translation>
    </message>
    <message>
        <source>Dia</source>
        <translation type="obsolete">اليوم</translation>
    </message>
    <message>
        <source>L</source>
        <translation>الإثنين</translation>
    </message>
    <message>
        <source>V</source>
        <translation>الجمعة</translation>
    </message>
    <message>
        <source>X</source>
        <translation>الأربعاء  </translation>
    </message>
    <message>
        <source>D</source>
        <translation>الأحد </translation>
    </message>
    <message>
        <source>M</source>
        <translation>الثلاثاء </translation>
    </message>
    <message>
        <source>J</source>
        <translation>الخميس</translation>
    </message>
    <message>
        <source>S</source>
        <translation>السبت</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق  </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق   </translation>
    </message>
    <message>
        <source>Condicion de llave:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condicion de hora:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condicion de Fecha / Dia semana:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condicion de entrada:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo de modulo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E/S:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condicion de alarma:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mod:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneConditionWindow</name>
    <message>
        <source>Dia semana</source>
        <translation type="obsolete">Week day</translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation type="obsolete">Date</translation>
    </message>
    <message>
        <source>Alarma de intrusion Armada</source>
        <translation type="obsolete">Intrusion alarm armed</translation>
    </message>
    <message>
        <source>Alarma de intrusion Desarmada</source>
        <translation type="obsolete">Intrusion alarm disarmed</translation>
    </message>
    <message>
        <source>Activacion de cualquier alarma</source>
        <translation type="obsolete">Activate any alarm</translation>
    </message>
    <message>
        <source>Sin condicionar</source>
        <translation type="obsolete">No conditioned</translation>
    </message>
</context>
<context>
    <name>SceneConditionWindowClass</name>
    <message>
        <source>Condiciones</source>
        <translation type="obsolete">Conditions</translation>
    </message>
    <message>
        <source>Llave:</source>
        <translation type="obsolete">Key:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="obsolete">Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="obsolete">Close</translation>
    </message>
    <message>
        <source>Hora:</source>
        <translation type="obsolete">Time:</translation>
    </message>
    <message>
        <source>Fecha / Dia semana</source>
        <translation type="obsolete">Dte/Week day</translation>
    </message>
    <message>
        <source>Condicion de alarma</source>
        <translation type="obsolete">Alarm condition</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation type="obsolete">H:mm</translation>
    </message>
    <message>
        <source>Condicion de entrada</source>
        <translation type="obsolete">Input condition</translation>
    </message>
    <message>
        <source>Tipo de modulo</source>
        <translation type="obsolete">Module type</translation>
    </message>
    <message>
        <source>Logica E/S</source>
        <translation type="obsolete">I/O</translation>
    </message>
    <message>
        <source>Mes</source>
        <translation type="obsolete">Month</translation>
    </message>
    <message utf8="true">
        <source>Año</source>
        <translation type="obsolete">Year</translation>
    </message>
    <message>
        <source>Dia</source>
        <translation type="obsolete">Day</translation>
    </message>
    <message>
        <source>L</source>
        <translation type="obsolete">M</translation>
    </message>
    <message>
        <source>V</source>
        <translation type="obsolete">F</translation>
    </message>
    <message>
        <source>X</source>
        <translation type="obsolete">M</translation>
    </message>
    <message>
        <source>D</source>
        <translation type="obsolete">SU</translation>
    </message>
    <message>
        <source>M</source>
        <translation type="obsolete">T</translation>
    </message>
    <message>
        <source>J</source>
        <translation type="obsolete">TH</translation>
    </message>
    <message>
        <source>S</source>
        <translation type="obsolete">S</translation>
    </message>
    <message>
        <source>E/S</source>
        <translation type="obsolete">I/O</translation>
    </message>
</context>
<context>
    <name>SceneEventWindow</name>
    <message>
        <source>Iluminacion</source>
        <translation type="obsolete">Lighting</translation>
    </message>
    <message>
        <source>Elementos motorizados</source>
        <translation type="obsolete">العناصر  المزوّدة للحركة</translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation>المقبس  </translation>
    </message>
    <message>
        <source>Climatizacion</source>
        <translation type="obsolete">Climate control</translation>
    </message>
    <message>
        <source>Riego</source>
        <translation>الرّيّ</translation>
    </message>
    <message>
        <source>Retardo</source>
        <translation>تأخير </translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation>الأمن</translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation>الضّوء المستقلّ </translation>
    </message>
    <message>
        <source>Grupo de luces</source>
        <translation type="obsolete">مجموعة الأضواء </translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation>جميع الأضواء </translation>
    </message>
    <message>
        <source>Opening individual</source>
        <translation type="obsolete">فتح مفرد </translation>
    </message>
    <message>
        <source>Grupo de openings</source>
        <translation type="obsolete">فتح مجموعة </translation>
    </message>
    <message>
        <source>Todos los openings</source>
        <translation type="obsolete">جميع الفتوحات </translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation>المقبس  المستقلّ</translation>
    </message>
    <message>
        <source>Grupo de enchufes</source>
        <translation type="obsolete">مجموعة  المقابس </translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation>جميع المقابس </translation>
    </message>
    <message>
        <source>Riego individual</source>
        <translation>الرّيّ المفرد </translation>
    </message>
    <message>
        <source>Grupo de riegos</source>
        <translation type="obsolete">مجموعة  الرّيّ</translation>
    </message>
    <message>
        <source>Todos los riegos</source>
        <translation>جميع  الرّيّ</translation>
    </message>
    <message>
        <source>Alarma de intrusion</source>
        <translation type="obsolete">Intrusion alarm</translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation>إنذار الحريق</translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation>إنذار الغاز</translation>
    </message>
    <message>
        <source>Alarma de inundacion</source>
        <translation type="obsolete">Flood alarm</translation>
    </message>
    <message>
        <source>Alarma de corte de suministro electrico</source>
        <translation type="obsolete">Power fail alarm</translation>
    </message>
    <message>
        <source>Alarma de corte telefonico</source>
        <translation type="obsolete">Telephone fail alarm</translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation>إنذار النظام  </translation>
    </message>
    <message>
        <source>Alarma medica</source>
        <translation type="obsolete">Medical alarm</translation>
    </message>
    <message>
        <source>Alarma de panico</source>
        <translation type="obsolete">Panic alarm</translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation>الإنذار الكتوم </translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation>إنذار تخريب </translation>
    </message>
    <message>
        <source>Todas</source>
        <translation type="obsolete">الكل</translation>
    </message>
    <message>
        <source>Persiana</source>
        <translation type="obsolete">الأباجور </translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation>الأباجور الّذي يمكن تحديد موقعه </translation>
    </message>
    <message>
        <source>Toldo</source>
        <translation type="obsolete"> المظلّة</translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation>الأباجور الّذي يمكن تحديد موقعه </translation>
    </message>
    <message>
        <source>Puerta</source>
        <translation type="obsolete">الباب </translation>
    </message>
    <message>
        <source>Todos</source>
        <translation type="obsolete">الكلّ</translation>
    </message>
    <message>
        <source>Deshabilitar alarma</source>
        <translation type="obsolete">تعطيل جهاز الإنذار </translation>
    </message>
    <message>
        <source>Habilitar alarma</source>
        <translation type="obsolete">تفعيل جهاز الإنذار </translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation>تشغيل جهاز الإنذار </translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation>جهاز الإنذار في حالة تهميش </translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation>جهاز الإنذار في عمل جزئي</translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation>جهاز الإنذار في حالة إستعداد</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation> نزع جهاز الإنذار </translation>
    </message>
    <message>
        <source>Desarmar coaccion</source>
        <translation type="obsolete">Disarm coercion</translation>
    </message>
    <message>
        <source>Encender</source>
        <translation>تشغيل </translation>
    </message>
    <message>
        <source>Apagar</source>
        <translation>تعطيل </translation>
    </message>
    <message>
        <source>Subir</source>
        <translation type="obsolete">تصعيد</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation type="obsolete">تخفيض</translation>
    </message>
    <message>
        <source>Activar</source>
        <translation type="unfinished">تفعيل </translation>
    </message>
    <message utf8="true">
        <source>Iluminación</source>
        <translation>الإنارة</translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation>تحكم بالمناخ  </translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation> جهاز الإقتحام </translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation>إنذار الفيضان  </translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte de suministro eléctrico</source>
        <translation type="obsolete">إنذار إنقطاع التيار </translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte telefónico</source>
        <translation>إنذار إنقطاع الهاتف </translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation>جهاز الإنذار  الطّبّي</translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation>جهاز الإنذار الهلع </translation>
    </message>
    <message utf8="true">
        <source>Desarmar coacción</source>
        <translation type="obsolete">تعطيل الحركة المشتركة </translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation type="unfinished">تعطيل </translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation type="unfinished">أضواء المنطقة </translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation type="unfinished">الضّوء تشغيل/تعطيل  </translation>
    </message>
    <message>
        <source>Luz Regulable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0%</source>
        <translation type="unfinished">0%</translation>
    </message>
    <message>
        <source>100%</source>
        <translation type="unfinished">100%</translation>
    </message>
    <message>
        <source>20%</source>
        <translation type="unfinished">20%</translation>
    </message>
    <message>
        <source>40%</source>
        <translation type="unfinished">40%</translation>
    </message>
    <message>
        <source>60%</source>
        <translation type="unfinished">60%</translation>
    </message>
    <message>
        <source>80%</source>
        <translation type="unfinished">80%</translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation type="unfinished">المقابس في المنطقة </translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo programa</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Modo económico</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation type="unfinished">%1ºC</translation>
    </message>
    <message>
        <source>Riegos de la zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 seg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3 seg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5 seg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>10 seg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>20 seg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>30 seg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dis. individual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dis. de la zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation type="unfinished">الباب  المزوّد بالحركة </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enchufe normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enchufes temporizados</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneEventWindowClass</name>
    <message>
        <source>SceneEventWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation type="obsolete">النوع </translation>
    </message>
    <message>
        <source>Parametro 1</source>
        <translation type="obsolete">Setting 1</translation>
    </message>
    <message>
        <source>Parametro 2</source>
        <translation type="obsolete">Setting 2</translation>
    </message>
    <message>
        <source>Parametro 3</source>
        <translation type="obsolete">Setting 3</translation>
    </message>
    <message>
        <source>Parametro 4</source>
        <translation type="obsolete">Setting 4</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق  </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message>
        <source>Modificar evento</source>
        <translation>تعديل الحدث </translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">لون الخلفية: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Tipo de evento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation type="unfinished">نوع التّحكّم</translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation type="unfinished">العنصر </translation>
    </message>
    <message>
        <source>Valor:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindow</name>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>أدخل الإسم الجديد</translation>
    </message>
    <message>
        <source>Iluminacion</source>
        <translation type="obsolete">Lighting</translation>
    </message>
    <message>
        <source>Persiana</source>
        <translation type="obsolete">الأباجور </translation>
    </message>
    <message>
        <source>Toldo</source>
        <translation type="obsolete"> المظلّة</translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation type="obsolete">الباب  المزوّد بالحركة </translation>
    </message>
    <message>
        <source>Todas las Persianas y Toldos</source>
        <translation type="obsolete">جميع المظلات ومظلات المدخل </translation>
    </message>
    <message>
        <source>Persianas</source>
        <translation type="obsolete">الأباجورات </translation>
    </message>
    <message>
        <source>Toldos</source>
        <translation type="obsolete">المظلات </translation>
    </message>
    <message>
        <source>Puertas motorizada</source>
        <translation type="obsolete"> الأبواب  المزوّدة بالحركة </translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation>المقبس  </translation>
    </message>
    <message>
        <source>Enchufes</source>
        <translation type="obsolete">المقابس </translation>
    </message>
    <message>
        <source>Todos los enchufes </source>
        <translation type="obsolete">جميع المقابس </translation>
    </message>
    <message>
        <source>Climatizacion</source>
        <translation type="obsolete">Climate control</translation>
    </message>
    <message>
        <source>Riego</source>
        <translation>الرّيّ</translation>
    </message>
    <message>
        <source>Riegos</source>
        <translation type="obsolete">الرّيّ</translation>
    </message>
    <message>
        <source>Todos los riegos </source>
        <translation type="obsolete">جميع  الرّيّ</translation>
    </message>
    <message>
        <source>Retardo</source>
        <translation type="obsolete">تأخير </translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation>أمن </translation>
    </message>
    <message>
        <source>Se va a eliminar la escena.
¿Está seguro?</source>
        <translation type="obsolete">Scene is about to be deleted.
do you wish to proceed?</translation>
    </message>
    <message>
        <source>Eliminar escena...</source>
        <translation type="obsolete">Delete scene</translation>
    </message>
    <message utf8="both">
        <source>Se va a eliminar el evento.
¿Está seguro?</source>
        <translation type="unfinished">Event is about to be deleted.
do you wish to proceed?</translation>
    </message>
    <message>
        <source>Eliminar evento...</source>
        <translation>إلغاء الحدث </translation>
    </message>
    <message>
        <source>Subir</source>
        <translation type="obsolete">تصعيد</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation type="obsolete">تخفيض </translation>
    </message>
    <message>
        <source>Zona </source>
        <translation type="obsolete">المنطقة </translation>
    </message>
    <message>
        <source>Encender</source>
        <translation type="obsolete">تشغيل </translation>
    </message>
    <message>
        <source>Apagar</source>
        <translation type="obsolete">تعطيل </translation>
    </message>
    <message>
        <source> Zona </source>
        <translation type="obsolete">المنطقة </translation>
    </message>
    <message>
        <source>Activar</source>
        <translation type="obsolete">تفعيل </translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation type="obsolete">تعطيل </translation>
    </message>
    <message>
        <source>Alarma de Intrusion</source>
        <translation type="obsolete">Intrusion alarm</translation>
    </message>
    <message>
        <source>Deshabilitar alarma</source>
        <translation>تعطيل جهاز الإنذار </translation>
    </message>
    <message>
        <source>Habilitar alarma</source>
        <translation>تفعيل جهاز الإنذار </translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation>تشغيل جهاز الإنذار </translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation>جهاز الإنذار في حالة تهميش </translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation>جهاز الإنذار في عمل جزئي</translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation>جهاز الإنذار في حالة إستعداد</translation>
    </message>
    <message>
        <source>Desarmar alarma</source>
        <translation type="obsolete">ضبط جهاز الإنذار </translation>
    </message>
    <message>
        <source>Alarma de Coaccion</source>
        <translation type="obsolete">Coercion alarm</translation>
    </message>
    <message>
        <source>Alarma de Fuego</source>
        <translation type="obsolete">إنذار الحريق</translation>
    </message>
    <message>
        <source>Alarma de Gas</source>
        <translation type="obsolete">إنذار الغاز</translation>
    </message>
    <message>
        <source>Alarma de Inundacion</source>
        <translation type="obsolete">Flood alarm</translation>
    </message>
    <message>
        <source>Alarma de Corte de suministro electrico</source>
        <translation type="obsolete">Power fail alarm</translation>
    </message>
    <message>
        <source>Alarma de Corte de telefono</source>
        <translation type="obsolete">Telephone fail alarm</translation>
    </message>
    <message>
        <source>Alarma de Sistema</source>
        <translation type="obsolete">إنذار النظام  </translation>
    </message>
    <message>
        <source>Alarma Medica</source>
        <translation type="obsolete">Medical alarm</translation>
    </message>
    <message>
        <source>Alarma de Panico</source>
        <translation type="obsolete">Panic alarm</translation>
    </message>
    <message>
        <source>Alarma Silenciosa</source>
        <translation type="obsolete">الإنذار الكتوم </translation>
    </message>
    <message>
        <source>Alarma de Sabotaje</source>
        <translation type="obsolete">إنذار تخريب </translation>
    </message>
    <message>
        <source>Evento</source>
        <translation>الحدث </translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Iluminación</source>
        <translation>الإنارة</translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation type="unfinished">تحكم بالمناخ  </translation>
    </message>
    <message utf8="true">
        <source>Alarma de Intrusión</source>
        <translation type="obsolete"> جهاز الإقتحام </translation>
    </message>
    <message utf8="true">
        <source>Alarma de Coacción</source>
        <translation type="obsolete">جهاز إنذار الإجبار </translation>
    </message>
    <message utf8="true">
        <source>Alarma de Inundación</source>
        <translation type="obsolete">إنذار الفيضان  </translation>
    </message>
    <message utf8="true">
        <source>Alarma de Corte de suministro eléctrico</source>
        <translation type="obsolete">إنذار إنقطاع التيار </translation>
    </message>
    <message utf8="true">
        <source>Alarma de Corte de teléfono</source>
        <translation type="obsolete">إنذار إنقطاع الهاتف </translation>
    </message>
    <message utf8="true">
        <source>Alarma Médica</source>
        <translation type="obsolete">جهاز الإنذار  الطّبّي</translation>
    </message>
    <message utf8="true">
        <source>Alarma de Pánico</source>
        <translation type="obsolete">جهاز الإنذار الهلع </translation>
    </message>
    <message>
        <source>Luces</source>
        <translation type="obsolete">الإنارة </translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation type="obsolete">جميع الأضواء </translation>
    </message>
    <message>
        <source> - Todas las luces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Apagar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - ON/OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Regulable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - RGB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los tipos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Individual: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Zona: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Persiana normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Persiana posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Persianas agupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cualquier persiana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Toldo normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Toldo posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Toldos agupados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cualquier toldo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cortina normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cortina posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cortinas agupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cualquier cortina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Puerta motorizada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los dispositivos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Encender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Apagado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Modo manual - </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation type="unfinished">ºC</translation>
    </message>
    <message>
        <source> - Modo programa</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source> - Modo económico - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los riegos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Activar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Desactivar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Retardo - </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation type="unfinished"> جهاز الإقتحام </translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation type="unfinished">إنذار الحريق</translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation type="unfinished">إنذار الغاز</translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation type="unfinished">إنذار الفيضان  </translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte de teléfono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation type="unfinished">إنذار النظام  </translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation type="unfinished">جهاز الإنذار  الطّبّي</translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation type="unfinished">جهاز الإنذار الهلع </translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation type="unfinished">الإنذار الكتوم </translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation type="unfinished">إنذار تخريب </translation>
    </message>
    <message utf8="true">
        <source>Alarma de coacción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation type="unfinished"> نزع جهاز الإنذار </translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - No temporizados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Temporizados</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindowClass</name>
    <message>
        <source>ScenesConfigWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق  </translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>إعادة تسمية </translation>
    </message>
    <message>
        <source>Modificar</source>
        <translation type="obsolete">Modify</translation>
    </message>
    <message>
        <source>Eliminar
Accion </source>
        <translation type="obsolete">Delete action</translation>
    </message>
    <message>
        <source>Eliminar
Escena</source>
        <translation type="obsolete">Delete
scene</translation>
    </message>
    <message>
        <source>Condiciones</source>
        <translation type="obsolete">Conditions</translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindow</name>
    <message>
        <source>Nombre</source>
        <translation>الإسم </translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la escena.
¿Está seguro?</source>
        <translation>السيناريو على وشك المحو ... هل تودّ الإستئناف؟ </translation>
    </message>
    <message>
        <source>Eliminar escena...</source>
        <translation>مسح السيناريو </translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindowClass</name>
    <message>
        <source>Form</source>
        <translation>الصّيغة</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق</translation>
    </message>
</context>
<context>
    <name>ScenesWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindow</name>
    <message>
        <source>Castellano</source>
        <translation>الإسبانية </translation>
    </message>
    <message utf8="both">
        <source>Inglés</source>
        <translation type="unfinished">English</translation>
    </message>
    <message utf8="both">
        <source>Portugués</source>
        <translation type="unfinished">Portuguese</translation>
    </message>
    <message utf8="both">
        <source>Francés</source>
        <translation type="unfinished">French</translation>
    </message>
    <message utf8="both">
        <source>Alemán</source>
        <translation type="unfinished">German</translation>
    </message>
    <message>
        <source>Euskera</source>
        <translation>الباسكية </translation>
    </message>
    <message utf8="both">
        <source>Catalán</source>
        <translation type="unfinished">Catalan</translation>
    </message>
    <message>
        <source>Gallego</source>
        <translation>الغليغو</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation type="obsolete">ظلام </translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>لا شيء </translation>
    </message>
    <message>
        <source>Marco de fotos digital</source>
        <translation>إطار  الصّورة الإلكتروني</translation>
    </message>
    <message>
        <source>Reloj/Temperatura</source>
        <translation type="obsolete">الوقت/الحرارة </translation>
    </message>
    <message>
        <source>Grey Ligth</source>
        <translation type="obsolete">الضوء الرمادي </translation>
    </message>
    <message utf8="true">
        <source>Botón</source>
        <translation>زرّ</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>حركة </translation>
    </message>
    <message>
        <source>Turco</source>
        <translation>التركية </translation>
    </message>
    <message utf8="true">
        <source>Árabe</source>
        <translation>عربي</translation>
    </message>
    <message>
        <source>Green</source>
        <translation type="obsolete">اخضر</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>برتقالي</translation>
    </message>
    <message>
        <source>Azul</source>
        <translation type="unfinished">ازرق</translation>
    </message>
    <message>
        <source>Negro</source>
        <translation type="unfinished">اسود</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation type="unfinished">اخضر</translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation type="unfinished">احمر</translation>
    </message>
    <message>
        <source>Italiano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>20 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>40 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>60 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>80 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>100 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 minuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5 minuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>10 minuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>15 minuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>30 minuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nunca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oscuro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(vacio)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>الصّيغة</translation>
    </message>
    <message>
        <source>General</source>
        <translation>عام </translation>
    </message>
    <message>
        <source> Identificador de pantalla</source>
        <translation>تحديد  الشّاشة</translation>
    </message>
    <message>
        <source> Idioma</source>
        <translation>اللّغة</translation>
    </message>
    <message>
        <source> Volumen</source>
        <translation>الصّوت</translation>
    </message>
    <message>
        <source> Brillo</source>
        <translation type="obsolete">السّطوع</translation>
    </message>
    <message>
        <source>Sonido teclado</source>
        <translation>صوت الكيبورد</translation>
    </message>
    <message>
        <source>Sensor de presencia</source>
        <translation>كاشف الحضور </translation>
    </message>
    <message>
        <source> Color</source>
        <translation type="obsolete">اللّون</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق  </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message>
        <source>Salvapantallas</source>
        <translation>الشاشة   </translation>
    </message>
    <message>
        <source> Salvapantallas</source>
        <translation>حارس الشاشة</translation>
    </message>
    <message utf8="true">
        <source> Activación Salvapantallas</source>
        <translation>تفعيل حارس الشاشة</translation>
    </message>
    <message>
        <source> Tiempo entre fotos</source>
        <translation>الوقت ما بين الصور </translation>
    </message>
    <message>
        <source> Autoapagado</source>
        <translation>إغلاق ذاتي </translation>
    </message>
    <message>
        <source>Botones</source>
        <translation>المفاتيح </translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation type="obsolete">Action</translation>
    </message>
    <message>
        <source>Arriba</source>
        <translation type="obsolete">Up</translation>
    </message>
    <message>
        <source>Abajo</source>
        <translation type="obsolete">Down</translation>
    </message>
    <message utf8="true">
        <source>Nueva acción</source>
        <translation type="obsolete">New action</translation>
    </message>
    <message utf8="true">
        <source>Eliminar acción</source>
        <translation type="obsolete">Delete action</translation>
    </message>
    <message>
        <source>QTabBar::tab {
	min-height: 20px;
    padding: 8px;
 }</source>
        <translation type="obsolete">QTabBar::tab {	min-height: 20px;    padding: 8px; }</translation>
    </message>
    <message>
        <source> Paleta</source>
        <translation>لوحة الالوان</translation>
    </message>
    <message>
        <source> Color iconos</source>
        <translation>الوان الايكنس</translation>
    </message>
    <message>
        <source>Offset de temperatura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visualizar cursor</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para ejecutar escenas</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Habilitación tamper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IP</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScreenSaver</name>
    <message>
        <source>%1:%2
%3/%4/%5</source>
        <translation type="obsolete">%1:%2
%3/%4/%5</translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindow</name>
    <message>
        <source>Armado total</source>
        <translation>جهاز الإنذار في حالة إستعداد</translation>
    </message>
    <message>
        <source>Armado parcial</source>
        <translation>جهاز إنذار جزئي </translation>
    </message>
    <message>
        <source>Armado perimetral</source>
        <translation>جهاز الإنذار في حالة تهميش </translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished">لا شيء </translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Intrusión</source>
        <translation>  الإقتحام </translation>
    </message>
    <message utf8="true">
        <source>Llamar en caso de intrusión a:</source>
        <translation type="obsolete">In case of intrusion call:</translation>
    </message>
    <message utf8="true">
        <source>Habilitación el autoarmado de intrusión</source>
        <translation type="obsolete">تفعيل التشغيل الذاتي لإنذار الإقتحام </translation>
    </message>
    <message>
        <source>Armado Perimetral</source>
        <translation type="obsolete">Peripheral arming</translation>
    </message>
    <message>
        <source>Armado Parcial</source>
        <translation type="obsolete">Partial arming</translation>
    </message>
    <message>
        <source>Armado Total</source>
        <translation type="obsolete">Full arming</translation>
    </message>
    <message>
        <source>Programa asociado el autoarmado</source>
        <translation> البرنامج  المترابط بالتفعيل الذاتي  </translation>
    </message>
    <message>
        <source>Viernes...</source>
        <translation type="obsolete">Friday...</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message utf8="true">
        <source>Activar simulación de presencia con el armado total</source>
        <translation>تفعيل  تامّ لتظاهر الحضور عند خلاء المنزل </translation>
    </message>
    <message utf8="true">
        <source>Tiempo mínimo de armado (seg):</source>
        <translation type="obsolete">الوقت الادنى  للتفعيل</translation>
    </message>
    <message utf8="true">
        <source> Retraso a la activación (seg):</source>
        <translation type="obsolete">تأخير في التفعيل </translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation>حريق</translation>
    </message>
    <message>
        <source>Llamar en caso de incendio a:</source>
        <translation type="obsolete">In case of fire call:</translation>
    </message>
    <message>
        <source>Gas</source>
        <translation>غاز </translation>
    </message>
    <message>
        <source>Llamar en caso de alarma de gas a:</source>
        <translation type="obsolete">In case of gas alarm call:</translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation>طوفان </translation>
    </message>
    <message utf8="true">
        <source>Llamar en caso de inundación a:</source>
        <translation type="obsolete">In case of flooding call:</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (seg):</source>
        <translation type="unfinished">تأخير في التفعيل (س)</translation>
    </message>
    <message utf8="true">
        <source>Corte Red Eléctrica</source>
        <translation>إنقطاع التيار الكهربائي</translation>
    </message>
    <message utf8="true">
        <source>Llamar en caso de corte en la red eléctrica a:</source>
        <translation type="obsolete">In case of power fail call:</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (min):</source>
        <translation>تأخير في التفعيل </translation>
    </message>
    <message utf8="true">
        <source>Corte teléfono</source>
        <translation>إنقطاع خطّ الهاتف</translation>
    </message>
    <message utf8="true">
        <source>Llamar en caso de corte de teléfono a:</source>
        <translation type="obsolete">In case of telephone fail call:</translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation>النّظام</translation>
    </message>
    <message>
        <source>Llamar en caso de alarma de sistema a:</source>
        <translation type="obsolete">In case of system alarm call:</translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation>الطّبّيّة</translation>
    </message>
    <message utf8="true">
        <source>Llamar en caso de alarma médica a:</source>
        <translation type="obsolete">In case of medical alarm call:</translation>
    </message>
    <message utf8="true">
        <source>Detección de inactividad</source>
        <translation>إكتشاف عدم الحركة </translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation>هلع</translation>
    </message>
    <message utf8="true">
        <source>Llamar en caso de alarma de pánico a:</source>
        <translation type="obsolete">In case of panic alarm call:</translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation>كتم الصّوت</translation>
    </message>
    <message>
        <source>Llamar en caso de alarma silenciosa a:</source>
        <translation type="obsolete">In case of silent alarm call:</translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation>تخريب   </translation>
    </message>
    <message>
        <source>Llamar en caso de sabotaje a:</source>
        <translation type="obsolete">In case of sabotage alarm call:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق </translation>
    </message>
    <message>
        <source>QTabBar::tab {
	min-height: 20px;
    padding: 8px;
 }</source>
        <translation type="obsolete">QTabBar::tab {	min-height: 20px;    padding: 8px; }</translation>
    </message>
    <message>
        <source>Llamar en caso de alarma a:</source>
        <translation>في حال الإنذار  الإتّصال ب</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 1</source>
        <translation>Telephone 1</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 2</source>
        <translation>Telephone 2</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 3</source>
        <translation>Telephone 3</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 4</source>
        <translation>Telephone 4</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 5</source>
        <translation>Telephone 5</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 6</source>
        <translation>Telephone 6</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 7</source>
        <translation>Telephone 7</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 8</source>
        <translation>Telephone 8</translation>
    </message>
    <message utf8="true">
        <source>Habilitar autoarmado de intrusión</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo de salida de la vivienda (seg):</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para armar la alarma de intrusión</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Hora de auto limpieza de la electroválvula de agua:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Armado Perimetral</source>
        <translation>جهاز الإنذار في حالة تهميش </translation>
    </message>
    <message>
        <source>Armado Parcial</source>
        <translation>جهاز إنذار جزئي </translation>
    </message>
    <message>
        <source>Armado Total</source>
        <translation>جهاز الإنذار في حالة إستعداد</translation>
    </message>
</context>
<context>
    <name>SelectActionClass</name>
    <message>
        <source>Aplicar</source>
        <translation type="obsolete">Validate</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="obsolete">Cancel</translation>
    </message>
    <message utf8="true">
        <source>Selecciona la acción:</source>
        <translation type="obsolete">Select action:</translation>
    </message>
</context>
<context>
    <name>SensorControl</name>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SensorControlClass</name>
    <message>
        <source>SensorControl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Deshabilitar sensor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interviene en el armado parcial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interviene en el armado perimetral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo de entrada:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Offset de temperatura:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Retraso a la activacion:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SystemConfigWindow</name>
    <message>
        <source>www.tiempo.es</source>
        <translation type="obsolete">www.alta2is.com</translation>
    </message>
    <message>
        <source>www.periodico.es</source>
        <translation type="obsolete">www.alakhbar.com</translation>
    </message>
    <message>
        <source>www.bolsa.es</source>
        <translation type="obsolete">www.albursa.com</translation>
    </message>
    <message>
        <source>www.viajes.es</source>
        <translation type="obsolete">www.harakatalsir.com</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a importar ficheros.
Por favor, no saque el dispositivo durante la importación.
 ¿Desea continuar?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importando...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a exportar ficheros.
Por favor, no saque el dispositivo durante la exportación.
¿Desea continuar?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exportando...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actualizando...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Firmware.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Webserver.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Para proceder a calibrar el touch es necesario reiniciar la pantalla.
¿Desea continuar?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calibrar Touch...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test Alarmas: %1
Pulse para %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation type="unfinished">تعطيل </translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Activar</source>
        <translation type="unfinished">تفعيل </translation>
    </message>
    <message>
        <source>Activar licencia</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SystemConfigWindowClass</name>
    <message>
        <source>SystemConfigWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Internet</source>
        <translation type="obsolete">انترنت </translation>
    </message>
    <message>
        <source>Y/N</source>
        <translation type="obsolete">نعم/كلّا</translation>
    </message>
    <message>
        <source>Link</source>
        <translation type="obsolete">الإرتباط</translation>
    </message>
    <message>
        <source>Imagen / Texto</source>
        <translation type="obsolete">الأيكن</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="obsolete">تطبيق  </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق</translation>
    </message>
    <message>
        <source>Reset del Sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exportar Ficheros</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importar  Ficheros</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acceder como
instalador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actualizar
Firmware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recalibrar Touch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log de Errores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actualizar
WebServer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prueba de alarmas: %1
Pulse para %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test llamadas CRA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licencia...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished">Textlabel</translation>
    </message>
</context>
<context>
    <name>UsersConfigWindow</name>
    <message>
        <source>Maestro</source>
        <translation>الرئيسة </translation>
    </message>
    <message>
        <source>Alto</source>
        <translation>عال  </translation>
    </message>
    <message>
        <source>Medio</source>
        <translation>وسط </translation>
    </message>
    <message>
        <source>Bajo</source>
        <translation>متدنّي</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>أدخل الإسم الجديد</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>الإسم </translation>
    </message>
    <message>
        <source>Clave</source>
        <translation>الرّمز</translation>
    </message>
    <message>
        <source>Nivel Acceso</source>
        <translation>مستوى الإذن لدخول النظام </translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el usuario.
¿Está seguro?</source>
        <translation>المستخدم على وشك المحو ... هل تودّ الإستئناف؟ </translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation>إلغاء علاقة </translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>الرّجاء إدخال المعلومات النّاقصة...</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>خلل </translation>
    </message>
    <message utf8="true">
        <source>Introduzca la nueva contraseña</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No se puede eliminar el único usuario maestro del sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Eliminación de usuario interrumpida.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UsersConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="obsolete">Name</translation>
    </message>
    <message>
        <source>Clave</source>
        <translation type="obsolete">Code</translation>
    </message>
    <message>
        <source>Nivel Acceso</source>
        <translation type="obsolete">Access level</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Microsoft Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Nivel de seguridad&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;del sistema&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Microsoft Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;System security level&lt;/p&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Leer Llave</source>
        <translation>إقرأ المفتاح </translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>تطبيق  </translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>إغلاق   </translation>
    </message>
    <message>
        <source>Nivel de seguridad
del sistema</source>
        <translation type="obsolete">نظام مستوى  الأمن </translation>
    </message>
</context>
<context>
    <name>WarningDialog</name>
    <message utf8="true">
        <source>Fallo en el sistema de avisos telefónicos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test de CRA fallido.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Aviso de cancelación de alarma de intrusión fallido.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Armado de intrusión cancelado. Sensor no temporizado activo:
%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Climatizador apagado por ventana abierta:
%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entrada de sensor en circuito abierto:
%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Cámara de videoportería ocupada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No se ha encontrado el mensaje que se desea reproducir.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No hay espacio para grabar más mensajes de voz, o se ha alcanzado el límite de 10 mensajes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Error en la comunicación con el módulo %1:
Comando rechazado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error al iniciar el sistema de ficheros. Compruebe si la tarjeta SD de la central funciona correctamente.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>El estado de la batería es bajo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Perdidas de tramas en la comunicación.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Comunicación recuperada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Mensaje de Aviso Nº%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No hay batería o la batería falla.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El test CRA ha sido satisfactorio.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Número de mensaje desconocido %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test de CRA...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WarningDialogClass</name>
    <message>
        <source>WarningDialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation type="unfinished">&lt;&lt;</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation type="unfinished">&gt;&gt;</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ZoneSelect</name>
    <message>
        <source>luces</source>
        <translation>الإنارة </translation>
    </message>
    <message>
        <source>clima</source>
        <translation>المناخ</translation>
    </message>
    <message>
        <source>dispositivos</source>
        <translation>المقابيس</translation>
    </message>
    <message>
        <source>persianas</source>
        <translation>الأباجورات </translation>
    </message>
    <message>
        <source>riegos</source>
        <translation>أنظمة  الرّيّ</translation>
    </message>
    <message>
        <source>toldos</source>
        <translation>المظلات </translation>
    </message>
    <message>
        <source>sensores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cortinas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>puertas</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ZoneSelectClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
</context>
</TS>
