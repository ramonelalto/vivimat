<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="tr_TR" sourcelanguage="es_ES">
<context>
    <name>AlarmDialog</name>
    <message utf8="true">
        <source>ALARMA DE INTRUSIÓN</source>
        <translation>Hırsız Alarm</translation>
    </message>
    <message>
        <source>ALARMA DE FUEGO</source>
        <translation>Yangın Alarm</translation>
    </message>
    <message>
        <source>ALARMA DE GAS</source>
        <translation>Gaz Alarm</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE INUNDACIÓN</source>
        <translation>Su Taşkın Alarm</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE ELÉCTRICO</source>
        <translation>Güç Arızası</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE TELEFÓNICO</source>
        <translation>Telefon arızası alarmı</translation>
    </message>
    <message>
        <source>ALARMA DE SISTEMA</source>
        <translation>Sistem Alarm</translation>
    </message>
    <message utf8="true">
        <source>ALARMA MÉDICA</source>
        <translation>Tıbbi Alarm</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE PÁNICO</source>
        <translation>Panik Alarm</translation>
    </message>
    <message>
        <source>ALARMA SILENCIOSA</source>
        <translation>Hareketsizlik Alarm</translation>
    </message>
    <message>
        <source>ALARMA DE SABOTAJE</source>
        <translation>Sabotaj Alarm</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE COACCIÓN</source>
        <translation>Tehdit Alarm</translation>
    </message>
    <message>
        <source>
 en las siguientes zonas:
</source>
        <translation>
Aşağıdaki bölgede:</translation>
    </message>
    <message>
        <source>REARMAR ALARMAS</source>
        <translation>Alarmı tekrar kur</translation>
    </message>
    <message>
        <source>Hay alarmas desarmadas. Pulse rearmar para volver a proteger el sistema.</source>
        <translation>Aktif olmayan alarmlar mevcut. Sistemi korumaya almak için alarmı tekrar kur a basın.</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar alarmas</source>
        <translation>Alarmı iptal etmek için şifre girin</translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 90 segundos.</source>
        <translation type="unfinished">Sistem asmak anahtar tanıtmak için üç deneme başarısız oldu sonra.
  Için tekrar girin şifreyi 90 saniye bekleyin.</translation>
    </message>
    <message>
        <source>Sistema bloqueado</source>
        <translation type="unfinished">Sistem asmak</translation>
    </message>
</context>
<context>
    <name>AlarmDialogClass</name>
    <message>
        <source>AlarmDialog</source>
        <translation>AlarmDialog</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Alarmı Kapat</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation>&lt;&lt;</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation>&gt;&gt;</translation>
    </message>
    <message utf8="true">
        <source>Menú
Alarmas</source>
        <translation>Alarmlar</translation>
    </message>
    <message>
        <source>Rearmar</source>
        <translation>Alarmı kur</translation>
    </message>
</context>
<context>
    <name>AlarmsWindow</name>
    <message>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>AÇIK</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>KAPALI</translation>
    </message>
</context>
<context>
    <name>AlarmsWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation>Yangın</translation>
    </message>
    <message>
        <source>Gas</source>
        <translation>Gaz</translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation>Su Taşkını</translation>
    </message>
    <message utf8="true">
        <source>Corte Eléctrico</source>
        <translation>Elektrik arıza</translation>
    </message>
    <message utf8="true">
        <source>Corte de Teléfono</source>
        <translation>Telefon arızası</translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation>Sistem</translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation>Tıbbi</translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation>Panik</translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation>Hareketsizlik</translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation>Sabotaj</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation>MetinEtiketi</translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation>Tehdit</translation>
    </message>
</context>
<context>
    <name>ArmingWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Armando...</source>
        <translation>birleştirmek...</translation>
    </message>
</context>
<context>
    <name>AssociatedZonesClass</name>
    <message>
        <source>AssociatedZones</source>
        <translation>AssociatedZones</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Aşağı</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Yukarı</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message utf8="true">
        <source>Zonas asociadas con la unidad climática...</source>
        <translation>Isı kontrolleri ile ilişkili bölgeler...</translation>
    </message>
</context>
<context>
    <name>BlackboardWindowClass</name>
    <message>
        <source>BlackboardWindow</source>
        <translation>BlackboardWindow</translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation>Kaydet</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Sil</translation>
    </message>
</context>
<context>
    <name>BlindControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Hiçbiri</translation>
    </message>
    <message>
        <source>Grupo de persianas</source>
        <translation>Panjur grubu</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Durum bilinmiyor</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuel</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
</context>
<context>
    <name>BlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>İlgili program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Yeniad</translation>
    </message>
    <message>
        <source>Bajar persianas en caso de lluvia</source>
        <translation>Yağmur durumunda panjurları kapat</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Açılma/Kapanma zamanı:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Fonksiyon modu:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Simge değiştir</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Bölge</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Cihaz.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Hepsi</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Bajar persianas en caso de viento fuerte</source>
        <translation>Güçlü rüzgarda panjurları kapat</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DOWN</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CRAConfigDialog</name>
    <message>
        <source>ADEMCO CID</source>
        <translation>ADEMCO CID</translation>
    </message>
    <message utf8="true">
        <source>Introduzca el código de abonado ...</source>
        <translation>Üyelik kodunu girin...</translation>
    </message>
</context>
<context>
    <name>CRAConfigDialogClass</name>
    <message>
        <source>CRAConfigDialog</source>
        <translation>AIMAyarEkranı</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Configuracion CRA</source>
        <translation>AIM Ayarları</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Habilitacion</source>
        <translation>Mevcut</translation>
    </message>
    <message>
        <source>border: solid;</source>
        <translation type="obsolete">Çizgi:Katı;</translation>
    </message>
    <message>
        <source>Cambiar
Codigo</source>
        <translation>Kod 
değiştir</translation>
    </message>
    <message>
        <source>Protocolo</source>
        <translation>Protokol</translation>
    </message>
    <message>
        <source>Autotest</source>
        <translation>Ototest</translation>
    </message>
    <message>
        <source>Cadencia</source>
        <translation>Zaman farkı</translation>
    </message>
    <message>
        <source>Hora del primer test</source>
        <translation>İlk testin zamanı</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>SS:dd</translation>
    </message>
    <message>
        <source>Codigo de cuenta</source>
        <translation>Giriş kodu</translation>
    </message>
</context>
<context>
    <name>CamsWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation>Girişi ara</translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation>Giriş ile bağlantı kuruldu</translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation>Şu anda zaten başka bir panelden bağlantı olduğu için bağlantı kurulamıyor.</translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation>Görüntülü diyafon meşgul</translation>
    </message>
</context>
<context>
    <name>CamsWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation>Konuş</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Aç</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation>Ses aç.</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation>Ses kapat.</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Yukarı</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Aşağı</translation>
    </message>
    <message>
        <source>Izquierda</source>
        <translation>Sol</translation>
    </message>
    <message>
        <source>Derecha</source>
        <translation>Sağ</translation>
    </message>
</context>
<context>
    <name>ClimaControl</name>
    <message utf8="true">
        <source>Frío</source>
        <translation>Soğukluk</translation>
    </message>
    <message>
        <source>Calor</source>
        <translation>Isı</translation>
    </message>
    <message>
        <source>Climatizador</source>
        <translation>Isı kontrol</translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation>Kapalı</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Hiçbiri</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
</context>
<context>
    <name>ClimaControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Modo general:</source>
        <translation>Genel mod:</translation>
    </message>
    <message>
        <source>Primer programa asociado:</source>
        <translation>İlk ilgili program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Yeniad</translation>
    </message>
    <message utf8="true">
        <source>Apagar climatización en caso de ventana abierta</source>
        <translation>Pencere açık olması durumunda klimayı kapat</translation>
    </message>
    <message>
        <source>Consig. Min:</source>
        <translation>min.sıcaklık:</translation>
    </message>
    <message>
        <source>Consig. Max:</source>
        <translation>maks.sıcaklık:</translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source>Zonas
Asociadas</source>
        <translation>ilişkili
bölgeler</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Simge değiştir</translation>
    </message>
    <message>
        <source>Sensor de temperatura asociado:</source>
        <translation>İlişkili ısı sensörü:</translation>
    </message>
    <message>
        <source>Histeresis:</source>
        <translation>Hassasiyet:</translation>
    </message>
    <message>
        <source>Segundo programa asociado:</source>
        <translation>Ikinci ilgili program:</translation>
    </message>
    <message>
        <source>modo</source>
        <translation>mod</translation>
    </message>
    <message utf8="true">
        <source>0ºC</source>
        <translation>0ºC</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Cihaz.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Hepsi</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>ClimaWindow</name>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
</context>
<context>
    <name>ClimaWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>KAPAT</translation>
    </message>
    <message>
        <source>MANUAL</source>
        <translation>Manuel</translation>
    </message>
    <message>
        <source>PROGRAMA</source>
        <translation>Program</translation>
    </message>
    <message>
        <source>ECO</source>
        <translation>EKO</translation>
    </message>
    <message utf8="true">
        <source>--ºC</source>
        <translation>--ºC</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Aşağı</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Yukarı</translation>
    </message>
</context>
<context>
    <name>ConfigWindow</name>
    <message utf8="true">
        <source>Vivimat III

versión %1.%2.%3

[%4]</source>
        <translation>Vivimat III

versiyon %1.%2.%3

[%4]</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión 0.2.0</source>
        <translation type="obsolete">Vision Color 7 

version 0.2.0</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión 0.6.4</source>
        <translation type="obsolete">Vision Color 7 

versiyon 0.6.4 </translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión %1.%2.%3</source>
        <translation type="obsolete">Vision Color 7

versiyon %1.%2.%3</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión %1.%2.%3
</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Sistema de ficheros

Versión: %1</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Vivimat III

versión Demo %1.%2.%3

[%4]</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión Demo %1.%2.%3
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>mando IR</source>
        <translation>IR uzaktan kumanda</translation>
    </message>
    <message>
        <source>programas horarios</source>
        <translation>Zaman programı</translation>
    </message>
    <message>
        <source>multimedia</source>
        <translation>Multimedya</translation>
    </message>
    <message utf8="true">
        <source>gestión de energía</source>
        <translation>Enerji yönetimi</translation>
    </message>
    <message>
        <source>escenas</source>
        <translation>Senaryolar</translation>
    </message>
    <message utf8="true">
        <source>telefonía</source>
        <translation>Telefon</translation>
    </message>
    <message>
        <source>usuarios</source>
        <translation>Kullanıcılar</translation>
    </message>
    <message>
        <source>sistema</source>
        <translation>Sistem</translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation>Güvenlik</translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation>Diyafon</translation>
    </message>
    <message>
        <source>fecha y hora</source>
        <translation>Tarih ve saat</translation>
    </message>
    <message>
        <source>pantalla</source>
        <translation>Ekran</translation>
    </message>
</context>
<context>
    <name>ConfirmationDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation>Doğrulama penceresi</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Kabul</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>İptal</translation>
    </message>
</context>
<context>
    <name>ConsumptionWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished">Form</translation>
    </message>
    <message>
        <source>Escala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Semana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mes</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Año</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unidades</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unit3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CurtainControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Hiçbiri</translation>
    </message>
    <message>
        <source>Grupo de cortinas</source>
        <translation>Perde grubu</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Durum bilinmiyor</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuel</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
</context>
<context>
    <name>CurtainControlClass</name>
    <message>
        <source>CurtainControl</source>
        <translation>Perde Kontrol</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>İlgili program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Yeniad</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Fonksiyon modu:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Simge değiştir</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Açılma/Kapanma zamanı:</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Bölge</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Cihaz.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Hepsi</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>DateHourWindow</name>
    <message>
        <source>Lunes</source>
        <translation>Pazartesi</translation>
    </message>
    <message>
        <source>Martes</source>
        <translation>Salı</translation>
    </message>
    <message utf8="true">
        <source>Miércoles</source>
        <translation>Çarşamba</translation>
    </message>
    <message>
        <source>Jueves</source>
        <translation>Perşembe</translation>
    </message>
    <message>
        <source>Viernes</source>
        <translation>Cuma</translation>
    </message>
    <message utf8="true">
        <source>Sábado</source>
        <translation>Cumartesi</translation>
    </message>
    <message>
        <source>Domingo</source>
        <translation>Pazar</translation>
    </message>
</context>
<context>
    <name>DateHourWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>/</source>
        <translation>/</translation>
    </message>
    <message>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
</context>
<context>
    <name>DoorControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Hiçbiri</translation>
    </message>
    <message>
        <source>Abierta</source>
        <translation>Açık</translation>
    </message>
    <message>
        <source>Cerrada</source>
        <translation>Kapalı</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Durum bilinmiyor</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Aç</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuel</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
</context>
<context>
    <name>DoorControlClass</name>
    <message>
        <source>DoorControl</source>
        <translation>Kapı kontrol</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>İlgili program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Yeniad</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Fonksiyon modu:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Simge değiştir</translation>
    </message>
    <message>
        <source>Tiempo de apertura / cierre:</source>
        <translation>Açılma/Kapanma zamanı:</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Bölge</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Cihaz.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Hepsi</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Aç</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>DoorphoneDialog</name>
    <message>
        <source>Dialog</source>
        <translation>diyalog</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>İptal</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Kabul</translation>
    </message>
    <message>
        <source>Llamada VIDEOPORTERO</source>
        <translation>Görüntülü interkom araması</translation>
    </message>
    <message>
        <source>Llamada desde videoportero</source>
        <translation>Video girişinden Çağrı</translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation>Girişi ara</translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation>Giriş ile bağlantı kuruldu</translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation>Şu anda zaten başka bir panelden bağlantı olduğu için bağlantı kurulamıyor.</translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation>Görüntülü diyafon meşgul</translation>
    </message>
    <message>
        <source>Conserje no contesta.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación, otra lladama en curso.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conserge ocupado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation>Konuş</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Aç</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation type="obsolete">Ses kapat.</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation type="obsolete">Ses aç.</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Aşağı</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Yukarı</translation>
    </message>
    <message utf8="true">
        <source>Portería</source>
        <translation>Giriş</translation>
    </message>
    <message>
        <source>Ver</source>
        <translation>BKZ</translation>
    </message>
</context>
<context>
    <name>EntryphoneConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message utf8="true">
        <source>Habilitar Desvío</source>
        <translation>Yönlendirmeyi aç</translation>
    </message>
    <message>
        <source>Habilitar Contestador</source>
        <translation>Telesekreteri aç</translation>
    </message>
    <message utf8="true">
        <source>Contacto al que se desvía la llamada:</source>
        <translation>Yönlendirilecek kişi:</translation>
    </message>
    <message>
        <source>Habilitar llamada desde puerta de entrada</source>
        <translation>Girişten aramayı aç</translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation>Kişisel mesajlar</translation>
    </message>
    <message utf8="true">
        <source>Número de veces que sonara: </source>
        <translation>Sistem çalma saysı: </translation>
    </message>
</context>
<context>
    <name>FileTransfer</name>
    <message>
        <source>Aplicacion DEMO para Windows.Simulando la transferencia de ficheros.</source>
        <translation>Windows için demo uygulaması. Simülasyon dosyaları trasferi.</translation>
    </message>
    <message>
        <source>Se ha encontrado una tarjeta SD.No saque la tarjeta hasta que finalice el intercambio de ficheros.</source>
        <translation>SD kart bulundu.Transfer bitene kadar çıkarmayınız. </translation>
    </message>
    <message>
        <source>Se ha encontrado un dispositivo USB.No saque el dispositivo hasta que finalice el intercambio de ficheros.</source>
        <translation>USB cihazı bulundu.Transfer bitene kadar çıkarmayınız. </translation>
    </message>
    <message utf8="true">
        <source>No se ha encontrado ningún dispositivo.Pulsa cancelar para salir.</source>
        <translation>Aygıt bulunamadı. Çıkmak için iptal e basınız.</translation>
    </message>
    <message utf8="true">
        <source>La actualización ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation>Güncelleme tamamlandı. Sistemin yeniden başlatılması gerekiyor.</translation>
    </message>
    <message utf8="true">
        <source>La exportación ha finalizado.Pulsa Aceptar para continuar.</source>
        <translation>Trasfer tamamlandı.Devam etmek için Kabul e basın.</translation>
    </message>
    <message utf8="true">
        <source>La importación ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation>Transfer tamamlandı. Sistemin yeniden başlatılması gerekiyor.</translation>
    </message>
    <message>
        <source>No existe un fichero de firmware. Inserte un dispositivo con un fichero de firmware.</source>
        <translation>Firmware dosyası yoktur. Firmware dosyasına sahip bir aygıt takın.</translation>
    </message>
    <message>
        <source>Error a la hora de copiar el nuevo firmware.</source>
        <translation>Yeni firmware kopyalarken hata oluştu.</translation>
    </message>
    <message utf8="true">
        <source>La copia del programa de calibración ha fallado.</source>
        <translation type="obsolete">Kalibrasyon kopyası başarısız oldu.</translation>
    </message>
    <message utf8="true">
        <source>No se encuentran todos los ficheros necesarios para la actualizacion del servidor web.
No se ha podido realizar la actualización.</source>
        <translation>Web sunucusu güncelleştirmek için gerekli tüm dosyalar bulunmaktadır.
Yükseltme yapılamıyor.</translation>
    </message>
    <message utf8="true">
        <source>La actualización ha fallado. Se mantiene el viejo rcS.</source>
        <translation>Güncelleştirme başarısız oldu. O eski rcS tutar.</translation>
    </message>
    <message>
        <source>cp -rf %1/PantallaColor /App/PantallaColor</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>FileTransferClass</name>
    <message>
        <source>FileTransfer</source>
        <translation>DosyaTransferi</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Kabul</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>İptal</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>FloorSelectClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Aşağı</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Yukarı</translation>
    </message>
</context>
<context>
    <name>HistoryWindow</name>
    <message>
        <source>Historial de Eventos</source>
        <translation>Olay kayıtları</translation>
    </message>
    <message>
        <source>Historial de Errores</source>
        <translation>Hata günlükleri</translation>
    </message>
</context>
<context>
    <name>HistoryWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Historial de Eventos</source>
        <translation>Olay geçmişi</translation>
    </message>
    <message>
        <source>01/01/2010 13:39:05 &gt; System initialization completed
01/01/2010 13:45:15 &gt; Intrusion alarm armed in total mode: Sergio
01/01/2010 13:50:05 &gt; Intrusion alarm disarmed: Sergio
</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
</context>
<context>
    <name>IRCodeReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Apunte el mando hacia el
receptor y pulse la tecla
correspondiente...</source>
        <translation>Uzaktan kumandayı alıcıya
doğru yöneltip basınız...</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message utf8="true">
        <source>Leer código de infrarrojos</source>
        <translation>IR kodları oku</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindow</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation>Senaryoyu çalıştır</translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation>Çevresel mod hırsız alarmı</translation>
    </message>
    <message utf8="true">
        <source>Activar pánico</source>
        <translation>Panik aktive et</translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation>Görüntülü diyafonu aç</translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation>Işık aç</translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation>Işık kapat</translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation>Işık seviyesini yükselt</translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation>Işık seviyesini düşür</translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation>Motor yukarı</translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation>Motor aşağı</translation>
    </message>
    <message>
        <source>Encender clima</source>
        <translation>Isı kontrol</translation>
    </message>
    <message>
        <source>Apagar clima</source>
        <translation>Klima kontrol kapat</translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation>Priz aç</translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation>Priz kapat</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Ad</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Eylem</translation>
    </message>
    <message utf8="true">
        <source>Código IR</source>
        <translation>IR Kod</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la acción.
¿Está seguro?</source>
        <translation>Eylem silinecek.
Devem etmek istiyor musunuz?</translation>
    </message>
    <message utf8="true">
        <source>Eliminar acción...</source>
        <translation>Eylemi sil...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Lütfen eksik veriyi girin.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Hata...</translation>
    </message>
    <message>
        <source> - ON/OFF -</source>
        <translation> - AÇ/KAPAT -</translation>
    </message>
    <message>
        <source> - Regulable -</source>
        <translation>-Ayarlanabilir-</translation>
    </message>
    <message>
        <source> - RGB -</source>
        <translation>-RGB-</translation>
    </message>
    <message>
        <source> - Todos los tipos -</source>
        <translation>- Tüm çeşitler -</translation>
    </message>
    <message>
        <source> Individual - </source>
        <translation>- Kişisel -</translation>
    </message>
    <message>
        <source> Zona - </source>
        <translation>Bölge -</translation>
    </message>
    <message>
        <source> Todas las luces</source>
        <translation>Tüm Işıklar</translation>
    </message>
    <message>
        <source> - Individual - </source>
        <translation>-Kişisel-</translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation> - Tüm Isıtmalar</translation>
    </message>
    <message>
        <source> - Zona - </source>
        <translation>-Bölge-</translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation>- Tüm prizler</translation>
    </message>
    <message>
        <source> - Persiana normal -</source>
        <translation>-Normal Panjur-</translation>
    </message>
    <message>
        <source> - Persiana posicional -</source>
        <translation>-Ayarlı panjur-</translation>
    </message>
    <message>
        <source> - Persianas agupadas -</source>
        <translation>-Grup perdeler-</translation>
    </message>
    <message>
        <source> - Cualquier persiana -</source>
        <translation>- Herhangibir panjur-</translation>
    </message>
    <message>
        <source> - Toldo normal -</source>
        <translation>-Normal Güneşlik-</translation>
    </message>
    <message>
        <source> - Toldo posicional -</source>
        <translation>-Ayarlı güneşlik-</translation>
    </message>
    <message>
        <source> - Toldos agupados -</source>
        <translation>-Grup güneşlikler-</translation>
    </message>
    <message>
        <source> - Cualquier toldo -</source>
        <translation>-Herhangibir güneşlik-</translation>
    </message>
    <message>
        <source> - Cortina normal -</source>
        <translation>-Normal perde-</translation>
    </message>
    <message>
        <source> - Cortina posicional -</source>
        <translation>-Ayarlı perde-</translation>
    </message>
    <message>
        <source> - Cortinas agupadas -</source>
        <translation>-Grup perdeler-</translation>
    </message>
    <message>
        <source> - Cualquier cortina -</source>
        <translation>-Herhangibir perde-</translation>
    </message>
    <message>
        <source> - Puerta motorizada -</source>
        <translation>-Motorlu kapı-</translation>
    </message>
    <message>
        <source> Todos</source>
        <translation>Hepsi</translation>
    </message>
    <message utf8="true">
        <source>Conmutar cámara</source>
        <translation>kamera değiştirme</translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Ad</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Eylem</translation>
    </message>
    <message utf8="true">
        <source>Código</source>
        <translation>Kod</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialog</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation>Senaryoyu çalıştır</translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation>Çevresel mod hırsız alarmı</translation>
    </message>
    <message utf8="true">
        <source>Activar pánico</source>
        <translation>Panik aktive et</translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation>Görüntülü diyafonu aç</translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation>Işık aç</translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation>Işık kapat</translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation>Işık seviyesini yükselt</translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation>Işık seviyesini düşür</translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation>Motor yukarı</translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation>Motor aşağı</translation>
    </message>
    <message>
        <source>Encender Clima</source>
        <translation>Isı kontrol</translation>
    </message>
    <message>
        <source>Apagar Clima</source>
        <translation>Klima kontrol kapat</translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation>Priz aç</translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation>Priz kapat</translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation>ON/OFF Işıklar</translation>
    </message>
    <message>
        <source>Luz regulable</source>
        <translation>Ayarlanabilir ışık</translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation>Tüm çeşitler</translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation>Kişisel ışık</translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation>Bölgedeki ışıklar</translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation>Tüm Işıklar</translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation>Kişisel ısı kontrol</translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation>Tüm Isıtmalar</translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation>kişisel priz</translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation>Bölgedeki prizler</translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation>Tüm prizler</translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation>Normal Panjur</translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation>Ayarlı panjur</translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation>Grup panjurlar</translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation>Herhangibir panjur</translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation>Normal Güneşlik</translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation>Ayarlı güneşlik</translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation>Grup güneşlikler</translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation>Herhangibir güneşlik</translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation>Normal perde</translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation>Ayarlı perde</translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation>Grup perdeler</translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation>Herhangibir perde</translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation>Motorlu kapı</translation>
    </message>
    <message>
        <source>Dispositivo individual</source>
        <translation>Kişisel cihaz</translation>
    </message>
    <message>
        <source>Dispositivos de la zona</source>
        <translation>Cihaz zonu</translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation>Tüm cihazlar</translation>
    </message>
    <message>
        <source>Conmutar camara</source>
        <translation>kamera değiştirme</translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message utf8="true">
        <source>Cambiar acción asociada a la tecla</source>
        <translation>Atanmış fonksiyonu düzenle</translation>
    </message>
    <message utf8="true">
        <source>Acción:</source>
        <translation>Eylem:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation>Eleman türü:</translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation>Kontrol tipi:</translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation>Eleman:</translation>
    </message>
</context>
<context>
    <name>IconChangeDialogClass</name>
    <message>
        <source>IconChangeDialog</source>
        <translation>SimgeDeğişimi</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Simge değiştir</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
</context>
<context>
    <name>IrrigatorControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Hiçbiri</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>AÇ</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>KAPAT</translation>
    </message>
    <message>
        <source>En espera</source>
        <translation>Beklemede</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Durum bilinmiyor</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuel</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
</context>
<context>
    <name>IrrigatorControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Fonksiyon modu:</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>İlgili program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Yeniad</translation>
    </message>
    <message utf8="true">
        <source>Detener riego en caso de lluvia o suelo ya húmedo</source>
        <translation>Yağmur veya ıslak zemin durumunda kapıyı durdur</translation>
    </message>
    <message>
        <source>Sensor de humedad asociado:</source>
        <translation>İlgili nem sensörü:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Simge değiştir</translation>
    </message>
    <message>
        <source>Duracion del riego (minutos):</source>
        <translation>kapı süresi (dakika):</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>AÇ</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>KAPAT</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Bölge</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Cihaz.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Hepsi</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>KeyReadDialog</name>
    <message utf8="true">
        <source>- Código: </source>
        <translation>- kod: </translation>
    </message>
    <message>
        <source>
- Tipo: </source>
        <translation>
Tip:</translation>
    </message>
    <message>
        <source>
- Asignada a: </source>
        <translation>
Atanan:</translation>
    </message>
    <message utf8="true">
        <source>Llave desconocida.
- Código: </source>
        <translation>Bilinmeyen kart.
 -Kod: </translation>
    </message>
</context>
<context>
    <name>KeyReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message utf8="true">
        <source>Acerque la llave
para ser leída</source>
        <translation>Kartı göster</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Leer llave</source>
        <translation>Kartı oku</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
</context>
<context>
    <name>KeyRecordDialog</name>
    <message utf8="true">
        <source>El usuario tiene
asociada la llave
con código: </source>
        <translation>Kullanıcıya 
kayıtlı kart 
kodu:</translation>
    </message>
    <message utf8="true">
        <source>No hay espacio
para grabar más llaves</source>
        <translation>Yeni mesaj 
kaydı için yer yok</translation>
    </message>
    <message>
        <source>Acerque la llave
para ser grabada</source>
        <translation>Kartı göster</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder
a borrar la llave.
¿Está seguro?</source>
        <translation>Kart silinecek. 
Emin misiniz?</translation>
    </message>
    <message>
        <source>La llave ya ha
sido grabada antes.</source>
        <translation>Bu kart daha önce kaydedilmiş.</translation>
    </message>
    <message utf8="true">
        <source>Llave leída.
- Código: </source>
        <translation>Kart oku
- Kod:</translation>
    </message>
</context>
<context>
    <name>KeyRecordDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>El usuario no tiene
llave asociada</source>
        <translation>Kullanıcıya kayıtlı 
kart yok</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Grabar llave</source>
        <translation>kartı 
kaydet</translation>
    </message>
    <message>
        <source>Tipo de llave:</source>
        <translation>Kart tipi:</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation>&gt;&gt;</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation>&lt;&lt;</translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation>Kaydet</translation>
    </message>
    <message>
        <source>Grabar
llave</source>
        <translation>kartı 
kaydet</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Borrar
llave</source>
        <translation>Kartı 
sil</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Kabul</translation>
    </message>
</context>
<context>
    <name>KeyboardClass</name>
    <message>
        <source>Keyboad</source>
        <translation>Klavye</translation>
    </message>
    <message>
        <source>&gt;&gt;&gt;</source>
        <translation>&gt;&gt;&gt;</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Sil</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Bloq May</source>
        <translation>BüyükHarf</translation>
    </message>
    <message>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <source>X</source>
        <translation>Ç</translation>
    </message>
    <message>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>W</source>
        <translation>W</translation>
    </message>
    <message>
        <source>I</source>
        <translation>I</translation>
    </message>
    <message>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>T</source>
        <translation>T</translation>
    </message>
    <message>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message utf8="true">
        <source>Ñ</source>
        <translation>Ñ</translation>
    </message>
    <message>
        <source>J</source>
        <translation>J</translation>
    </message>
    <message>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>H</source>
        <translation>H</translation>
    </message>
    <message>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <source>Q</source>
        <translation>Q</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>Z</source>
        <translation>Z</translation>
    </message>
    <message>
        <source>K</source>
        <translation>K</translation>
    </message>
    <message>
        <source>O</source>
        <translation>O</translation>
    </message>
    <message>
        <source>G</source>
        <translation>G</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message utf8="true">
        <source>ó</source>
        <translation>ó</translation>
    </message>
    <message utf8="true">
        <source>é</source>
        <translation>é</translation>
    </message>
    <message utf8="true">
        <source>ş</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ö</source>
        <translation>ö</translation>
    </message>
    <message>
        <source>&apos;</source>
        <translation>&apos;</translation>
    </message>
    <message utf8="true">
        <source>Ó</source>
        <translation>Ó</translation>
    </message>
    <message>
        <source>_</source>
        <translation>_</translation>
    </message>
    <message>
        <source>.</source>
        <translation>.</translation>
    </message>
    <message>
        <source>,</source>
        <translation>,</translation>
    </message>
    <message utf8="true">
        <source>É</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ü</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>á</source>
        <translation></translation>
    </message>
    <message>
        <source>@</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ú</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Í</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Ç</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Ú</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ǧ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Á</source>
        <translation></translation>
    </message>
    <message>
        <source>*</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ç</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>í</source>
        <translation></translation>
    </message>
    <message>
        <source>#</source>
        <translation></translation>
    </message>
    <message>
        <source>-</source>
        <translation></translation>
    </message>
    <message>
        <source>y</source>
        <translation></translation>
    </message>
    <message>
        <source>s</source>
        <translation></translation>
    </message>
    <message>
        <source>f</source>
        <translation></translation>
    </message>
    <message>
        <source>j</source>
        <translation></translation>
    </message>
    <message>
        <source>v</source>
        <translation></translation>
    </message>
    <message>
        <source>t</source>
        <translation></translation>
    </message>
    <message>
        <source>b</source>
        <translation></translation>
    </message>
    <message>
        <source>z</source>
        <translation></translation>
    </message>
    <message>
        <source>c</source>
        <translation></translation>
    </message>
    <message>
        <source>k</source>
        <translation></translation>
    </message>
    <message>
        <source>i</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ñ</source>
        <translation></translation>
    </message>
    <message>
        <source>r</source>
        <translation></translation>
    </message>
    <message>
        <source>g</source>
        <translation></translation>
    </message>
    <message>
        <source>w</source>
        <translation></translation>
    </message>
    <message>
        <source>a</source>
        <translation></translation>
    </message>
    <message>
        <source>x</source>
        <translation></translation>
    </message>
    <message>
        <source>p</source>
        <translation></translation>
    </message>
    <message>
        <source>l</source>
        <translation></translation>
    </message>
    <message>
        <source>m</source>
        <translation></translation>
    </message>
    <message>
        <source>n</source>
        <translation></translation>
    </message>
    <message>
        <source>h</source>
        <translation></translation>
    </message>
    <message>
        <source>u</source>
        <translation></translation>
    </message>
    <message>
        <source>d</source>
        <translation></translation>
    </message>
    <message>
        <source>q</source>
        <translation></translation>
    </message>
    <message>
        <source>o</source>
        <translation></translation>
    </message>
    <message>
        <source>e</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ف</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ى</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ح</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ه</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ا</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ع</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>خ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ي</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>م</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ة</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ض</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ب</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ص</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ت</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ث</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>و</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ش</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ق</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>لا</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ؤ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>س</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ن</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>غ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ك</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ل</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ر</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ئ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ء</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ظ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ز</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>د</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ج</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ط</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٨</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٤</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٣</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٧</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ذ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>١</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٢</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٩</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٦</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٥</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
</context>
<context>
    <name>LicenseSystem</name>
    <message>
        <source>Introduzca licencia...</source>
        <translation>Lisans girin ...</translation>
    </message>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Licencia</source>
        <translation>Lisans</translation>
    </message>
    <message utf8="true">
        <source>La licencia caducará en %1 días. 
Para poder seguir usando el sistema Vivimat III deberá llamar a su instalador para que le proporcione una licencia 
 válida. Deberá indicarle el número de licencia que aparece a continuación para poder activar el sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Número de licencia:</source>
        <translation>Lisans Numarası:</translation>
    </message>
    <message>
        <source>Licencia....</source>
        <translation>Lisans...</translation>
    </message>
</context>
<context>
    <name>LightControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Hiçbiri</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Durum bilinmiyor</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuel</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
    <message>
        <source>Presencia</source>
        <translation>Hareket</translation>
    </message>
    <message>
        <source>Crepuscular</source>
        <translation>Alacakaranlık</translation>
    </message>
    <message>
        <source>Crep + Pres</source>
        <translation>Bas+Alc</translation>
    </message>
    <message>
        <source>Pres + Prog</source>
        <translation>Bas+Prog</translation>
    </message>
</context>
<context>
    <name>LightControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>İlgili program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Yeniad</translation>
    </message>
    <message>
        <source>Consigna en modo presencia:</source>
        <translation>Hareket modundaki değer:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Fonksiyon modu:</translation>
    </message>
    <message>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <source>Sensor de presencia asociado:</source>
        <translation>İlgili Hareket sensörü:</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la desactivación:</source>
        <translation>Deaktivasyon gecikmesi:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Simge değiştir</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Cihaz.</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Bölge</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Hepsi</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>ON</source>
        <translation></translation>
    </message>
    <message>
        <source>OFF</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>inicio</source>
        <translation>Başla</translation>
    </message>
    <message>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation>Görüntülü diyafon</translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation>Güvenlik</translation>
    </message>
    <message>
        <source>escenas</source>
        <translation>Senaryolar</translation>
    </message>
    <message>
        <source>mensajes</source>
        <translation>Mesajlar</translation>
    </message>
    <message>
        <source>configurar</source>
        <translation>Ayar</translation>
    </message>
    <message>
        <source>clima</source>
        <translation>Klima</translation>
    </message>
    <message utf8="true">
        <source>cámaras</source>
        <translation>Kameralar</translation>
    </message>
    <message>
        <source>programas</source>
        <translation>Programlar</translation>
    </message>
    <message>
        <source>alarmas</source>
        <translation>Alarmlar</translation>
    </message>
    <message>
        <source>historial</source>
        <translation>Alarm kayıtları</translation>
    </message>
    <message>
        <source>fotos</source>
        <translation>Fotograflar</translation>
    </message>
    <message>
        <source>pizarra</source>
        <translation>Yazı tahtası</translation>
    </message>
    <message>
        <source>sos</source>
        <translation>SOS</translation>
    </message>
    <message utf8="true">
        <source>No es posible visualizar las cámaras porque ya están siendo visualizadas en otro terminal.</source>
        <translation>Kamerayı görüntülemek şu anda mümkün değil, çünkü başka bir ekranda şu anda zaten görüntüleniyor.</translation>
    </message>
    <message utf8="true">
        <source>Cámaras ocupadas</source>
        <translation>Kameralar meşgul</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar</source>
        <translation>alarmı iptal etmek için şifre girin</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para menú de seguridad</source>
        <translation>Güvenlik menüsü için şifre girin</translation>
    </message>
    <message>
        <source>Antes de poder usar los mensajes de voz es necesario tener grabados los mensajes personales.</source>
        <translation>Ses mesajlarını kullanmak için kişisel mesajlara kaydetmetmeniz gerekir.</translation>
    </message>
    <message>
        <source>Mensajes personales sin grabar</source>
        <translation>Kayıtsız kişisel mesajlar</translation>
    </message>
    <message>
        <source>LUN </source>
        <translation>PZT </translation>
    </message>
    <message>
        <source>MAR </source>
        <translation>SAL </translation>
    </message>
    <message>
        <source>MIE </source>
        <translation>ÇAR </translation>
    </message>
    <message>
        <source>JUE </source>
        <translation>PER </translation>
    </message>
    <message>
        <source>VIE </source>
        <translation>CUM </translation>
    </message>
    <message>
        <source>SAB </source>
        <translation>CTS </translation>
    </message>
    <message>
        <source>DOM </source>
        <translation>PAZ </translation>
    </message>
    <message>
        <source>dd/MM/yyyy</source>
        <translation>yyyy/MM/dd</translation>
    </message>
    <message utf8="true">
        <source>INT %1 ºC</source>
        <translation>IÇ %1 ºC</translation>
    </message>
    <message utf8="true">
        <source>Los ficheros de configuración no coinciden.
Para sobreescribir los ficheros de la central en la pantalla pulsa Aceptar. En caso contrario, pulsa Cancelar.</source>
        <translation>Konfigürasyon dosyaları farklıdır.
 dosyaların üzerine yazmak için
 Kabul eti seçin. aksi halde, İptal düğmesini seçin.</translation>
    </message>
    <message utf8="true">
        <source>Actualizar configuración</source>
        <translation>Konfigürasyon güncelleme</translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código IR:
%1 %2 %3</source>
        <translation>IR kod okundu:
%1 %2 %3</translation>
    </message>
    <message utf8="true">
        <source>Código IR leído</source>
        <translation>IR Kod oku</translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código RFID:
%1 %2 %3 %4</source>
        <translation>RFID kodu okundu:
%1 %2 %3 %4</translation>
    </message>
    <message utf8="true">
        <source>Llave leída</source>
        <translation>RFID kart oku</translation>
    </message>
    <message utf8="true">
        <source>El idioma del sistema ha sido modificado.
¿Desea reiniciar la pantalla?</source>
        <translation>Sistem dili değiştirildi.Ekran yeniden başlatılsın mı?</translation>
    </message>
    <message>
        <source>Actualizar idioma...</source>
        <translation>Dil güncelleme...</translation>
    </message>
    <message utf8="true">
        <source>Cerrar sesión</source>
        <translation>Çıkış yap</translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 30 segundos.</source>
        <translation type="obsolete">Sistem asmak anahtar tanıtmak için üç deneme başarısız oldu sonra.
  Için tekrar girin şifreyi 30 saniye bekleyin.</translation>
    </message>
    <message>
        <source>Sistema bloqueado</source>
        <translation>Sistem asmak</translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 90 segundos.</source>
        <translation>Sistem asmak anahtar tanıtmak için üç deneme başarısız oldu sonra.
  Için tekrar girin şifreyi 90 saniye bekleyin.</translation>
    </message>
</context>
<context>
    <name>MainWindowClass</name>
    <message>
        <source>MainWindow</source>
        <translation>AnaEkran</translation>
    </message>
    <message>
        <source>12:30</source>
        <translation>12:30</translation>
    </message>
    <message>
        <source>MAR 15/11/2009</source>
        <translation>SAL 15/11/2009</translation>
    </message>
    <message utf8="true">
        <source>INT 18ºC</source>
        <translation>İÇ 18 ºC</translation>
    </message>
    <message>
        <source>T</source>
        <translation type="obsolete">T</translation>
    </message>
    <message>
        <source>LL</source>
        <translation>LL</translation>
    </message>
</context>
<context>
    <name>MessageDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation>Doğrulama penceresi</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Kabul</translation>
    </message>
</context>
<context>
    <name>MessagesWindow</name>
    <message>
        <source>Tipo</source>
        <translation>Tür</translation>
    </message>
    <message>
        <source>Origen</source>
        <translation>Menşei</translation>
    </message>
    <message>
        <source>Fecha/Hora</source>
        <translation>Tarih ve saat</translation>
    </message>
    <message>
        <source>Videoportero</source>
        <translation>Görüntülü diyafon</translation>
    </message>
    <message>
        <source>Terminal 1</source>
        <translation>Ekran1</translation>
    </message>
    <message>
        <source>Terminal 2</source>
        <translation>Ekran2</translation>
    </message>
    <message>
        <source>Terminal 3</source>
        <translation>Ekran 3</translation>
    </message>
    <message>
        <source>Desconocido</source>
        <translation>Bilinmiyor</translation>
    </message>
    <message>
        <source>Voz</source>
        <translation>Ses</translation>
    </message>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>Ses mesajı şu an kullanımda olduğu için mesaj  kaydedilemez.</translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation>Ses mesajı kullanımda</translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation>Mesaj kayıt...</translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>Ses mesajı şu an kullanımda olduğu için mesaj  dinlenemez.</translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation>Mesaj tekrar...</translation>
    </message>
    <message utf8="true">
        <source>No es posible borrar los mensajes, los mensajes de voz ya están siendo usados.</source>
        <translation>Ses mesajı şu an kullanımda olduğu için mesaj silinemez.</translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation>Tüm mesajlar silinecek. 
Emin misiniz?</translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation>Mesajı Sil...</translation>
    </message>
</context>
<context>
    <name>MessagesWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Grabar
mensaje</source>
        <translation>Mesaj 
kayıt</translation>
    </message>
    <message>
        <source>Borrar
mensajes</source>
        <translation>Mesajı 
sil</translation>
    </message>
</context>
<context>
    <name>MsgProgressDialogClass</name>
    <message>
        <source>RecWindow</source>
        <translation>KayıtEkranı</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Parar</source>
        <translation>Dur</translation>
    </message>
</context>
<context>
    <name>PasswordClass</name>
    <message>
        <source>Password</source>
        <translation>Şifre </translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para continuar...</source>
        <translation>Şifreyi girin...</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Sil</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>TAMAM</translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialog</name>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>Ses mesajı şu an kullanımda olduğu için mesaj  kaydedilemez.</translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation>Voice messages in use</translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation>All messages will be deleted. 
Are you sure?</translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation>Mesajı Sil...</translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation>Mesaj kayıt...</translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>It is not possible to play the message, the voice messages are already in use.</translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation>Ses mesajı kullanımda...</translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation>ConfirmationWindow</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Mensajes de voz personalizados</source>
        <translation>Kişisel ses mesajları</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Kabul</translation>
    </message>
    <message>
        <source>Mensaje para llamadas de alarma</source>
        <translation>Alarm aramaları için mesaj</translation>
    </message>
    <message>
        <source>Reproducir</source>
        <translation>Tekrar</translation>
    </message>
    <message>
        <source>Grabar</source>
        <translation>Kayıt</translation>
    </message>
    <message>
        <source>Mensaje para contestador de videoportero</source>
        <translation>Görüntülü diyafon cevap mesajı</translation>
    </message>
    <message utf8="true">
        <source>Para grabar los mensajes de voz personalizados primero se borraran todos los mensajes, después se grabará el mensaje para llamadas de alarma y a continuación el mensaje para contestador de videoportero.</source>
        <translation>kişisel ses mesajı bırakmak için tüm mesajları silin,  sonra alarm arama ve görüntülü diyafon mesajlarını kaydedin.</translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindow</name>
    <message>
        <source>Tipo</source>
        <translation>Tür</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Ad</translation>
    </message>
    <message utf8="true">
        <source>Número</source>
        <translation>Numara</translation>
    </message>
    <message>
        <source>TEL</source>
        <translation>TEL</translation>
    </message>
    <message>
        <source>SMS</source>
        <translation>SMS</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>CRA</source>
        <translation>AIM</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
    <message>
        <source>Es necesario introducir primero el tipo de contacto.</source>
        <translation>Önce kişi türünü girin.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Hata...</translation>
    </message>
    <message utf8="true">
        <source>Introduzca nuevo número o dirección de correo ...</source>
        <translation>Yeni numarayı veya e-mail adresini girin ...</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el contacto.
¿Está seguro?</source>
        <translation>Kişi silinecek. 
Emin misiniz?</translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation>Kişi sil...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Lütfen eksik veriyi girin.</translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindowClass</name>
    <message>
        <source>PhoneConfigWindow</source>
        <translation>TelAyarEkranı</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Habilitar avisos</source>
        <translation>Alarm uyarısını aç</translation>
    </message>
    <message>
        <source>Habilitar telecontrol</source>
        <translation>Telefon ile kontrolü aç</translation>
    </message>
    <message>
        <source>Tonos</source>
        <translation>Tonlar</translation>
    </message>
    <message>
        <source>Configurar
CRA</source>
        <translation>AIM 
Ayarları</translation>
    </message>
</context>
<context>
    <name>PhotosWindow</name>
    <message>
        <source>Marco de fotos</source>
        <translation>Resim çerçevesi</translation>
    </message>
    <message>
        <source>No hay fotos disponibles.</source>
        <translation>Fotoğraf Yok.</translation>
    </message>
    <message>
        <source>Reducir la resolucion de la imagen para su correcta visualizacion.</source>
        <translation type="obsolete">Görüntüleri izlemek için görüntünün çözünürlüğünü azaltın.</translation>
    </message>
    <message>
        <source>No se puede mostrar la foto (%1).</source>
        <translation>Fotoğrafı görüntülemek için açılamıyor (%1).</translation>
    </message>
</context>
<context>
    <name>PlugControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Hiçbiri</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>AÇ</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>KAPAT</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Durum bilinmiyor</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuel</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
</context>
<context>
    <name>PlugControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Fonksiyon modu:</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>İlgili program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Yeniad</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Simge değiştir</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>AÇ</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>KAPAT</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Bölge</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Cihaz.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Hepsi</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>salida temporizada </source>
        <translation>oto kapama</translation>
    </message>
    <message>
        <source>segundos</source>
        <translation>saniye</translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindow</name>
    <message>
        <source>Temperatura</source>
        <translation>Sıcaklık</translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation>0-100%</translation>
    </message>
    <message>
        <source>ON-OFF</source>
        <translation>AÇ-KAPAT</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
    <message utf8="true">
        <source>Las franjas horarias no están bien definidas.</source>
        <translation>Zaman aralığı uygun belirlenmedi.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Hata...</translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>0 = OFF</source>
        <translation>0 = KAPAT</translation>
    </message>
    <message>
        <source>1 = ON</source>
        <translation>1 = AÇ</translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Tür</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Yeniad</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message utf8="true">
        <source>Días de ejecución:</source>
        <translation>Aktif günler:</translation>
    </message>
    <message>
        <source>L</source>
        <translation>P</translation>
    </message>
    <message>
        <source>M</source>
        <translation>S</translation>
    </message>
    <message>
        <source>X</source>
        <translation>Ç</translation>
    </message>
    <message>
        <source>J</source>
        <translation>P</translation>
    </message>
    <message>
        <source>V</source>
        <translation>C</translation>
    </message>
    <message>
        <source>S</source>
        <translation>C</translation>
    </message>
    <message>
        <source>D</source>
        <translation>P</translation>
    </message>
    <message>
        <source>Fin</source>
        <translation>Son</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>SS:dd</translation>
    </message>
    <message>
        <source>Inicio</source>
        <translation>Başla</translation>
    </message>
    <message>
        <source>Consigna</source>
        <translation>Değer</translation>
    </message>
    <message>
        <source>Franja 1:</source>
        <translation>Giriş 1:</translation>
    </message>
    <message>
        <source>Franja 2:</source>
        <translation>Giriş 2:</translation>
    </message>
    <message>
        <source>Franja 3:</source>
        <translation>Giriş 3:</translation>
    </message>
    <message>
        <source>Franja 4:</source>
        <translation>Giriş 4:</translation>
    </message>
    <message>
        <source>Franja 5:</source>
        <translation>Giriş 5:</translation>
    </message>
</context>
<context>
    <name>ProgramsWindow</name>
    <message>
        <source>Nombre</source>
        <translation>Ad</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Tür</translation>
    </message>
    <message>
        <source>L</source>
        <translation>P</translation>
    </message>
    <message>
        <source>M</source>
        <translation>S</translation>
    </message>
    <message>
        <source>X</source>
        <translation>Ç</translation>
    </message>
    <message>
        <source>J</source>
        <translation>P</translation>
    </message>
    <message>
        <source>V</source>
        <translation>C</translation>
    </message>
    <message>
        <source>S</source>
        <translation>C</translation>
    </message>
    <message>
        <source>D</source>
        <translation>P</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Temperatura</source>
        <translation>Sıcaklık</translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation>0-100%</translation>
    </message>
    <message>
        <source>ON/OFF</source>
        <translation>AÇ-KAPAT</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el programa.
¿Está seguro?</source>
        <translation>Program silinecek. 
Devam etmek istiyor musunuz??</translation>
    </message>
    <message>
        <source>Eliminar programa...</source>
        <translation>Program sil...</translation>
    </message>
</context>
<context>
    <name>ProgramsWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Ad</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Tür</translation>
    </message>
    <message>
        <source>L</source>
        <translation>P</translation>
    </message>
    <message>
        <source>M</source>
        <translation>S</translation>
    </message>
    <message>
        <source>X</source>
        <translation>Ç</translation>
    </message>
    <message>
        <source>J</source>
        <translation>P</translation>
    </message>
    <message>
        <source>V</source>
        <translation>C</translation>
    </message>
    <message>
        <source>S</source>
        <translation>C</translation>
    </message>
    <message>
        <source>D</source>
        <translation>P</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
</context>
<context>
    <name>RBlindControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Hiçbiri</translation>
    </message>
    <message>
        <source>Grupo de toldos</source>
        <translation>Grup güneşlikler</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Durum bilinmiyor</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuel</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
</context>
<context>
    <name>RBlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>İlgili program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Yeniad</translation>
    </message>
    <message>
        <source>Plegar toldos en caso de viento fuerte</source>
        <translation>Güçlü rüzgarda güneşlikleri kaldır</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Açılma/Kapanma zamanı:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Fonksiyon modu:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Simge değiştir</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Bölge</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Cihaz.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Hepsi</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Plegar toldos en caso de lluvia</source>
        <translation>Yağmur durumunda güneşlikleri kaldır</translation>
    </message>
</context>
<context>
    <name>SOSWindow</name>
    <message utf8="true">
        <source>Alarma de pánico deshabilitada</source>
        <translation>Panik alarm kapalı</translation>
    </message>
</context>
<context>
    <name>SOSWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>SOS</source>
        <translation>SOS</translation>
    </message>
    <message>
        <source>STOP</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SceneConditionDialog</name>
    <message>
        <source>Sin condicionar</source>
        <translation>Koşul yok</translation>
    </message>
    <message>
        <source>Cualquier llave</source>
        <translation>herhangi bir kart</translation>
    </message>
    <message>
        <source>Llave tipo A</source>
        <translation>kart türü A</translation>
    </message>
    <message>
        <source>Llave tipo B</source>
        <translation>kart türü B</translation>
    </message>
    <message>
        <source>Llave tipo C</source>
        <translation>kart türü C</translation>
    </message>
    <message>
        <source>Llave tipo D</source>
        <translation>kart türü D</translation>
    </message>
    <message>
        <source>Llave tipo E</source>
        <translation>kart türü E</translation>
    </message>
    <message>
        <source>Llave tipo F</source>
        <translation>kart türü F</translation>
    </message>
    <message>
        <source>Llave: </source>
        <translation>KART:</translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation>Tarih</translation>
    </message>
    <message utf8="true">
        <source>Día semana</source>
        <translation>Hafta içi</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión armada</source>
        <translation>Hırsız Alarmı Kurulu</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión desarmada</source>
        <translation>Hırsız alarmı kurulu değil</translation>
    </message>
    <message utf8="true">
        <source>Activación de cualquier alarma</source>
        <translation>Herhangi alarmı aktive et</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de intrusión</source>
        <translation>HIrsız alarmı aç</translation>
    </message>
    <message>
        <source>Act. alm. de fuego</source>
        <translation>Yangın alarmı aç</translation>
    </message>
    <message>
        <source>Act. alm. de gas</source>
        <translation>Gaz alarmı aç</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de inundación</source>
        <translation>Su taşkın alarmı aç</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de corte eléc.</source>
        <translation>Güç kesintisi alarmı aç.</translation>
    </message>
    <message>
        <source>Act. alm. de corte tlf.</source>
        <translation>Telefon kesintisi alamı aç.</translation>
    </message>
    <message>
        <source>Act. alm. de sistema</source>
        <translation>Sistem alarmı aç</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. médica</source>
        <translation>Tıbbi alarm aç</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de pánico</source>
        <translation>Panik alarm aç</translation>
    </message>
    <message>
        <source>Act. alm. silenciosa</source>
        <translation>hareketsizlik alarmı aç</translation>
    </message>
    <message>
        <source>Act. alm. de sabotaje</source>
        <translation>Sabtaj alarmı aç</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de coacción</source>
        <translation>Tehdir alarmı aç</translation>
    </message>
    <message>
        <source>Entrada en Central</source>
        <translation>Ana üniteye gir</translation>
    </message>
    <message>
        <source>Entrada en MOD0035</source>
        <translation>MOD-0035 e gir</translation>
    </message>
    <message>
        <source>Intrusion en armado total</source>
        <translation>HIRSIZ GENEL ALARM KURULU</translation>
    </message>
    <message>
        <source>Intrusion en armado perimetral</source>
        <translation>HIRSIZ ÇEVRESEL ALARM KURULU</translation>
    </message>
    <message>
        <source>Intrusion en armado parcial</source>
        <translation type="unfinished">HIRSIZ PARÇALI ALARM KURULU</translation>
    </message>
</context>
<context>
    <name>SceneConditionDialogClass</name>
    <message>
        <source>EventConditionWindow</source>
        <translation>OlayDurumEkranı</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Condiciones</source>
        <translation>Koşullar</translation>
    </message>
    <message>
        <source>Condicion de llave:</source>
        <translation>Kart koşulu:</translation>
    </message>
    <message>
        <source>Condicion de hora:</source>
        <translation>Zaman koşulu:</translation>
    </message>
    <message>
        <source>Condicion de Fecha / Dia semana:</source>
        <translation>Tarih/haftaiçi koşulu:</translation>
    </message>
    <message>
        <source>Condicion de alarma:</source>
        <translation>Alarm koşulu:</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>SS:dd</translation>
    </message>
    <message>
        <source>L</source>
        <translation>P</translation>
    </message>
    <message>
        <source>V</source>
        <translation>C</translation>
    </message>
    <message>
        <source>X</source>
        <translation>Ç</translation>
    </message>
    <message>
        <source>D</source>
        <translation>P</translation>
    </message>
    <message>
        <source>M</source>
        <translation>S</translation>
    </message>
    <message>
        <source>J</source>
        <translation>P</translation>
    </message>
    <message>
        <source>S</source>
        <translation>C</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Condicion de entrada:</source>
        <translation>Input koşulu:</translation>
    </message>
    <message>
        <source>Tipo de modulo:</source>
        <translation>Modül türü:</translation>
    </message>
    <message>
        <source>E/S:</source>
        <translation>C/Ç:</translation>
    </message>
    <message>
        <source>Mod:</source>
        <translation>MOD:</translation>
    </message>
</context>
<context>
    <name>SceneEventWindow</name>
    <message utf8="true">
        <source>Iluminación</source>
        <translation>Işıklar</translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation>Motorlu cihaz</translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation>Priz</translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation>Isı kontrol</translation>
    </message>
    <message>
        <source>Riego</source>
        <translation>kapı</translation>
    </message>
    <message>
        <source>Retardo</source>
        <translation>Gecikme</translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation>Güvenlik</translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation>Kişisel ışık</translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation>Bölgedeki ışıklar</translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation>Tüm Işıklar</translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation>ON/OFF Işıklar</translation>
    </message>
    <message>
        <source>Luz Regulable</source>
        <translation>Ayarlanabilir ışık</translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation>Tüm türler</translation>
    </message>
    <message>
        <source>0%</source>
        <translation>0%</translation>
    </message>
    <message>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <source>20%</source>
        <translation>20%</translation>
    </message>
    <message>
        <source>40%</source>
        <translation>40%</translation>
    </message>
    <message>
        <source>60%</source>
        <translation>60%</translation>
    </message>
    <message>
        <source>80%</source>
        <translation>80%</translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation>kişisel priz</translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation>Bölgedeki prizler</translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation>Tüm prizler</translation>
    </message>
    <message>
        <source>Encender</source>
        <translation>Aç</translation>
    </message>
    <message>
        <source>Apagar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation>Kişisel ısı kontrol</translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation>Tüm Isıtmalar</translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation>Kapalı</translation>
    </message>
    <message>
        <source>Modo manual</source>
        <translation>Manuel mod</translation>
    </message>
    <message>
        <source>Modo programa</source>
        <translation>Program modu</translation>
    </message>
    <message utf8="true">
        <source>Modo económico</source>
        <translation>Eko mod</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>Riego individual</source>
        <translation>Kişisel kapı</translation>
    </message>
    <message>
        <source>Riegos de la zona</source>
        <translation>Bölgedeki kapılar</translation>
    </message>
    <message>
        <source>Todos los riegos</source>
        <translation>Tüm kapı</translation>
    </message>
    <message>
        <source>Activar</source>
        <translation>Aktive et</translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>1 seg</source>
        <translation>1 sn</translation>
    </message>
    <message>
        <source>3 seg</source>
        <translation>3 sn</translation>
    </message>
    <message>
        <source>5 seg</source>
        <translation>5 sn</translation>
    </message>
    <message>
        <source>10 seg</source>
        <translation>10 sn</translation>
    </message>
    <message>
        <source>20 seg</source>
        <translation>20 sn</translation>
    </message>
    <message>
        <source>30 seg</source>
        <translation>30 sn</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation>Hırsız Alarm</translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation>Yangın Alarm</translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation>Gaz Alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation>Su Taşkın Alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation>Güç Arızası</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte telefónico</source>
        <translation>Telefon Arızası</translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation>Sistem Alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation>Tıbbi Alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation>Panik Alarm</translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation>Hareketsizlik Alarm</translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation>Sabotaj Alarm</translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation>Çevresel alarmı kur</translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation>Parçalı alarmı kur</translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation>Genel Alarmı kur</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Alarmı iptal et</translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation>Parçalı alarmı iptal et</translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation>Alarmı aktive et</translation>
    </message>
    <message>
        <source>Dis. individual</source>
        <translation>Kişisel cihaz</translation>
    </message>
    <message>
        <source>Dis. de la zona</source>
        <translation>Bölge cihazları</translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation>Tüm cihazlar</translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation>Normal Panjur</translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation>Ayarlı panjur</translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation>Grup panjurlar</translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation>Herhangibir panjur</translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation>Normal Güneşlik</translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation>Ayarlı güneşlik</translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation>Grup güneşlikler</translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation>Herhangibir güneşlik</translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation>Normal perde</translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation>Ayarlı perde</translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation>Grup perdeler</translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation>Herhangibir perde</translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation>Motorlu kapı</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Aç</translation>
    </message>
    <message>
        <source>Enchufe normal</source>
        <translation type="unfinished">Normal Priz</translation>
    </message>
    <message>
        <source>Enchufes temporizados</source>
        <translation type="unfinished">Zamanlı Priz</translation>
    </message>
</context>
<context>
    <name>SceneEventWindowClass</name>
    <message>
        <source>SceneEventWindow</source>
        <translation>OlayDurumEkranı</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Modificar evento</source>
        <translation>Olayı düzenle</translation>
    </message>
    <message>
        <source>Tipo de evento:</source>
        <translation>Olay türü:</translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation>Kontrol türü:</translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation>Element türü:</translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation>Element:</translation>
    </message>
    <message>
        <source>Valor:</source>
        <translation>Değer:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindow</name>
    <message>
        <source>Evento</source>
        <translation>Olay</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el evento.
¿Está seguro?</source>
        <translation>Eleman silinecek. 
Emin misiniz?</translation>
    </message>
    <message>
        <source>Eliminar evento...</source>
        <translation>Olay sil...</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
    <message utf8="true">
        <source>Iluminación</source>
        <translation>Işıklar</translation>
    </message>
    <message>
        <source> - ON/OFF</source>
        <translation> - AÇ/KAPAT -</translation>
    </message>
    <message>
        <source> - Regulable</source>
        <translation>-Ayarlanabilir</translation>
    </message>
    <message>
        <source> - RGB</source>
        <translation>-RGB</translation>
    </message>
    <message>
        <source> - Todos los tipos</source>
        <translation>Tüm türler</translation>
    </message>
    <message>
        <source> - Individual: </source>
        <translation>Kişisel:</translation>
    </message>
    <message>
        <source> - Zona: </source>
        <translation>-Bölge:</translation>
    </message>
    <message>
        <source> - Todas las luces</source>
        <translation>Tüm Işıklar</translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation>Motorlu cihaz</translation>
    </message>
    <message>
        <source> - Persiana normal</source>
        <translation>-Normal Panjur-</translation>
    </message>
    <message>
        <source> - Persiana posicional</source>
        <translation>- Ayarlı panjur</translation>
    </message>
    <message>
        <source> - Persianas agupadas</source>
        <translation>- Grup panjurlar</translation>
    </message>
    <message>
        <source> - Cualquier persiana</source>
        <translation>- Herhangibir panjur</translation>
    </message>
    <message>
        <source> - Toldo normal</source>
        <translation>- Normal Güneşlik</translation>
    </message>
    <message>
        <source> - Toldo posicional</source>
        <translation>- Awning positional</translation>
    </message>
    <message>
        <source> - Toldos agupados</source>
        <translation>- Grup güneşlikler</translation>
    </message>
    <message>
        <source> - Cualquier toldo</source>
        <translation>- Herhangibir güneşlik</translation>
    </message>
    <message>
        <source> - Cortina normal</source>
        <translation>- Normal perde</translation>
    </message>
    <message>
        <source> - Cortina posicional</source>
        <translation>-  Ayarlı perde</translation>
    </message>
    <message>
        <source> - Cortinas agupadas</source>
        <translation>- Grup perdeler</translation>
    </message>
    <message>
        <source> - Cualquier cortina</source>
        <translation>- Herhangibir panjur</translation>
    </message>
    <message>
        <source> - Puerta motorizada</source>
        <translation>- Motor yukarı</translation>
    </message>
    <message>
        <source> - Todos los dispositivos</source>
        <translation>- Tüm cihazlar</translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation>Priz</translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation>Tüm prizler</translation>
    </message>
    <message>
        <source> - Encender</source>
        <translation>Aç</translation>
    </message>
    <message>
        <source> - Apagar</source>
        <translation>Kapat</translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation>Isı kontrol </translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation> - Tüm Isıtmalar</translation>
    </message>
    <message>
        <source> - Apagado</source>
        <translation>Kapalı</translation>
    </message>
    <message>
        <source> - Modo manual - </source>
        <translation>-Manuel mod -</translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source> - Modo programa</source>
        <translation>Program modu</translation>
    </message>
    <message utf8="true">
        <source> - Modo económico - </source>
        <translation>Eko mod</translation>
    </message>
    <message>
        <source>Riego</source>
        <translation>kapı</translation>
    </message>
    <message>
        <source> - Todos los riegos</source>
        <translation>- Tüm kapı</translation>
    </message>
    <message>
        <source> - Activar</source>
        <translation>- Aç</translation>
    </message>
    <message>
        <source> - Desactivar</source>
        <translation>- Kapat</translation>
    </message>
    <message>
        <source>Retardo - </source>
        <translation>Gecikme -</translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation>Güvenlik</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation>Hırsız Alarm</translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation>Yangın Alarm</translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation>Gaz Alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation>Su Taşkın Alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation>Güç arızası alarmı</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte de teléfono</source>
        <translation>Telefon arıza alarmı</translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation>Sistem Alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation>Tıbbi Alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation>Panik Alarm</translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation>Hareketsizlik Alarm</translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation>Sabotaj Alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de coacción</source>
        <translation>Tehdit Alarm</translation>
    </message>
    <message>
        <source>Deshabilitar alarma</source>
        <translation>Alarmı kapat</translation>
    </message>
    <message>
        <source>Habilitar alarma</source>
        <translation>Alarm aç</translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation>Alarmı aktive et</translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation>Çevresel alarm modu</translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation>Parçalı alarm modu</translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation>Genel Alarm modu</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Alarmı Kapat</translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation>Parçalı alarmı kapat</translation>
    </message>
    <message>
        <source> - Todos </source>
        <translation type="unfinished">-Tüm</translation>
    </message>
    <message>
        <source> - Temporizados </source>
        <translation type="obsolete">-zamanlanmış</translation>
    </message>
    <message>
        <source> - No temporizados</source>
        <translation type="unfinished">- Zamanlı Değil</translation>
    </message>
    <message>
        <source> - Temporizados</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindowClass</name>
    <message>
        <source>ScenesConfigWindow</source>
        <translation>SenaryoAyarEkranı</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Yeniad</translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindow</name>
    <message>
        <source>Nombre</source>
        <translation>Ad</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la escena.
¿Está seguro?</source>
        <translation>Senaryo silinecek.
devem etmek inuz? stiyor musu</translation>
    </message>
    <message>
        <source>Eliminar escena...</source>
        <translation>Senaryo sil...</translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
</context>
<context>
    <name>ScenesWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindow</name>
    <message>
        <source>Castellano</source>
        <translation>İspanyol</translation>
    </message>
    <message utf8="true">
        <source>Inglés</source>
        <translation>İngilizce</translation>
    </message>
    <message utf8="true">
        <source>Portugués</source>
        <translation>Portekizli</translation>
    </message>
    <message utf8="true">
        <source>Francés</source>
        <translation>Fransız</translation>
    </message>
    <message utf8="true">
        <source>Alemán</source>
        <translation>Almanca</translation>
    </message>
    <message>
        <source>Euskera</source>
        <translation>Bask</translation>
    </message>
    <message utf8="true">
        <source>Catalán</source>
        <translation>Catalan</translation>
    </message>
    <message>
        <source>Gallego</source>
        <translation>Galik</translation>
    </message>
    <message>
        <source>Turco</source>
        <translation>Türkçe</translation>
    </message>
    <message>
        <source>Italiano</source>
        <translation>İtalyanca</translation>
    </message>
    <message utf8="true">
        <source>Árabe</source>
        <translation>Arapça</translation>
    </message>
    <message>
        <source>0 %</source>
        <translation>0%</translation>
    </message>
    <message>
        <source>20 %</source>
        <translation>20%</translation>
    </message>
    <message>
        <source>40 %</source>
        <translation>40%</translation>
    </message>
    <message>
        <source>60 %</source>
        <translation>60%</translation>
    </message>
    <message>
        <source>80 %</source>
        <translation>80%</translation>
    </message>
    <message>
        <source>100 %</source>
        <translation>100%</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation type="obsolete">Koyu</translation>
    </message>
    <message>
        <source>Green</source>
        <translation type="obsolete">Yeşil</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>Turuncu</translation>
    </message>
    <message>
        <source>Azul</source>
        <translation type="unfinished">Mavi</translation>
    </message>
    <message>
        <source>Negro</source>
        <translation type="unfinished">Siyah</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation>Yeşil</translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation type="unfinished">Kırmızı</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Hiçbiri</translation>
    </message>
    <message>
        <source>Marco de fotos digital</source>
        <translation>Dijital resim çerçevesi</translation>
    </message>
    <message>
        <source>1 minuto</source>
        <translation>1 dakika</translation>
    </message>
    <message>
        <source>2 minuto</source>
        <translation>2 dakika</translation>
    </message>
    <message>
        <source>5 minuto</source>
        <translation>5 dakika</translation>
    </message>
    <message>
        <source>10 minuto</source>
        <translation>10 dakika</translation>
    </message>
    <message>
        <source>15 minuto</source>
        <translation>15 dakika</translation>
    </message>
    <message>
        <source>30 minuto</source>
        <translation>30 dakika</translation>
    </message>
    <message>
        <source>Nunca</source>
        <translation>Hiçbir zaman</translation>
    </message>
    <message utf8="true">
        <source>Botón</source>
        <translation>Buton</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Eylem</translation>
    </message>
    <message>
        <source>Oscuro</source>
        <translation>gri</translation>
    </message>
    <message>
        <source>(vacio)</source>
        <translation>(Boş)</translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Genel</translation>
    </message>
    <message>
        <source> Identificador de pantalla</source>
        <translation>Ekran tanımlama</translation>
    </message>
    <message>
        <source> Idioma</source>
        <translation>Dil</translation>
    </message>
    <message>
        <source> Volumen</source>
        <translation>Ses</translation>
    </message>
    <message>
        <source> Brillo</source>
        <translation type="obsolete">Parlaklık</translation>
    </message>
    <message>
        <source>Sonido teclado</source>
        <translation>Tuş sesi</translation>
    </message>
    <message>
        <source>Sensor de presencia</source>
        <translation>Hareket sensörü</translation>
    </message>
    <message>
        <source> Paleta</source>
        <translation>Yüzey</translation>
    </message>
    <message>
        <source> Color iconos</source>
        <translation>Renk simgeler</translation>
    </message>
    <message>
        <source>Offset de temperatura</source>
        <translation>Sıcaklık offset</translation>
    </message>
    <message>
        <source>Visualizar cursor</source>
        <translation>Ekran imleci</translation>
    </message>
    <message>
        <source>Salvapantallas</source>
        <translation>Ekran koruyucu</translation>
    </message>
    <message>
        <source> Salvapantallas</source>
        <translation>Ekran koruyucu</translation>
    </message>
    <message utf8="true">
        <source> Activación Salvapantallas</source>
        <translation>Ekran koruyucuyu aç</translation>
    </message>
    <message>
        <source> Tiempo entre fotos</source>
        <translation>Fotograflar arası süre</translation>
    </message>
    <message>
        <source> Autoapagado</source>
        <translation>Oto kapanma</translation>
    </message>
    <message>
        <source>Botones</source>
        <translation>Tuşlar</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para ejecutar escenas</source>
        <translation>Şifre sahneleri yürütmek iste</translation>
    </message>
    <message utf8="true">
        <source>Habilitación tamper</source>
        <translation>etkin sabotaj</translation>
    </message>
    <message>
        <source>IP</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindow</name>
    <message>
        <source>Armado total</source>
        <translation>Genel Alarm</translation>
    </message>
    <message>
        <source>Armado parcial</source>
        <translation>Parçalı alarm</translation>
    </message>
    <message>
        <source>Armado perimetral</source>
        <translation>Çevresel alarm</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Hiçbiri</translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message utf8="true">
        <source>Intrusión</source>
        <translation>Hırsız</translation>
    </message>
    <message utf8="true">
        <source>Habilitar autoarmado de intrusión</source>
        <translation>Otomatik hırsız alarm kurmayı aç</translation>
    </message>
    <message>
        <source>Programa asociado el autoarmado</source>
        <translation>Otomatik alarm ile ilgili program</translation>
    </message>
    <message utf8="true">
        <source>Activar simulación de presencia con el armado total</source>
        <translation>Genel alarm ile varlık simulasyonunu aç</translation>
    </message>
    <message>
        <source>Tiempo de salida de la vivienda (seg):</source>
        <translation>Çıkış gecikmesi (saniye):</translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para armar la alarma de intrusión</source>
        <translation>Hırsız alarmı açmak için şifre sor</translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation>Yangın</translation>
    </message>
    <message>
        <source>Gas</source>
        <translation>Gaz</translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation>Su Taşkını</translation>
    </message>
    <message utf8="true">
        <source>Hora de auto limpieza de la electroválvula de agua:</source>
        <translation>Su vanası otomatik temizleme zamanı:</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>SS:dd</translation>
    </message>
    <message utf8="true">
        <source>Corte Red Eléctrica</source>
        <translation>Güç Arızası</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (min):</source>
        <translation>Aktivasyon gecikmesi (dk):</translation>
    </message>
    <message utf8="true">
        <source>Corte teléfono</source>
        <translation>Telefon arızası</translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation>Sistem</translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation>Tıbbi</translation>
    </message>
    <message utf8="true">
        <source>Detección de inactividad</source>
        <translation>Hareketsizlik algılama</translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation>Panik</translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation>hareketsizlik</translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation>Sabotaj</translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation>Tehdit</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Llamar en caso de alarma a:</source>
        <translation>Alarm durumunda ara:</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 1</source>
        <translation>Telefon 1</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 2</source>
        <translation>Telefon 2</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 3</source>
        <translation>Telefon 3</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 4</source>
        <translation>Telefon 4</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 5</source>
        <translation>Telefon 5</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 6</source>
        <translation>Telefon 6</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 7</source>
        <translation>Telefon 7</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 8</source>
        <translation>Telefon 8</translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation>Kişisel 
mesajlar</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (seg):</source>
        <translation>Aktivasyon gecikmesi (san):</translation>
    </message>
</context>
<context>
    <name>SecurityWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Armado Perimetral</source>
        <translation>Çevresel alarm</translation>
    </message>
    <message>
        <source>Armado Parcial</source>
        <translation>Parçalı alarm</translation>
    </message>
    <message>
        <source>Armado Total</source>
        <translation>Genel Alarm</translation>
    </message>
</context>
<context>
    <name>SensorControl</name>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
</context>
<context>
    <name>SensorControlClass</name>
    <message>
        <source>SensorControl</source>
        <translation>SensörKontrol</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">Arkafon-renk: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Deshabilitar sensor</source>
        <translation>Sensör iptal</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Yeniad</translation>
    </message>
    <message>
        <source>Interviene en el armado parcial</source>
        <translation>Parçalı alarm modundaki müdahaleler</translation>
    </message>
    <message>
        <source>Interviene en el armado perimetral</source>
        <translation>Çevresel alarm modundaki müdahaleler</translation>
    </message>
    <message>
        <source>Tiempo de entrada:</source>
        <translation>Giriş süresi:</translation>
    </message>
    <message>
        <source>Offset de temperatura:</source>
        <translation>Sıcaklık offset:</translation>
    </message>
    <message>
        <source>Retraso a la activacion:</source>
        <translation>Aktivasyon gecikmesi:</translation>
    </message>
</context>
<context>
    <name>SystemConfigWindow</name>
    <message utf8="true">
        <source>Se va a proceder a importar ficheros.
Por favor, no saque el dispositivo durante la importación.
 ¿Desea continuar?</source>
        <translation>Dosyalar alınacak. 
İşlem sırasında lütfen aygıtı çıkarmayın. 
devam etmek istiyor musunuz?</translation>
    </message>
    <message>
        <source>Importando...</source>
        <translation>Alım...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a exportar ficheros.
Por favor, no saque el dispositivo durante la exportación.
¿Desea continuar?</source>
        <translation>Dosyalar gönderilecek. 
İşlem sırasında lütfen aygıtı çıkarmayın. 
devam etmek istiyor musunuz?</translation>
    </message>
    <message>
        <source>Exportando...</source>
        <translation>Gönderim...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Firmware.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation>Yazılım versiyonu güncellenecek. 
İşlem sırasında lütfen aygıtı çıkarmayın. 
devam etmek istiyor musunuz?</translation>
    </message>
    <message>
        <source>Actualizando...</source>
        <translation>Güncelleniyor...</translation>
    </message>
    <message utf8="true">
        <source>Para proceder a calibrar el touch es necesario reiniciar la pantalla.
¿Desea continuar?</source>
        <translation>Dokunmatik ekranın kalibrasyonu için ekranın yeniden başlatılması gerekiyor.
devam edilsin mi?</translation>
    </message>
    <message>
        <source>Calibrar Touch...</source>
        <translation>Ekran kalibrasyonu...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Webserver.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation>Web sunucusu güncellenecek. 
İşlem sırasında lütfen aygıtı çıkarmayın. 
devam etmek istiyor musunuz?</translation>
    </message>
    <message>
        <source>Test Alarmas: %1
Pulse para %2</source>
        <translation>Alarm Testi:%1
%2 için basın</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>AÇ</translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>KAPAT</translation>
    </message>
    <message>
        <source>Activar</source>
        <translation>Aktive et</translation>
    </message>
    <message>
        <source>Activar licencia</source>
        <translation>Lisans aktivasyonu</translation>
    </message>
</context>
<context>
    <name>SystemConfigWindowClass</name>
    <message>
        <source>SystemConfigWindow</source>
        <translation>SistemAyarEkranı</translation>
    </message>
    <message>
        <source>Reset del Sistema</source>
        <translation>Sistem reset</translation>
    </message>
    <message>
        <source>Exportar Ficheros</source>
        <translation>Dosyaları gönder</translation>
    </message>
    <message>
        <source>Importar  Ficheros</source>
        <translation>Dosyaları al</translation>
    </message>
    <message>
        <source>Actualizar Firmware</source>
        <translation type="obsolete">Yazılım versiyonu güncelle</translation>
    </message>
    <message>
        <source>Acceder como
instalador</source>
        <translation>Servis girişi 
yap</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <source>Recalibrar Touch</source>
        <translation>Ekranı kalibre et</translation>
    </message>
    <message>
        <source>Actualizar
Firmware</source>
        <translation>Yazılım
 güncelle</translation>
    </message>
    <message>
        <source>Log de Errores</source>
        <translation>Hata kayıtlan</translation>
    </message>
    <message>
        <source>Actualizar
WebServer</source>
        <translation>Webserver
 güncelle</translation>
    </message>
    <message>
        <source>Prueba de alarmas: %1
Pulse para %2</source>
        <translation>Alarm Testi:%1
%2 için basın</translation>
    </message>
    <message>
        <source>Test llamadas CRA</source>
        <translation>AIM arama testi</translation>
    </message>
    <message>
        <source>Licencia...</source>
        <translation>Lisans...</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation>MetinEtiketi</translation>
    </message>
</context>
<context>
    <name>UsersConfigWindow</name>
    <message>
        <source>Nombre</source>
        <translation>Ad</translation>
    </message>
    <message>
        <source>Clave</source>
        <translation>Kod</translation>
    </message>
    <message>
        <source>Nivel Acceso</source>
        <translation>Giriş seviyesi</translation>
    </message>
    <message>
        <source>Maestro</source>
        <translation>Yönetici</translation>
    </message>
    <message>
        <source>Alto</source>
        <translation>Yüksek</translation>
    </message>
    <message>
        <source>Medio</source>
        <translation>Orta</translation>
    </message>
    <message>
        <source>Bajo</source>
        <translation>Düşük</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Yeni isim girin...</translation>
    </message>
    <message utf8="true">
        <source>Introduzca la nueva contraseña</source>
        <translation>Yeni şifreyi girin</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el usuario.
¿Está seguro?</source>
        <translation>Kullanıcı silinecek.
devam etmek istiyor musunuz?</translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation>Kişi sil...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Lütfen eksik veriyi girin.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Hata...</translation>
    </message>
    <message utf8="true">
        <source>No se puede eliminar el único usuario maestro del sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Eliminación de usuario interrumpida.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UsersConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Leer Llave</source>
        <translation>Kartı oku</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Kapat</translation>
    </message>
</context>
<context>
    <name>WarningDialog</name>
    <message utf8="true">
        <source>Fallo en el sistema de avisos telefónicos.</source>
        <translation>Telefon alarm uyarı hatası.</translation>
    </message>
    <message>
        <source>Test de CRA fallido.</source>
        <translation>AIM (alarm izleme merkezi) test hatası.</translation>
    </message>
    <message utf8="true">
        <source>Aviso de cancelación de alarma de intrusión fallido.</source>
        <translation>Hırsız alarm iptal uyarı hatası.</translation>
    </message>
    <message utf8="true">
        <source>Armado de intrusión cancelado. Sensor no temporizado activo:
%1</source>
        <translation>Hırsız alarmı iptal.Gecikmeli sensör yok:
%1</translation>
    </message>
    <message>
        <source>Climatizador apagado por ventana abierta:
%1</source>
        <translation>Pencere açık olduğu için klima kapatıldı: 
%1</translation>
    </message>
    <message>
        <source>Entrada de sensor en circuito abierto:
%1</source>
        <translation>Sensor girişi açık:
%1</translation>
    </message>
    <message utf8="true">
        <source>Cámara de videoportería ocupada.</source>
        <translation>Görüntülü diyafon kamerası meşgul.</translation>
    </message>
    <message>
        <source>No se ha encontrado el mensaje que se desea reproducir.</source>
        <translation>Dinlemek istediğiniz mesaj buunamadı.</translation>
    </message>
    <message utf8="true">
        <source>No hay espacio para grabar más mensajes de voz, o se ha alcanzado el límite de 10 mensajes.</source>
        <translation>Daha fazla mesaj için gerekli alan yok veya 10 adet mesaj sınırı aşılmış.</translation>
    </message>
    <message utf8="true">
        <source>Mensaje de Aviso Nº%1</source>
        <translation>Alarm mesajı Nº%1</translation>
    </message>
    <message utf8="true">
        <source>Error en la comunicación con el módulo %1:
Comando rechazado.</source>
        <translation>Modülü %1 ile iletişimde hata:
Komut reddetti.</translation>
    </message>
    <message>
        <source>Error al iniciar el sistema de ficheros. Compruebe si la tarjeta SD de la central funciona correctamente.</source>
        <translation>Dosya sistemi başlatılamadı.Bitki SD düzgün çalışıp çalışmadığını kontrol edin.</translation>
    </message>
    <message utf8="true">
        <source>El estado de la batería es bajo.</source>
        <translation>Pil durumu düşüktür.</translation>
    </message>
    <message utf8="true">
        <source>Perdidas de tramas en la comunicación.</source>
        <translation>Iletişim çerçeve içinde kayboldum.</translation>
    </message>
    <message utf8="true">
        <source>Comunicación recuperada.</source>
        <translation>İletişim kurtarıldı.</translation>
    </message>
    <message utf8="true">
        <source>No hay batería o la batería falla.</source>
        <translation>Veya pil hatası yok.</translation>
    </message>
    <message>
        <source>Iniciando el test de CRA...</source>
        <translation type="obsolete">AIM (alarm izleme merkezi)  testi başlatılıyor ...</translation>
    </message>
    <message>
        <source>El test CRA ha sido satisfactorio.</source>
        <translation>AIM (alarm izleme merkezi) testi başarılı oldu.</translation>
    </message>
    <message utf8="true">
        <source>Número de mensaje desconocido %1</source>
        <translation>Bilinmeyen mesaj numarası %1</translation>
    </message>
    <message>
        <source>Test de CRA...</source>
        <translation type="unfinished">Alarm izleme...</translation>
    </message>
</context>
<context>
    <name>WarningDialogClass</name>
    <message>
        <source>WarningDialog</source>
        <translation>UyarıEkranı</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation>&lt;&lt;</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation>&gt;&gt;</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Sil</translation>
    </message>
</context>
<context>
    <name>ZoneSelect</name>
    <message>
        <source>luces</source>
        <translation>Işıklar</translation>
    </message>
    <message>
        <source>clima</source>
        <translation>Klima</translation>
    </message>
    <message>
        <source>dispositivos</source>
        <translation>Cihazlar</translation>
    </message>
    <message>
        <source>persianas</source>
        <translation>Panjurlar</translation>
    </message>
    <message>
        <source>cortinas</source>
        <translation>Perdeler</translation>
    </message>
    <message>
        <source>puertas</source>
        <translation>Kapılar</translation>
    </message>
    <message>
        <source>riegos</source>
        <translation>kapılar</translation>
    </message>
    <message>
        <source>toldos</source>
        <translation>Güneşlikler</translation>
    </message>
    <message>
        <source>sensores</source>
        <translation>Sensörler</translation>
    </message>
</context>
<context>
    <name>ZoneSelectClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
</context>
</TS>
