<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it_IT">
<context>
    <name>AlarmDialog</name>
    <message utf8="true">
        <source>ALARMA DE INTRUSIÓN</source>
        <translation>ALLARME ANTINTRUSIONE</translation>
    </message>
    <message>
        <source>ALARMA DE FUEGO</source>
        <translation>ALLARME INCENDIO</translation>
    </message>
    <message>
        <source>ALARMA DE GAS</source>
        <translation>ALLARME GAS</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE INUNDACIÓN</source>
        <translation>ALLARME ALLAGAMENTO</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE ELÉCTRICO</source>
        <translation>ALLARME MANCANZA TENSIONE</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE TELEFÓNICO</source>
        <translation>ALLARME LINEA TELEFONICA</translation>
    </message>
    <message>
        <source>ALARMA DE SISTEMA</source>
        <translation>ALLARME DI SISTEMA</translation>
    </message>
    <message utf8="true">
        <source>ALARMA MÉDICA</source>
        <translation>ALLARME MEDICO</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE PÁNICO</source>
        <translation>ALLARME PANICO</translation>
    </message>
    <message>
        <source>ALARMA SILENCIOSA</source>
        <translation>ALLARME SILENZIOSO</translation>
    </message>
    <message>
        <source>ALARMA DE SABOTAJE</source>
        <translation>ALLARME MANOMISSIONE</translation>
    </message>
    <message>
        <source>REARMAR ALARMAS</source>
        <translation>RIATTIVARE ALLARMI</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar alarmas</source>
        <translation>Introdurre  password per disattivare gli allarmi</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE COACCIÓN</source>
        <translation>Allarme Coercizione</translation>
    </message>
    <message>
        <source>
 en las siguientes zonas:
</source>
        <translation>
nelle seguenti zone:</translation>
    </message>
    <message>
        <source>Hay alarmas desarmadas. Pulse rearmar para volver a proteger el sistema.</source>
        <translation>Gli allarmi sono disattivati. Premere Attiva per proteggere il sistema.</translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 90 segundos.</source>
        <translation type="unfinished">Sistema bloccato da tre tentativi errati di introduzione password.
Per introdurre nuovamente la password aspettare 90 secondi.</translation>
    </message>
    <message>
        <source>Sistema bloqueado</source>
        <translation type="unfinished">Sistema bloccato</translation>
    </message>
</context>
<context>
    <name>AlarmDialogClass</name>
    <message>
        <source>AlarmDialog</source>
        <translation>AlarmDialog</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="obsolete">Conferma</translation>
    </message>
    <message>
        <source>6</source>
        <translation type="obsolete">6</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="obsolete">3</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>8</source>
        <translation type="obsolete">8</translation>
    </message>
    <message>
        <source>9</source>
        <translation type="obsolete">9</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="obsolete">2</translation>
    </message>
    <message>
        <source>4</source>
        <translation type="obsolete">4</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <source>5</source>
        <translation type="obsolete">5</translation>
    </message>
    <message>
        <source>Introduzca clave de acceso</source>
        <translation type="obsolete">Inserisci codice accesso</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation type="obsolete">Cancella</translation>
    </message>
    <message>
        <source>7</source>
        <translation type="obsolete">7</translation>
    </message>
    <message>
        <source>Alarmas desarmadas</source>
        <translation type="obsolete">Disattiva allarme</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Disattiva</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation>&lt;&lt;</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation>&gt;&gt;</translation>
    </message>
    <message>
        <source>Rearmar</source>
        <translation>Riattiva</translation>
    </message>
    <message utf8="true">
        <source>Menú
Alarmas</source>
        <translation>Menu Allarmi</translation>
    </message>
</context>
<context>
    <name>AlarmsWindow</name>
    <message>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
</context>
<context>
    <name>AlarmsWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation>Incendio</translation>
    </message>
    <message>
        <source>Gas</source>
        <translation>Gas</translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation>Allagamento</translation>
    </message>
    <message utf8="true">
        <source>Corte de Red Eléctrica</source>
        <translation type="obsolete">Mancanza Tensione</translation>
    </message>
    <message utf8="true">
        <source>Corte de teléfono</source>
        <translation type="obsolete">Telephone fail</translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation>Sistema</translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation>Soccorso</translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation>Panico</translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation>Silenzioso</translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation>Manomissione</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Corte de Teléfono</source>
        <translation>Mancanza linea telefonica</translation>
    </message>
    <message utf8="true">
        <source>Corte Eléctrico</source>
        <translation>Mancanza Tensione</translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation>Coercizione</translation>
    </message>
</context>
<context>
    <name>ArmingWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Armando...</source>
        <translation>Inserimento in corso...</translation>
    </message>
</context>
<context>
    <name>AssociatedZones</name>
    <message>
        <source>Zonas asociadas</source>
        <translation type="obsolete">Associated zones</translation>
    </message>
</context>
<context>
    <name>AssociatedZonesClass</name>
    <message>
        <source>AssociatedZones</source>
        <translation></translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Abbassare</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Aumentare</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message utf8="true">
        <source>Indique las zonas de la vivienda asociadas con la unidad climática ...</source>
        <translation type="obsolete">Indicate zones associated to the climate control unit</translation>
    </message>
    <message utf8="true">
        <source>Zonas asociadas con la unidad climática...</source>
        <translation>Zone associate all&apos; unità di controllo temperatura...</translation>
    </message>
</context>
<context>
    <name>AudioVideoConfigWindow</name>
    <message>
        <source>  TV</source>
        <translation type="obsolete">TV</translation>
    </message>
    <message>
        <source>  TV Cable</source>
        <translation type="obsolete">TV via cavo</translation>
    </message>
    <message>
        <source>  DVD</source>
        <translation type="obsolete">DVD</translation>
    </message>
    <message>
        <source>  CD</source>
        <translation type="obsolete">CD</translation>
    </message>
    <message>
        <source>  MCE PC</source>
        <translation type="obsolete">Media nCenter</translation>
    </message>
    <message>
        <source>  VCR</source>
        <translation type="obsolete">VCR</translation>
    </message>
    <message>
        <source>  Radio</source>
        <translation type="obsolete">Radio</translation>
    </message>
    <message>
        <source>Modo visualizacion 1</source>
        <translation type="obsolete">Visualizzazione 1</translation>
    </message>
    <message>
        <source>Modo visualizacion 2</source>
        <translation type="obsolete">Visualizzazione 2</translation>
    </message>
    <message>
        <source>Modo visualizacion 3</source>
        <translation type="obsolete">Visualizzazione 3</translation>
    </message>
</context>
<context>
    <name>AudioVideoConfigWindowClass</name>
    <message>
        <source>Aplicar</source>
        <translation type="obsolete">Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="obsolete">Chiudi</translation>
    </message>
    <message>
        <source>Y/N</source>
        <translation type="obsolete">S/N</translation>
    </message>
    <message>
        <source>Dispositivo</source>
        <translation type="obsolete">Dispositivo</translation>
    </message>
    <message>
        <source>Visualizacion</source>
        <translation type="obsolete">Visualizzazione</translation>
    </message>
</context>
<context>
    <name>AudioVideoWindow</name>
    <message>
        <source>TV</source>
        <translation type="obsolete">TV</translation>
    </message>
    <message>
        <source>TV Cable</source>
        <translation type="obsolete">TV via cavo</translation>
    </message>
    <message>
        <source>DVD</source>
        <translation type="obsolete">DVD</translation>
    </message>
    <message>
        <source>CD</source>
        <translation type="obsolete">CD</translation>
    </message>
    <message>
        <source>MCE PC</source>
        <translation type="obsolete">Media Center</translation>
    </message>
    <message>
        <source>VCR</source>
        <translation type="obsolete">VCR</translation>
    </message>
    <message>
        <source>Radio</source>
        <translation type="obsolete">Radio</translation>
    </message>
</context>
<context>
    <name>AudioVideoWindowClass</name>
    <message>
        <source>Subir</source>
        <translation type="obsolete">Su</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation type="obsolete">Giù</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="obsolete">2</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="obsolete">3</translation>
    </message>
    <message>
        <source>4</source>
        <translation type="obsolete">4</translation>
    </message>
    <message>
        <source>5</source>
        <translation type="obsolete">5</translation>
    </message>
    <message>
        <source>6</source>
        <translation type="obsolete">6</translation>
    </message>
    <message>
        <source>7</source>
        <translation type="obsolete">7</translation>
    </message>
    <message>
        <source>8</source>
        <translation type="obsolete">8</translation>
    </message>
    <message>
        <source>9</source>
        <translation type="obsolete">9</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>Channel</source>
        <translation type="obsolete">Canale</translation>
    </message>
    <message>
        <source>+</source>
        <translation type="obsolete">+</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="obsolete">Volume</translation>
    </message>
    <message>
        <source>-</source>
        <translation type="obsolete">-</translation>
    </message>
    <message>
        <source>EJECT</source>
        <translation type="obsolete">Espelli</translation>
    </message>
    <message>
        <source> 91.4 FM</source>
        <translation type="obsolete">91.4 FM</translation>
    </message>
    <message>
        <source>Tune</source>
        <translation type="obsolete">Tune</translation>
    </message>
</context>
<context>
    <name>BlackboardWindowClass</name>
    <message>
        <source>BlackboardWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation>Salva</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Cancella</translation>
    </message>
</context>
<context>
    <name>BlindControl</name>
    <message>
        <source>Manual</source>
        <translation>Manuale</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Timer</translation>
    </message>
    <message>
        <source>Arriba</source>
        <translation type="obsolete">Su</translation>
    </message>
    <message>
        <source>Abajo</source>
        <translation type="obsolete">Giù</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Inserisci nuovo nome...</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Sconosciuto</translation>
    </message>
    <message>
        <source>Grupo de persianas</source>
        <translation>Gruppo di tapparella veneziana</translation>
    </message>
</context>
<context>
    <name>BlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Timer associato:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <source>Bajar persianas en caso de lluvia</source>
        <translation>Abbassa le tapparelle in caso di pioggia</translation>
    </message>
    <message>
        <source>Consigna en modo programa:</source>
        <translation type="obsolete">Set point memorizzati:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo di funzionamento:</translation>
    </message>
    <message>
        <source>%</source>
        <translation type="obsolete">%</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Tutti</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Tempo di salita/discesa:</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Cambiare icona</translation>
    </message>
    <message>
        <source>Bajar persianas en caso de viento fuerte</source>
        <translation type="unfinished">Scarica persiane in caso di forte vento</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DOWN</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CRAConfigDialog</name>
    <message>
        <source>ADEMCO CID</source>
        <translation>ADEMCO CID</translation>
    </message>
    <message utf8="true">
        <source>Introduzca el código de abonado ...</source>
        <translation>introduca il codice abbonamento...</translation>
    </message>
</context>
<context>
    <name>CRAConfigDialogClass</name>
    <message>
        <source>CRAConfigDialog</source>
        <translation>CRAConfigDialog</translation>
    </message>
    <message>
        <source>Configuracion CRA</source>
        <translation>Configuraione CRA</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Habilitacion</source>
        <translation>Abiitazione</translation>
    </message>
    <message>
        <source>Cambiar
Codigo</source>
        <translation>C ambiare
Codice</translation>
    </message>
    <message>
        <source>Protocolo</source>
        <translation>Protocollo</translation>
    </message>
    <message>
        <source>Autotest</source>
        <translation>Autotest</translation>
    </message>
    <message>
        <source>Cadencia</source>
        <translation>Cadenza </translation>
    </message>
    <message>
        <source>Hora del primer test</source>
        <translation>oa del primo test</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:mm</translation>
    </message>
    <message>
        <source>Codigo de cuenta</source>
        <translation>Codice di con teggio</translation>
    </message>
</context>
<context>
    <name>CamsWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation>Chiamata portineria</translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation>Comunicazione con  portineria attiva</translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation>Non è possibile stabilire una comunicazione perchè è scollegato l&apos;altro terminale.</translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation>videocitofono occupato</translation>
    </message>
</context>
<context>
    <name>CamsWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation>Parla</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Apri</translation>
    </message>
    <message>
        <source>+</source>
        <translation type="obsolete">+</translation>
    </message>
    <message>
        <source>-</source>
        <translation type="obsolete">-</translation>
    </message>
    <message>
        <source>&lt;</source>
        <translation type="obsolete">&lt;</translation>
    </message>
    <message>
        <source>&gt;</source>
        <translation type="obsolete">&gt;</translation>
    </message>
    <message>
        <source>^</source>
        <translation type="obsolete">^</translation>
    </message>
    <message>
        <source>v</source>
        <translation type="obsolete">v</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation>Alza Vol.</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation>Abbassa Vol.</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Alza</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Abbassa</translation>
    </message>
    <message>
        <source>Izquierda</source>
        <translation>Sinistra</translation>
    </message>
    <message>
        <source>Derecha</source>
        <translation>Destra</translation>
    </message>
</context>
<context>
    <name>ClimaControl</name>
    <message utf8="true">
        <source>Frío</source>
        <translation>Freddo</translation>
    </message>
    <message>
        <source>Calor</source>
        <translation>Caldo</translation>
    </message>
    <message>
        <source>Climatizador</source>
        <translation>Climatizzatore</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Inserisci nuovo nome...</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation>Spegnimento</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Nessuno</translation>
    </message>
</context>
<context>
    <name>ClimaControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Modo general:</source>
        <translation>Modalità standard:</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation type="obsolete">Timer associato:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rinomina</translation>
    </message>
    <message utf8="true">
        <source>Apagar climatización en caso de ventana abierta</source>
        <translation>Spegni la climatizzazione in caso di finestra aperta</translation>
    </message>
    <message>
        <source>Consigna Min:</source>
        <translation type="obsolete">Set point min:</translation>
    </message>
    <message>
        <source>Consigna Max:</source>
        <translation type="obsolete">Set point max:</translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source>Zonas Asociadas</source>
        <translation type="obsolete">Zone associate</translation>
    </message>
    <message>
        <source>Consigna en modo programa:</source>
        <translation type="obsolete">Set point memorizzati:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>modo</source>
        <translation>modalita</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message utf8="true">
        <source>0ºC</source>
        <translation>0ºC</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Cambiare icona</translation>
    </message>
    <message>
        <source>Sensor de temperatura asociado:</source>
        <translation>Sensore di temperatura  associato:</translation>
    </message>
    <message>
        <source>Histeresis:</source>
        <translation>Isteresi:</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Tutti</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Disposit.</translation>
    </message>
    <message>
        <source>Primer programa asociado:</source>
        <translation>Primo programma associato:</translation>
    </message>
    <message>
        <source>Consig. Min:</source>
        <translation>Set point min:</translation>
    </message>
    <message>
        <source>Consig. Max:</source>
        <translation>Set point max:</translation>
    </message>
    <message>
        <source>Zonas
Asociadas</source>
        <translation>Zone
Associate</translation>
    </message>
    <message>
        <source>Segundo programa asociado:</source>
        <translation>Secondo programma associato:</translation>
    </message>
</context>
<context>
    <name>ClimaWindow</name>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
</context>
<context>
    <name>ClimaWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Maschera</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>MANUAL</source>
        <translation>MANUALE</translation>
    </message>
    <message>
        <source>PROGRAMA</source>
        <translation>Timer</translation>
    </message>
    <message>
        <source>ECO</source>
        <translation>ECO</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="obsolete">Textlabel</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message utf8="true">
        <source>20ºC</source>
        <translation type="obsolete">20ºC</translation>
    </message>
    <message utf8="true">
        <source>23ºC</source>
        <translation type="obsolete">23ºC</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Diminuire</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Aumentare</translation>
    </message>
    <message utf8="true">
        <source>--ºC</source>
        <translation>--ºC</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
</context>
<context>
    <name>Communication</name>
    <message utf8="true">
        <source>Los ficheros de configuración no coinciden.
Para sobreescribir los ficheros de la central en la pantalla
pulsa Aceptar. En caso contrario, pulsa Cancelar.</source>
        <translation type="obsolete">Configuration files are different.
To overwrite the central&apos;s files into the display
click Accept. Otherwise, click Cancel</translation>
    </message>
    <message utf8="true">
        <source>Actualizar configuración</source>
        <translation type="obsolete">Configuration update</translation>
    </message>
</context>
<context>
    <name>ConfigWindow</name>
    <message utf8="true">
        <source>Vivimat III

versión 1.0.0</source>
        <translation type="obsolete">Vivimat III

version 1.0.0</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión 1.0.0</source>
        <translation type="obsolete">Vision Color 7

version 1.0.0</translation>
    </message>
    <message utf8="true">
        <source>Vivimat III

versión %1.%2.%3

[%4]</source>
        <translation>Vivimat III

versione %1.%2.%3

[%4]</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión 0.6.4</source>
        <translation type="obsolete">Vision Color 7

versione 0.6.4 </translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión %1.%2.%3
</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Sistema de ficheros

Versión: %1</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Vivimat III

versión Demo %1.%2.%3

[%4]</source>
        <translation type="unfinished">Vivimat III Demo%1.%2.%3[%4]</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión Demo %1.%2.%3
</source>
        <translation type="unfinished">Vision Color 7 Demo %1.%2.%3</translation>
    </message>
</context>
<context>
    <name>ConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Maschera</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;Vivimat III&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;versión 1.0.0&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;Vivimat III&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;version 1.0.0&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;Vision Color 7&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;versión 1.0.0&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;Vision Color 7&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;version 1.0.0&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>mando IR</source>
        <translation>Telecomando IR</translation>
    </message>
    <message>
        <source>programas horarios</source>
        <translation>Programmazione oraria</translation>
    </message>
    <message>
        <source>multimedia</source>
        <translation>Multimedia</translation>
    </message>
    <message utf8="true">
        <source>gestión de energía</source>
        <translation>Gestione carichi</translation>
    </message>
    <message>
        <source>escenas</source>
        <translation>Scenari</translation>
    </message>
    <message utf8="true">
        <source>telefonía</source>
        <translation>Telefono</translation>
    </message>
    <message>
        <source>usuarios</source>
        <translation>Utente</translation>
    </message>
    <message>
        <source>sistema</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation>Sicurezza</translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation>Videocitofono</translation>
    </message>
    <message>
        <source>fecha y hora</source>
        <translation>Data e ora</translation>
    </message>
    <message>
        <source>pantalla</source>
        <translation>Schermo</translation>
    </message>
    <message utf8="true">
        <source>Vivimat III

versión 1.0.0</source>
        <translation type="obsolete">Vivimat III

version 1.0.0</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión 1.0.0</source>
        <translation type="obsolete">Vision Color 7

version 1.0.0</translation>
    </message>
</context>
<context>
    <name>ConfirmationDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancella</translation>
    </message>
</context>
<context>
    <name>ConfirmationWindowClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation type="obsolete">ConfirmationWindow</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="obsolete">Accept</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="obsolete">Cancel</translation>
    </message>
</context>
<context>
    <name>ConsumptionWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Escala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Semana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mes</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Año</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unidades</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unit3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConsumptionsConfigWindow</name>
    <message>
        <source>Visualizacion</source>
        <translation type="obsolete">View</translation>
    </message>
    <message>
        <source>S/N</source>
        <translation type="obsolete">S/N</translation>
    </message>
    <message>
        <source>Diario</source>
        <translation type="obsolete">Giornaliero</translation>
    </message>
    <message>
        <source>Semanal</source>
        <translation type="obsolete">Settimanale</translation>
    </message>
    <message>
        <source>Mensual</source>
        <translation type="obsolete">Mensile</translation>
    </message>
    <message>
        <source>Anual</source>
        <translation type="obsolete">Annuale</translation>
    </message>
    <message>
        <source>Ultima factura</source>
        <translation type="obsolete">Last bill</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="obsolete">2</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="obsolete">3</translation>
    </message>
    <message>
        <source>4</source>
        <translation type="obsolete">4</translation>
    </message>
    <message>
        <source>5</source>
        <translation type="obsolete">5</translation>
    </message>
    <message>
        <source>6</source>
        <translation type="obsolete">6</translation>
    </message>
    <message>
        <source>7</source>
        <translation type="obsolete">7</translation>
    </message>
    <message>
        <source>8</source>
        <translation type="obsolete">8</translation>
    </message>
    <message>
        <source>9</source>
        <translation type="obsolete">9</translation>
    </message>
    <message>
        <source>10</source>
        <translation type="obsolete">10</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="obsolete">Inserisci nuovo nome...</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Prioridad</source>
        <translation type="obsolete">Priorità</translation>
    </message>
    <message>
        <source>Coste/Unidad</source>
        <translation type="obsolete">Costo/unità</translation>
    </message>
    <message>
        <source>Alarma</source>
        <translation type="obsolete">Allarme </translation>
    </message>
    <message>
        <source>Umbral alarma</source>
        <translation type="obsolete">Soglia allarme</translation>
    </message>
    <message>
        <source>euros
/unidad</source>
        <translation type="obsolete">euro
/unita</translation>
    </message>
    <message>
        <source>Modificar fecha ultima factura</source>
        <translation type="obsolete">Modify date of last bill</translation>
    </message>
    <message utf8="true">
        <source>Visualización</source>
        <translation type="obsolete">Visualizzazione</translation>
    </message>
    <message utf8="true">
        <source>Contaminación CO2</source>
        <translation type="obsolete">Allarme CO2</translation>
    </message>
    <message utf8="true">
        <source>Última factura</source>
        <translation type="obsolete">Ultima fattura</translation>
    </message>
    <message>
        <source>m3</source>
        <translation type="obsolete">m3</translation>
    </message>
    <message>
        <source>SUBCIRCUITO </source>
        <translation type="obsolete">ALTRA ZONA</translation>
    </message>
    <message utf8="true">
        <source>Modificar fecha última factura</source>
        <translation type="obsolete">Cambia data ultima fattura</translation>
    </message>
</context>
<context>
    <name>ConsumptionsConfigWindowClass</name>
    <message>
        <source>GAS</source>
        <translation type="obsolete">GAS</translation>
    </message>
    <message>
        <source>AGUA</source>
        <translation type="obsolete">ACQUA</translation>
    </message>
    <message>
        <source>ELECTRICIDAD</source>
        <translation type="obsolete">ELETTRICITA&apos;</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 1</source>
        <translation type="obsolete">ALTRA ZONA 1</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 2</source>
        <translation type="obsolete">ALTRA ZONA 2</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 3</source>
        <translation type="obsolete">ALTRA ZONA 3</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 4</source>
        <translation type="obsolete">ALTRA ZONA 4</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 5</source>
        <translation type="obsolete">ALTRA ZONA 5</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 6</source>
        <translation type="obsolete">ALTRA ZONA 6</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 7</source>
        <translation type="obsolete">ALTRA ZONA 7</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 8</source>
        <translation type="obsolete">ALTRA ZONA 8</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 9</source>
        <translation type="obsolete">ALTRA ZONA 9</translation>
    </message>
    <message>
        <source>SUBCIRCUITO 10</source>
        <translation type="obsolete">ALTRA ZONA 10</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="obsolete">Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="obsolete">Chiudi</translation>
    </message>
    <message>
        <source>Fecha
ultima factura</source>
        <translation type="obsolete">Data ultima fattura</translation>
    </message>
</context>
<context>
    <name>ConsumptionsDisplayWindow</name>
    <message>
        <source>Consumo diario</source>
        <translation type="obsolete">Consumo giornaliero</translation>
    </message>
    <message>
        <source>Consumo semanal</source>
        <translation type="obsolete">Consumo settimanale</translation>
    </message>
    <message>
        <source>Consumo mensual</source>
        <translation type="obsolete">Consumo mensile</translation>
    </message>
    <message>
        <source>Consumo anual</source>
        <translation type="obsolete">Consumo annuale</translation>
    </message>
    <message utf8="true">
        <source>Consumo desde última factura</source>
        <translation type="obsolete">Consumo dall&apos;ultima fattura</translation>
    </message>
    <message>
        <source> m3</source>
        <translation type="obsolete">m3</translation>
    </message>
    <message>
        <source> Kw</source>
        <translation type="obsolete">Kw</translation>
    </message>
    <message>
        <source> L</source>
        <translation type="obsolete">Litri</translation>
    </message>
    <message>
        <source>Consumo desde ultima factura</source>
        <translation type="obsolete">Consumo dall&apos;ultima fattura</translation>
    </message>
</context>
<context>
    <name>ConsumptionsDisplayWindowClass</name>
    <message>
        <source>Consumo diario</source>
        <translation type="obsolete">Daily consumption</translation>
    </message>
    <message>
        <source>Consumo semanal</source>
        <translation type="obsolete">Weekly consumption</translation>
    </message>
    <message>
        <source>Consumo mensual</source>
        <translation type="obsolete">Monthly consumption</translation>
    </message>
    <message>
        <source>Consumo anual</source>
        <translation type="obsolete">Yearly consumption</translation>
    </message>
    <message>
        <source>Consumo desde ultima factura</source>
        <translation type="obsolete">Consumption since last bill</translation>
    </message>
</context>
<context>
    <name>ConsumptionsWindow</name>
    <message>
        <source>GAS
12l</source>
        <translation type="obsolete">GAS
12l</translation>
    </message>
    <message>
        <source>AGUA
55m3</source>
        <translation type="obsolete">WATER
55m3</translation>
    </message>
    <message>
        <source>ELECTRICIDAD
172Kw</source>
        <translation type="obsolete">ELECTRICITY
172Kw</translation>
    </message>
    <message>
        <source>SUBCIRCUITO </source>
        <translation type="obsolete">SUBCIRCUIT</translation>
    </message>
    <message>
        <source>
Consumo diario:</source>
        <translation type="obsolete">Consumo giornaliero:</translation>
    </message>
    <message>
        <source>
1 L</source>
        <translation type="obsolete">
1 Lt</translation>
    </message>
    <message>
        <source>
0.09 m3</source>
        <translation type="obsolete">
0.09 m3</translation>
    </message>
    <message>
        <source>
155 Kw</source>
        <translation type="obsolete">
155 Kw</translation>
    </message>
    <message>
        <source>
Consumo semanal:</source>
        <translation type="obsolete">Consumo settimanale:</translation>
    </message>
    <message>
        <source>
2.3 L</source>
        <translation type="obsolete">
2.3 Lt</translation>
    </message>
    <message>
        <source>
0.27 m3</source>
        <translation type="obsolete">
0.27 m3</translation>
    </message>
    <message>
        <source>
680 Kw</source>
        <translation type="obsolete">
680 Kw</translation>
    </message>
    <message>
        <source>
Consumo mensual:</source>
        <translation type="obsolete">Consumo mensile:</translation>
    </message>
    <message>
        <source>
7.1 L</source>
        <translation type="obsolete">
7.1 Lt</translation>
    </message>
    <message>
        <source>
0.63 m3</source>
        <translation type="obsolete">
0.63 m3</translation>
    </message>
    <message>
        <source>
1182 Kw</source>
        <translation type="obsolete">
1182 Kw</translation>
    </message>
    <message>
        <source>
Consumo anual:</source>
        <translation type="obsolete">Consumo annuale:</translation>
    </message>
    <message>
        <source>
84.7 L</source>
        <translation type="obsolete">
84.7 Lt</translation>
    </message>
    <message>
        <source>
3.82 m3</source>
        <translation type="obsolete">
3.82 m3</translation>
    </message>
    <message>
        <source>
5711 Kw</source>
        <translation type="obsolete">
5711 Kw</translation>
    </message>
    <message utf8="true">
        <source>
Consumo última factura:</source>
        <translation type="obsolete">Consumo dall&apos;ultima fattura:</translation>
    </message>
    <message>
        <source>
4.9 L</source>
        <translation type="obsolete">
4.9 Lt</translation>
    </message>
    <message>
        <source>
0.21 m3</source>
        <translation type="obsolete">
0.21 m3</translation>
    </message>
    <message>
        <source>
711 Kw</source>
        <translation type="obsolete">
711 Kw</translation>
    </message>
    <message>
        <source>CIRC. </source>
        <translation type="obsolete">CIRC.</translation>
    </message>
</context>
<context>
    <name>CurtainControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Sconosciuto</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuale</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programma</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Inserisci nuovo nome...</translation>
    </message>
    <message>
        <source>Grupo de cortinas</source>
        <translation>Gruppo di tende</translation>
    </message>
</context>
<context>
    <name>CurtainControlClass</name>
    <message>
        <source>CurtainControl</source>
        <translation>CurtainControl</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programma associato:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo di funzionamento:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Cambiare icona</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Tempo di salita/discesa:</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Tutti</translation>
    </message>
</context>
<context>
    <name>DateHourWindow</name>
    <message>
        <source>Lunes</source>
        <translation>Lunedì</translation>
    </message>
    <message>
        <source>Martes</source>
        <translation>Martedì</translation>
    </message>
    <message utf8="true">
        <source>Miércoles</source>
        <translation>Mercoledi</translation>
    </message>
    <message>
        <source>Jueves</source>
        <translation>Giovedì</translation>
    </message>
    <message>
        <source>Viernes</source>
        <translation>Venerdì</translation>
    </message>
    <message utf8="true">
        <source>Sábado</source>
        <translation>Sabato</translation>
    </message>
    <message>
        <source>Domingo</source>
        <translation>Domenica</translation>
    </message>
</context>
<context>
    <name>DateHourWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>/</source>
        <translation>/</translation>
    </message>
    <message>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
</context>
<context>
    <name>DoorControl</name>
    <message>
        <source>Ninguno</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>Abierta</source>
        <translation>Aperta</translation>
    </message>
    <message>
        <source>Cerrada</source>
        <translation>Chiusa</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Stato sconosciuto</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuale</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Programma</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Apri</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Inserisci nuovo nome...</translation>
    </message>
</context>
<context>
    <name>DoorControlClass</name>
    <message>
        <source>DoorControl</source>
        <translation>DoorControl</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programma associato:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo di funzionamento:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Cambiare icona</translation>
    </message>
    <message>
        <source>Tiempo de apertura / cierre:</source>
        <translation>Tempo di apertura/chiusura:</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Tutti</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Apri</translation>
    </message>
</context>
<context>
    <name>DoorphoneDialog</name>
    <message>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Llamada VIDEOPORTERO</source>
        <translation>chiamata VIDEOCITOFONO</translation>
    </message>
    <message>
        <source>Llamada desde videoportero</source>
        <translation>chiamata dal videocitofono</translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation>Chiamata portineria</translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation>Comunicazione con  portineria attiva</translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation>Non è possibile stabilire una comunicazione perchè è scollegato l&apos;altro terminale.</translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation>videocitofono occupato</translation>
    </message>
    <message>
        <source>Conserje no contesta.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación, otra lladama en curso.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conserge ocupado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Maschera</translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation>Parla</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Apri</translation>
    </message>
    <message>
        <source>+</source>
        <translation type="obsolete">+</translation>
    </message>
    <message>
        <source>-</source>
        <translation type="obsolete">-</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation type="obsolete">Abbassa Vol.</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation type="obsolete">Alza Vol.</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Diminuire</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Aumentare</translation>
    </message>
    <message utf8="true">
        <source>Portería</source>
        <translation>Portineria</translation>
    </message>
    <message>
        <source>Ver</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EntryphoneConfigWindow</name>
    <message>
        <source>Grabando mensaje...</source>
        <translation type="obsolete">Registra messaggio...</translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation type="obsolete">Riproduci Messaggio...</translation>
    </message>
</context>
<context>
    <name>EntryphoneConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Maschera</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Grabar</source>
        <translation type="obsolete">Registra</translation>
    </message>
    <message>
        <source>Reproducir</source>
        <translation type="obsolete">Riproduci</translation>
    </message>
    <message utf8="true">
        <source>Habilitar Desvío</source>
        <translation>Abilita deviazione  di chiamata</translation>
    </message>
    <message>
        <source>Habilitar Contestador</source>
        <translation>Abilita segreteria</translation>
    </message>
    <message utf8="true">
        <source>Contacto al que se
desvía la llamada:</source>
        <translation type="obsolete">Devia la chiamata a:</translation>
    </message>
    <message>
        <source>Juan</source>
        <translation type="obsolete">Kemal</translation>
    </message>
    <message>
        <source>Pedro</source>
        <translation type="obsolete">Nicola</translation>
    </message>
    <message>
        <source>Mensaje para contestador</source>
        <translation type="obsolete">Messaggio segreteria</translation>
    </message>
    <message utf8="true">
        <source>Contacto al que se desvía la llamada:</source>
        <translation>Devia la chiamata a:</translation>
    </message>
    <message>
        <source>Habilitar llamada desde puerta de entrada</source>
        <translation>abilita la chiamata  da questa porta di entrata</translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation>Messaggi
Personali</translation>
    </message>
    <message utf8="true">
        <source>Número de veces que sonara: </source>
        <translation type="unfinished">Tempi suono:</translation>
    </message>
</context>
<context>
    <name>FileTransfer</name>
    <message>
        <source>Aplicacion DEMO para Windows.Simulando la transferencia de ficheros.</source>
        <translation>Applicazione DEMO per windows. Simula il trasferimento dei file.</translation>
    </message>
    <message>
        <source>Se ha encontrado una tarjeta SD.No saque la tarjeta hasta que finalice el intercambio de ficheros.</source>
        <translation>E&apos; stato trovato un dispositivo SD.Non rimuovere ilo dispositivio fino l termine del trasferimento dei file.</translation>
    </message>
    <message>
        <source>Se ha encontrado un dispositivo USB.No saque el dispositivo hasta que finalice el intercambio de ficheros.</source>
        <translation>E&apos; stato trovato un dispositivo USB.Non rimuovere ilo dispositivio fino l termine del trasferimento dei file.</translation>
    </message>
    <message utf8="true">
        <source>No se ha encontrado ningún dispositivo.Pulsa cancelar para salir.</source>
        <translation>Non è stato trovato alcun dispositivo.Premere Cancella per uscire.</translation>
    </message>
    <message utf8="true">
        <source>La actualización ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation>L&apos;aggiornamento è terminato.E&apos; necessario reinizializzare il sistema.</translation>
    </message>
    <message utf8="true">
        <source>La exportación ha finalizado.Pulsa Aceptar para continuar.</source>
        <translation>L&apos;esportazione è terminata.Premi Accetare per continuare.</translation>
    </message>
    <message utf8="true">
        <source>La importación ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation>l&apos;importazione è terminata. E&apos; necessario reinizzializzare il sistema..</translation>
    </message>
    <message>
        <source>No existe un fichero de firmware. Inserte un dispositivo con un fichero de firmware.</source>
        <translation>Non vi è alcun file del firmware. Inserire un dispositivo con un file del firmware.</translation>
    </message>
    <message>
        <source>Error a la hora de copiar el nuevo firmware.</source>
        <translation>Errore durante la copia del nuovo firmware.</translation>
    </message>
    <message utf8="true">
        <source>La copia del programa de calibración ha fallado.</source>
        <translation type="obsolete">La copia del programma di calibrazione non è riuscita.</translation>
    </message>
    <message utf8="true">
        <source>No se encuentran todos los ficheros necesarios para la actualizacion del servidor web.
No se ha podido realizar la actualización.</source>
        <translation>Ci sono tutti i file necessari per aggiornare il server web.
Impossibile aggiornare.</translation>
    </message>
    <message utf8="true">
        <source>La actualización ha fallado. Se mantiene el viejo rcS.</source>
        <translation>L&apos;aggiornamento non è riuscito. Mantiene la vecchia rcS.</translation>
    </message>
    <message>
        <source>cp -rf %1/PantallaColor /App/PantallaColor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileTransferClass</name>
    <message>
        <source>FileTransfer</source>
        <translation>Trasferimento file</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
</context>
<context>
    <name>FloorSelectClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Abbassa</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Alza</translation>
    </message>
</context>
<context>
    <name>HistoryWindow</name>
    <message>
        <source>Mensaje</source>
        <translation type="obsolete">Messaggio</translation>
    </message>
    <message>
        <source>Fecha/Hora</source>
        <translation type="obsolete">Data/ora</translation>
    </message>
    <message>
        <source>Historial de Eventos</source>
        <translation>Storico eventi</translation>
    </message>
    <message>
        <source>Historial de Errores</source>
        <translation>Storico errori</translation>
    </message>
</context>
<context>
    <name>HistoryWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Maschera</translation>
    </message>
    <message>
        <source>Mensaje</source>
        <translation type="obsolete">Messaggio</translation>
    </message>
    <message>
        <source>Fecha / Hora</source>
        <translation type="obsolete">Data/ora</translation>
    </message>
    <message utf8="true">
        <source>Alm. intrusión armada por Eugenio</source>
        <translation type="obsolete">Allarme intrusione inserito da Eugenio</translation>
    </message>
    <message>
        <source>05/01/2008 9:50</source>
        <translation type="obsolete">05/01/2008 9:50</translation>
    </message>
    <message utf8="true">
        <source>Alm. intrusión en Salón</source>
        <translation type="obsolete">Scattato allarme sala</translation>
    </message>
    <message>
        <source>05/01/2008 9:55</source>
        <translation type="obsolete">05/01/2008 9:55</translation>
    </message>
    <message utf8="true">
        <source>Alm. intrusión desarmada</source>
        <translation type="obsolete">Disattivazione allarme</translation>
    </message>
    <message>
        <source>05/01/2008 10:45</source>
        <translation type="obsolete">05/01/2008 10:45</translation>
    </message>
    <message utf8="true">
        <source>Alm. Pánico activada</source>
        <translation type="obsolete">Allarme panico attivato</translation>
    </message>
    <message>
        <source>10/01/2008 9:50</source>
        <translation type="obsolete">10/01/2008 9:50</translation>
    </message>
    <message utf8="true">
        <source>Alm. Pánico desactivada</source>
        <translation type="obsolete">Allarme panico disattivato</translation>
    </message>
    <message>
        <source>11/01/2008 13:50</source>
        <translation type="obsolete">11/01/2008 13:50</translation>
    </message>
    <message>
        <source>Historial de Eventos</source>
        <translation>Storico eventi</translation>
    </message>
    <message>
        <source>01/01/2010 13:39:05 &gt; System initialization completed
01/01/2010 13:45:15 &gt; Intrusion alarm armed in total mode: Sergio
01/01/2010 13:50:05 &gt; Intrusion alarm disarmed: Sergio
</source>
        <translation>01/01/2010 13:39:05&gt;Inizializzazione del sistema completata
01/01/2010 13:45:15&gt;Ativato allarme antintrusione totale:Sergio
01/01/2010 13:50:05&gt; Allarme antintrusione disattivato:Sergio
</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
</context>
<context>
    <name>IRCodeReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>Apunte el mando hacia el
receptor y pulse la tecla
correspondiente...</source>
        <translation>Punta il telecomando
verso il ricevitore e 
premi il tasto...</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message utf8="true">
        <source>Leer código de infrarrojos</source>
        <translation>Apprendimento codici infrarossi</translation>
    </message>
    <message>
        <source>R</source>
        <translation type="obsolete">R</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindow</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation>Esegui scena</translation>
    </message>
    <message>
        <source>Arm. Intr. Peri.</source>
        <translation type="obsolete">Attiva all.perim.</translation>
    </message>
    <message utf8="true">
        <source>Activar pánico</source>
        <translation>Attiva all. panico</translation>
    </message>
    <message>
        <source>Abrir puerta</source>
        <translation type="obsolete">Apri porta</translation>
    </message>
    <message>
        <source>Cambiar cámara</source>
        <translation type="obsolete">Switch camera</translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation>Accendi luce</translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation>Spegni luci</translation>
    </message>
    <message>
        <source>Subir persiana</source>
        <translation type="obsolete">Raise blind</translation>
    </message>
    <message>
        <source>Bajar persiana</source>
        <translation type="obsolete">Lower blind</translation>
    </message>
    <message>
        <source>Encender clima</source>
        <translation>Accendi climatizzazione</translation>
    </message>
    <message>
        <source>Apagar clima</source>
        <translation>spegni climatizzazione</translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation>Accendi dispositivo</translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation>Spegnere dispositivi</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduci nuovo nome ...</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Azione</translation>
    </message>
    <message utf8="true">
        <source>Código IR</source>
        <translation>Codice IR</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Completa i dati mancanti.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Errore...</translation>
    </message>
    <message>
        <source>Luz ON</source>
        <translation type="obsolete">Luce ON</translation>
    </message>
    <message>
        <source>Luz OFF</source>
        <translation type="obsolete">Luce  OFF</translation>
    </message>
    <message>
        <source>Incrementar luz</source>
        <translation type="obsolete">Aumenta luce</translation>
    </message>
    <message>
        <source>Decrementar luz</source>
        <translation type="obsolete">Diminuisci luce</translation>
    </message>
    <message>
        <source>Subir elemento motorizado</source>
        <translation type="obsolete">Alza motore</translation>
    </message>
    <message>
        <source>Bajar elemento motorizado</source>
        <translation type="obsolete">Abbassa motore</translation>
    </message>
    <message>
        <source>Clima ON</source>
        <translation type="obsolete">Clima ON</translation>
    </message>
    <message>
        <source>Clima OFF</source>
        <translation type="obsolete">Clima OFF </translation>
    </message>
    <message>
        <source>Enchufe ON</source>
        <translation type="obsolete">Presa FM ON</translation>
    </message>
    <message>
        <source>Enchufe OFF</source>
        <translation type="obsolete">Presa FM OFF</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la acción.
¿Está seguro?</source>
        <translation>L&apos;azione verrà cancellata.
Vuoi proseguire?</translation>
    </message>
    <message utf8="true">
        <source>Eliminar acción...</source>
        <translation>Elimina azione...</translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation>Arm Antintrusione Perimetrale</translation>
    </message>
    <message>
        <source> Individual - </source>
        <translation>Individual-</translation>
    </message>
    <message>
        <source> Zona - </source>
        <translation>Zona-</translation>
    </message>
    <message>
        <source> - Individual - </source>
        <translation>-Individual-</translation>
    </message>
    <message>
        <source> - Zona - </source>
        <translation>-Zona-</translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation>Aprire videocitofono</translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation>Aumenta illuminazione</translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation>Diminuisci illuminazione</translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation>Alzare dis.motorizzato</translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation>Abbassare dis. motorizzato</translation>
    </message>
    <message>
        <source> - ON/OFF -</source>
        <translation>-ON/OFF-</translation>
    </message>
    <message>
        <source> - Regulable -</source>
        <translation>-Regolabile-</translation>
    </message>
    <message>
        <source> - RGB -</source>
        <translation>-RGB-</translation>
    </message>
    <message>
        <source> - Todos los tipos -</source>
        <translation>-tutti i tipi-</translation>
    </message>
    <message>
        <source> Todas las luces</source>
        <translation>Tutte le luci</translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation>- tutti i climatizzatori</translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation>-Tutti i dispositivi</translation>
    </message>
    <message>
        <source> - Persiana normal -</source>
        <translation>-Persiana normale</translation>
    </message>
    <message>
        <source> - Persiana posicional -</source>
        <translation>-Persiana posizionale</translation>
    </message>
    <message>
        <source> - Persianas agupadas -</source>
        <translation>-Gruppo Persiane</translation>
    </message>
    <message>
        <source> - Cualquier persiana -</source>
        <translation>-Qualunque persiana</translation>
    </message>
    <message>
        <source> - Toldo normal -</source>
        <translation>-Tenda normale</translation>
    </message>
    <message>
        <source> - Toldo posicional -</source>
        <translation>-Tenda posizionale</translation>
    </message>
    <message>
        <source> - Toldos agupados -</source>
        <translation>-Gruppo di tende</translation>
    </message>
    <message>
        <source> - Cualquier toldo -</source>
        <translation>-qualunque tenda</translation>
    </message>
    <message>
        <source> - Cortina normal -</source>
        <translation>Tenda a sipario normale</translation>
    </message>
    <message>
        <source> - Cortina posicional -</source>
        <translation>Tenda a sipario posizionale</translation>
    </message>
    <message>
        <source> - Cortinas agupadas -</source>
        <translation>Gruppo di tende a sipario</translation>
    </message>
    <message>
        <source> - Cualquier cortina -</source>
        <translation>Qualunque tenda a sipario</translation>
    </message>
    <message>
        <source> - Puerta motorizada -</source>
        <translation>Porta motorizzata</translation>
    </message>
    <message>
        <source> Todos</source>
        <translation>Tutti</translation>
    </message>
    <message utf8="true">
        <source>Conmutar cámara</source>
        <translation type="unfinished">Cambia fotocamera</translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Azione</translation>
    </message>
    <message utf8="true">
        <source>Código</source>
        <translation>Codice IR</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialog</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation>Esegui scena</translation>
    </message>
    <message>
        <source>Arm. Intr. Peri.</source>
        <translation type="obsolete">Attiva all.perim.</translation>
    </message>
    <message utf8="true">
        <source>Activar pánico</source>
        <translation>Attiva all. panico</translation>
    </message>
    <message>
        <source>Abrir puerta</source>
        <translation type="obsolete">Apri porta</translation>
    </message>
    <message utf8="true">
        <source>Cambiar cámara</source>
        <translation type="obsolete">Switch camera</translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation>Accendi luce</translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation>Spegni luci</translation>
    </message>
    <message>
        <source>Subir persiana</source>
        <translation type="obsolete">Raise blind</translation>
    </message>
    <message>
        <source>Bajar persiana</source>
        <translation type="obsolete">Lower blind</translation>
    </message>
    <message>
        <source>Encender clima</source>
        <translation type="obsolete">Climate control on</translation>
    </message>
    <message>
        <source>Apagar clima</source>
        <translation type="obsolete">Climate control off</translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation>Accendi dispositivo prese</translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation>Spegnere dispositivi prese</translation>
    </message>
    <message utf8="true">
        <source>Cambiar acción asociada a la tecla</source>
        <translation type="obsolete">Cambia azione associata alla chiave</translation>
    </message>
    <message>
        <source>Luz ON</source>
        <translation type="obsolete">Luce ON</translation>
    </message>
    <message>
        <source>Luz OFF</source>
        <translation type="obsolete">Luce  OFF</translation>
    </message>
    <message>
        <source>Incrementar luz</source>
        <translation type="obsolete">Aumenta luce</translation>
    </message>
    <message>
        <source>Decrementar luz</source>
        <translation type="obsolete">Diminuisci luce</translation>
    </message>
    <message>
        <source>Subir elemento motorizado</source>
        <translation type="obsolete">Alza motore</translation>
    </message>
    <message>
        <source>Bajar elemento motorizado</source>
        <translation type="obsolete">Abbassa motore</translation>
    </message>
    <message>
        <source>Clima ON</source>
        <translation type="obsolete">Clima ON</translation>
    </message>
    <message>
        <source>Clima OFF</source>
        <translation type="obsolete">Clima OFF </translation>
    </message>
    <message>
        <source>Enchufe ON</source>
        <translation type="obsolete">Presa FM ON</translation>
    </message>
    <message>
        <source>Enchufe OFF</source>
        <translation type="obsolete">Presa FM OFF</translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation>Luce ON/OFF</translation>
    </message>
    <message>
        <source>Luz dimeada</source>
        <translation type="obsolete">Dimmer luce</translation>
    </message>
    <message>
        <source>Persiana</source>
        <translation type="obsolete">Tapparella</translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation>persiana veneziana</translation>
    </message>
    <message>
        <source>Toldo</source>
        <translation type="obsolete">Tenda</translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation>Tenda posizionale</translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation>Porta motorizzata</translation>
    </message>
    <message>
        <source>Vivimat</source>
        <translation type="obsolete">Vivimat</translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation>Luce singola</translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation>Luci zona</translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation>Tutte le luci</translation>
    </message>
    <message>
        <source>Elemento individual</source>
        <translation type="obsolete">Apparecchiatura singola</translation>
    </message>
    <message>
        <source>Elementos de la zona</source>
        <translation type="obsolete">Apparecchiature zona</translation>
    </message>
    <message>
        <source>Todos los elementos</source>
        <translation type="obsolete">Tutte le apparecchiature</translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation>Presa FM singola</translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation>Prese FM zona</translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation>Tutte le prese FM</translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation>Arm Antintrusione Perimetrale</translation>
    </message>
    <message>
        <source>Encender Clima</source>
        <translation>Accendi climatizzazione</translation>
    </message>
    <message>
        <source>Apagar Clima</source>
        <translation>Spegni climatizzazione</translation>
    </message>
    <message>
        <source>Luz regulable</source>
        <translation>Luce regolabile</translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation>Persiana normale</translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation>Tenda normale</translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation>Aprire videocitofono</translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation>Aumenta illuminazione</translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation>Diminuisci illuminazione</translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation>Alzare dis.motorizzato</translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation>Abbassare dis. motorizzato</translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation>-Tutti i tipi-</translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation>Climatizzazione singola</translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation>Tutti i climatizzatori</translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation>Gruppo Persiane</translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation>Qualunque persiana</translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation>Gruppo di tende</translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation>Qualunque tenda</translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation>Tenda a sipario normale</translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation>Tenda a sipario posizionale</translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation>Gruppo di tende a sipario</translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation>Qualunque tenda a sipario</translation>
    </message>
    <message>
        <source>Dispositivo individual</source>
        <translation>Dispositivo singolo</translation>
    </message>
    <message>
        <source>Dispositivos de la zona</source>
        <translation>Dispositivi di zona</translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation>Tutti i dispositivi</translation>
    </message>
    <message>
        <source>Conmutar camara</source>
        <translation type="unfinished">Cambia fotocamera</translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message utf8="true">
        <source>Cambiar acción asociada a la tecla</source>
        <translation>Cambia azione associata alla chiave</translation>
    </message>
    <message utf8="true">
        <source>Tipo de acción:</source>
        <translation type="obsolete">Function type:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message utf8="true">
        <source>Acción:</source>
        <translation>Azione:</translation>
    </message>
    <message>
        <source>Tipo:</source>
        <translation type="obsolete">Tipo:</translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation>Tipo di controllo:</translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation>Elemenot:</translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation>Tipo di elemento:</translation>
    </message>
</context>
<context>
    <name>IconChangeDialogClass</name>
    <message>
        <source>IconChangeDialog</source>
        <translation>IconChangeDialog</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Cambiare icona</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
</context>
<context>
    <name>IntercomWindow</name>
    <message>
        <source>Terminal1</source>
        <translation type="obsolete">Terminal1</translation>
    </message>
    <message>
        <source>Terminal2</source>
        <translation type="obsolete">Terminal2</translation>
    </message>
    <message>
        <source>Terminal3</source>
        <translation type="obsolete">Terminal3</translation>
    </message>
    <message>
        <source>Terminal 1</source>
        <translation type="obsolete">Terminal 1</translation>
    </message>
    <message>
        <source>Terminal 2</source>
        <translation type="obsolete">Terminal 2</translation>
    </message>
    <message>
        <source>Terminal 3</source>
        <translation type="obsolete">Terminal 3</translation>
    </message>
    <message>
        <source>NO EXISTEN MÁS TERMINALES</source>
        <translation type="obsolete">NO MORE TERMINAL</translation>
    </message>
    <message>
        <source>DESCONECTADO</source>
        <translation type="obsolete">DISCONNESSO</translation>
    </message>
    <message>
        <source>CONECTADO</source>
        <translation type="obsolete">CONNESSO</translation>
    </message>
</context>
<context>
    <name>IntercomWindowClass</name>
    <message>
        <source>Llamar</source>
        <translation type="obsolete">Chiama</translation>
    </message>
    <message>
        <source>+</source>
        <translation type="obsolete">+</translation>
    </message>
    <message>
        <source>-</source>
        <translation type="obsolete">-</translation>
    </message>
    <message>
        <source>Colgar</source>
        <translation type="obsolete">Termina</translation>
    </message>
    <message>
        <source>Volumen</source>
        <translation type="obsolete">Volume</translation>
    </message>
    <message>
        <source>Terminal 1</source>
        <translation type="obsolete">Terminal 1</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation type="obsolete">Alza Vol.</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation type="obsolete">Abbassa Vol.</translation>
    </message>
</context>
<context>
    <name>InternetWindow</name>
    <message>
        <source>Tiempo</source>
        <translation type="obsolete">Tempo</translation>
    </message>
    <message>
        <source>Noticias</source>
        <translation type="obsolete">Notizie</translation>
    </message>
    <message>
        <source>Bolsa</source>
        <translation type="obsolete">Borsa</translation>
    </message>
    <message>
        <source>Trafico</source>
        <translation type="obsolete">Traffico</translation>
    </message>
</context>
<context>
    <name>InvoiceWindow</name>
    <message>
        <source>Introduzca el año ...</source>
        <translation type="obsolete">Introduce the year</translation>
    </message>
    <message>
        <source>Introduzca el mes ...</source>
        <translation type="obsolete">Introduci mese...</translation>
    </message>
    <message>
        <source>Introduzca el dia ...</source>
        <translation type="obsolete">Introduce the day</translation>
    </message>
    <message utf8="true">
        <source>Introduzca el día ...</source>
        <translation type="obsolete">Introduci giorno...</translation>
    </message>
</context>
<context>
    <name>InvoiceWindowClass</name>
    <message>
        <source>InvoiceWindow</source>
        <translation type="obsolete">Finestra fattura</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="obsolete">Chiudu</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="obsolete">Conferma</translation>
    </message>
    <message>
        <source>Introduzca la fecha de la ultima factura:</source>
        <translation type="obsolete">Introduci data ultima fattura:</translation>
    </message>
    <message utf8="true">
        <source>Año</source>
        <translation type="obsolete">Anno</translation>
    </message>
    <message>
        <source>Mes</source>
        <translation type="obsolete">Mese</translation>
    </message>
    <message>
        <source>Dia</source>
        <translation type="obsolete">Giorno</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
</context>
<context>
    <name>IrrigatorControl</name>
    <message>
        <source>Manual</source>
        <translation>Manuale</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Timer</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Inserisci nuovo nome...</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>En espera</source>
        <translation>In attesa</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Sconosciuto</translation>
    </message>
</context>
<context>
    <name>IrrigatorControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo di funzionamento:</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Programma associato:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rinomina</translation>
    </message>
    <message utf8="true">
        <source>Detener riego en caso de lluvia o suelo ya húmedo</source>
        <translation>Disattiva irrigazione in caso di pioggia o terreno umido</translation>
    </message>
    <message>
        <source>Sensor de humedad asociado:</source>
        <translation>Sensore uminidtà associato:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Tutti</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Cambiare icona</translation>
    </message>
    <message>
        <source>Duracion del riego (minutos):</source>
        <translation>Durata irrigazione (minuti):</translation>
    </message>
</context>
<context>
    <name>KeyReadDialog</name>
    <message>
        <source>- Codigo: </source>
        <translation type="obsolete">-Code:</translation>
    </message>
    <message>
        <source>
- Tipo: </source>
        <translation>
-Tipo:</translation>
    </message>
    <message>
        <source>
- Asignada a: </source>
        <translation>
-Assegnata a:</translation>
    </message>
    <message utf8="true">
        <source>Llave desconocida.
- Código: </source>
        <translation>Chiave sconosciuta
codice :</translation>
    </message>
    <message utf8="true">
        <source>- Código: </source>
        <translation>-Codice:</translation>
    </message>
</context>
<context>
    <name>KeyReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Acerque la llave
para ser leída</source>
        <translation>Avvicina la chiave
per leggerla</translation>
    </message>
    <message>
        <source>Leer llave</source>
        <translation>Leggi chiave</translation>
    </message>
    <message>
        <source>R</source>
        <translation type="obsolete">R</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
</context>
<context>
    <name>KeyRecordDialog</name>
    <message utf8="true">
        <source>El usuario tiene
asociada la llave
con código: </source>
        <translation>L&apos;utente ha
associata una chiave
con codice:</translation>
    </message>
    <message>
        <source>
del tipo: </source>
        <translation type="obsolete">
del tipo:</translation>
    </message>
    <message utf8="true">
        <source>No hay espacio
para grabar más llaves</source>
        <translation>Spazio insufficiente per registrare
nuovo messaggio
</translation>
    </message>
    <message>
        <source>Acerque la llave
para ser grabada</source>
        <translation>Avvicina la chiave
per registrarla</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder
a borrar la llave.
¿Está seguro?</source>
        <translation>la chiave sarà
cancellata
desideri procedere?
</translation>
    </message>
    <message>
        <source>La llave ya ha
sido grabada antes.</source>
        <translation>La chiave è gia
stata registrata.</translation>
    </message>
    <message utf8="true">
        <source>Llave leída.
- Código: </source>
        <translation>Chiave letta
codice:
</translation>
    </message>
</context>
<context>
    <name>KeyRecordDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation></translation>
    </message>
    <message>
        <source>El usuario no tiene
llave asociada</source>
        <translation>L&apos;utente non ha nessuna chiave
associata</translation>
    </message>
    <message>
        <source>Grabar llave</source>
        <translation>Registra chiave</translation>
    </message>
    <message>
        <source>R</source>
        <translation type="obsolete">R</translation>
    </message>
    <message>
        <source>Tipo de llave:</source>
        <translation>Tipo di chiave:</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation>&gt;&gt;</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation>&lt;&lt;</translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation>Salva</translation>
    </message>
    <message>
        <source>Grabar
llave</source>
        <translation>Registra
chiave</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Borrar
llave</source>
        <translation>Cancella
chiave</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
</context>
<context>
    <name>KeyboardClass</name>
    <message>
        <source>Keyboad</source>
        <translation>Tastiera</translation>
    </message>
    <message>
        <source>&gt;&gt;&gt;</source>
        <translation>&gt;&gt;&gt;</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <source>Bloq May</source>
        <translation>Bloc Maiusc</translation>
    </message>
    <message>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>W</source>
        <translation>W</translation>
    </message>
    <message>
        <source>I</source>
        <translation>I</translation>
    </message>
    <message>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>T</source>
        <translation>T</translation>
    </message>
    <message>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message utf8="true">
        <source>Ñ</source>
        <translation>N</translation>
    </message>
    <message>
        <source>J</source>
        <translation>J</translation>
    </message>
    <message>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <source>V</source>
        <translation>v</translation>
    </message>
    <message>
        <source>P</source>
        <translation>p</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>H</source>
        <translation>H</translation>
    </message>
    <message>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <source>Q</source>
        <translation>Q</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>Z</source>
        <translation>Z</translation>
    </message>
    <message>
        <source>K</source>
        <translation>K</translation>
    </message>
    <message>
        <source>O</source>
        <translation>O</translation>
    </message>
    <message>
        <source>G</source>
        <translation>G</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message utf8="true">
        <source>ó</source>
        <translation>ò</translation>
    </message>
    <message utf8="true">
        <source>é</source>
        <translation>é</translation>
    </message>
    <message>
        <source>&apos;</source>
        <translation>&apos;</translation>
    </message>
    <message utf8="true">
        <source>Ó</source>
        <translation>ò</translation>
    </message>
    <message>
        <source>_</source>
        <translation>_</translation>
    </message>
    <message>
        <source>.</source>
        <translation>.</translation>
    </message>
    <message>
        <source>,</source>
        <translation>,</translation>
    </message>
    <message utf8="true">
        <source>É</source>
        <translation>E&apos;</translation>
    </message>
    <message utf8="true">
        <source>á</source>
        <translation>à</translation>
    </message>
    <message>
        <source>@</source>
        <translation>@</translation>
    </message>
    <message utf8="true">
        <source>ú</source>
        <translation>ù</translation>
    </message>
    <message utf8="true">
        <source>Í</source>
        <translation>I</translation>
    </message>
    <message utf8="true">
        <source>Ç</source>
        <translation>ç</translation>
    </message>
    <message utf8="true">
        <source>Ú</source>
        <translation>ù</translation>
    </message>
    <message utf8="true">
        <source>Á</source>
        <translation>A&apos;</translation>
    </message>
    <message utf8="true">
        <source>ç</source>
        <translation>ç</translation>
    </message>
    <message utf8="true">
        <source>í</source>
        <translation>i</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>y</source>
        <translation>y</translation>
    </message>
    <message>
        <source>s</source>
        <translation>s</translation>
    </message>
    <message>
        <source>f</source>
        <translation>f</translation>
    </message>
    <message>
        <source>j</source>
        <translation>j</translation>
    </message>
    <message>
        <source>v</source>
        <translation>v</translation>
    </message>
    <message>
        <source>t</source>
        <translation>t</translation>
    </message>
    <message>
        <source>b</source>
        <translation>b</translation>
    </message>
    <message>
        <source>z</source>
        <translation>z</translation>
    </message>
    <message>
        <source>c</source>
        <translation>c</translation>
    </message>
    <message>
        <source>k</source>
        <translation>k</translation>
    </message>
    <message>
        <source>i</source>
        <translation>i</translation>
    </message>
    <message utf8="true">
        <source>ñ</source>
        <translation>n</translation>
    </message>
    <message>
        <source>r</source>
        <translation>r</translation>
    </message>
    <message>
        <source>g</source>
        <translation>g</translation>
    </message>
    <message>
        <source>w</source>
        <translation>w</translation>
    </message>
    <message>
        <source>a</source>
        <translation>a</translation>
    </message>
    <message>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <source>p</source>
        <translation>P</translation>
    </message>
    <message>
        <source>l</source>
        <translation>l</translation>
    </message>
    <message>
        <source>m</source>
        <translation>m</translation>
    </message>
    <message>
        <source>n</source>
        <translation>n</translation>
    </message>
    <message>
        <source>h</source>
        <translation>h</translation>
    </message>
    <message>
        <source>u</source>
        <translation>u</translation>
    </message>
    <message>
        <source>d</source>
        <translation>d</translation>
    </message>
    <message>
        <source>q</source>
        <translation>q</translation>
    </message>
    <message>
        <source>o</source>
        <translation>o</translation>
    </message>
    <message>
        <source>e</source>
        <translation>e</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>*</source>
        <translation>*</translation>
    </message>
    <message>
        <source>#</source>
        <translation>#</translation>
    </message>
    <message utf8="true">
        <source>ş</source>
        <translation>s</translation>
    </message>
    <message utf8="true">
        <source>ö</source>
        <translation>O</translation>
    </message>
    <message utf8="true">
        <source>ü</source>
        <translation>ù</translation>
    </message>
    <message utf8="true">
        <source>ǧ</source>
        <translation>g</translation>
    </message>
    <message utf8="true">
        <source>ف</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ى</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ح</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ه</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ا</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ع</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>خ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ي</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>م</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ة</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ض</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ب</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ص</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ت</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ث</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>و</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ش</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ق</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>لا</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ؤ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>س</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ن</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>غ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ك</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ل</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ر</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ئ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ء</source>
        <translation>&quot;</translation>
    </message>
    <message utf8="true">
        <source>ظ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ز</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>د</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ج</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ط</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٨</source>
        <translation>٨</translation>
    </message>
    <message utf8="true">
        <source>٤</source>
        <translation>٤</translation>
    </message>
    <message utf8="true">
        <source>٣</source>
        <translation>٣</translation>
    </message>
    <message utf8="true">
        <source>٧</source>
        <translation>٧</translation>
    </message>
    <message utf8="true">
        <source>ذ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>١</source>
        <translation>١</translation>
    </message>
    <message utf8="true">
        <source>٢</source>
        <translation>٢</translation>
    </message>
    <message utf8="true">
        <source>٩</source>
        <translation>٩</translation>
    </message>
    <message utf8="true">
        <source>٦</source>
        <translation>٦</translation>
    </message>
    <message utf8="true">
        <source>٥</source>
        <translation>٥</translation>
    </message>
</context>
<context>
    <name>LicenseSystem</name>
    <message>
        <source>Introduzca licencia...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>La licencia caducará en %1 días. 
Para poder seguir usando el sistema Vivimat III deberá llamar a su instalador para que le proporcione una licencia 
 válida. Deberá indicarle el número de licencia que aparece a continuación para poder activar el sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Número de licencia:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licencia....</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LightControl</name>
    <message>
        <source>Manual</source>
        <translation>Manuale</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Timer</translation>
    </message>
    <message>
        <source>Presencia</source>
        <translation>Presenza</translation>
    </message>
    <message>
        <source>Crepuscular</source>
        <translation>Crepuscolare</translation>
    </message>
    <message>
        <source>Pres + Crep</source>
        <translation type="obsolete">Pres +Crep</translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="obsolete">ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="obsolete">OFF</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Inserisci nuovo nome...</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Stato sconosciuto</translation>
    </message>
    <message>
        <source>Crep + Pres</source>
        <translation>Crep + Pres</translation>
    </message>
    <message>
        <source>Pres + Prog</source>
        <translation>Pres +Crep</translation>
    </message>
</context>
<context>
    <name>LightControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Timer associato:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <source>Consigna en modo programa:</source>
        <translation type="obsolete">Livello in modalità timer:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo di funzionamento:</translation>
    </message>
    <message>
        <source>%</source>
        <translation></translation>
    </message>
    <message>
        <source>Sensor de presencia asociado:</source>
        <translation>Sensore presenza associato:</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la desactivación:</source>
        <translation>Ritardo allo spegnimento:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Disposit.</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zona</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Tutte</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Consigna en modo presencia:</source>
        <translation>Abilità modalità presenza:</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Cambiare icona</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>inicio</source>
        <translation>inizio</translation>
    </message>
    <message>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation>Videocitofono</translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation>Sicurezza</translation>
    </message>
    <message>
        <source>escenas</source>
        <translation>Scenari</translation>
    </message>
    <message>
        <source>mensajes</source>
        <translation>Messaggi</translation>
    </message>
    <message>
        <source>configuración</source>
        <translation type="obsolete">Configuration</translation>
    </message>
    <message>
        <source>telefono</source>
        <translation type="obsolete">Telephone</translation>
    </message>
    <message>
        <source>audio/vídeo</source>
        <translation type="obsolete">A/V</translation>
    </message>
    <message>
        <source>clima</source>
        <translation>Climate</translation>
    </message>
    <message>
        <source>consumos</source>
        <translation type="obsolete">Consumi</translation>
    </message>
    <message utf8="true">
        <source>cámaras</source>
        <translation>Telecamere</translation>
    </message>
    <message>
        <source>internet</source>
        <translation type="obsolete">Internet</translation>
    </message>
    <message>
        <source>programas</source>
        <translation>Timer</translation>
    </message>
    <message>
        <source>intercom.</source>
        <translation type="obsolete">Intercom.</translation>
    </message>
    <message>
        <source>alarmas</source>
        <translation>Allarmi</translation>
    </message>
    <message>
        <source>historial</source>
        <translation>Cronologia</translation>
    </message>
    <message>
        <source>fotos</source>
        <translation>Foto</translation>
    </message>
    <message>
        <source>barómetro</source>
        <translation type="obsolete">Baromether</translation>
    </message>
    <message>
        <source>pizarra</source>
        <translation>Lavagna</translation>
    </message>
    <message>
        <source>sos</source>
        <translation>SOS</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>teléfono</source>
        <translation type="obsolete">Telefono</translation>
    </message>
    <message>
        <source>LUN </source>
        <translation>LUN </translation>
    </message>
    <message>
        <source>MAR </source>
        <translation>MAR </translation>
    </message>
    <message>
        <source>MIE </source>
        <translation>MER </translation>
    </message>
    <message>
        <source>JUE </source>
        <translation>GIO </translation>
    </message>
    <message>
        <source>VIE </source>
        <translation>VEN </translation>
    </message>
    <message>
        <source>SAB </source>
        <translation>SAB </translation>
    </message>
    <message>
        <source>DOM </source>
        <translation>DOM </translation>
    </message>
    <message>
        <source>dd/MM/yyyy</source>
        <translation>dd/MM/yyyy</translation>
    </message>
    <message>
        <source>INT </source>
        <translation type="obsolete">INT</translation>
    </message>
    <message utf8="true">
        <source> ºC</source>
        <translation type="obsolete">ºC</translation>
    </message>
    <message utf8="true">
        <source>Los ficheros de configuración no coinciden.
Para sobreescribir los ficheros de la central en la pantalla
pulsa Aceptar. En caso contrario, pulsa Cancelar.</source>
        <translation type="obsolete">I files di configurazione sono diversi.
Per sovrascrivere i files della centrale nel display
clicca Conferma. In caso contrario, Cancella.</translation>
    </message>
    <message utf8="true">
        <source>Actualizar configuración</source>
        <translation>Aggiorna configurazione</translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código IR:
%1
%2
%3</source>
        <translation type="obsolete">Codice IR letto al:
%1
%2
%3</translation>
    </message>
    <message utf8="true">
        <source>Código IR leido</source>
        <translation type="obsolete">Codice IR letto</translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código RF:
%1
%2
%3
%4</source>
        <translation type="obsolete">Chiave letta al:
%1
%2
%3
%4</translation>
    </message>
    <message>
        <source>Llave leida</source>
        <translation type="obsolete">Chiave letta</translation>
    </message>
    <message utf8="true">
        <source>INT %1 ºC</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código IR:
%1 %2 %3</source>
        <translation>Codice IR letto al:
%1 %2 %3</translation>
    </message>
    <message utf8="true">
        <source>Código IR leído</source>
        <translation>Codice IR letto</translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código RFID:
%1 %2 %3 %4</source>
        <translation>ChiaveRFID  letta al:
%1 %2 %3 %4</translation>
    </message>
    <message utf8="true">
        <source>Llave leída</source>
        <translation>Chiave letta</translation>
    </message>
    <message utf8="true">
        <source>Cerrar sesión</source>
        <translation>Chiudere la sessione</translation>
    </message>
    <message>
        <source>configurar</source>
        <translation>Configurare</translation>
    </message>
    <message utf8="true">
        <source>No es posible visualizar las cámaras porque ya están siendo visualizadas en otro terminal.</source>
        <translation>Non è possibile visualizzare la telecamera, è visualizzata da un altro terminale.</translation>
    </message>
    <message utf8="true">
        <source>Cámaras ocupadas</source>
        <translation>Telecamera occupata</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar</source>
        <translation>Introduca password per disattivare</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para menú de seguridad</source>
        <translation>Introduca password per accedere al menu sicurezza</translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 30 segundos.</source>
        <translation type="obsolete">Sistema bloccato da tre tentativi errati di introduzione password.
Per introdurre nuovamente la password aspettare 30 secondi.</translation>
    </message>
    <message>
        <source>Sistema bloqueado</source>
        <translation>Sistema bloccato</translation>
    </message>
    <message>
        <source>Antes de poder usar los mensajes de voz es necesario tener grabados los mensajes personales.</source>
        <translation>Prima di poter usare un messaggio vocale  è necessario registrare un messaggio personale.</translation>
    </message>
    <message>
        <source>Mensajes personales sin grabar</source>
        <translation>Messaggio personale non registrato</translation>
    </message>
    <message utf8="true">
        <source>Los ficheros de configuración no coinciden.
Para sobreescribir los ficheros de la central en la pantalla pulsa Aceptar. En caso contrario, pulsa Cancelar.</source>
        <translation>I file di configurazione coincidono
Per sovrascrivere i file della centrale nell touchscreen premere Acceta. In caso contrario , premere Cancella.</translation>
    </message>
    <message utf8="true">
        <source>El idioma del sistema ha sido modificado.
¿Desea reiniciar la pantalla?</source>
        <translation>Vocabolario del sistema è stato modificato.
Reiniziallizare il Touchscreen?</translation>
    </message>
    <message>
        <source>Actualizar idioma...</source>
        <translation>Aggiornare il vocabolario...</translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 90 segundos.</source>
        <translation>Sistema bloccato da tre tentativi errati di introduzione password.
Per introdurre nuovamente la password aspettare 90 secondi.</translation>
    </message>
</context>
<context>
    <name>MainWindowClass</name>
    <message>
        <source>MAR 03/02/2009</source>
        <translation type="obsolete">TUE 03/02/2009</translation>
    </message>
    <message>
        <source>12:30</source>
        <translation>12:30</translation>
    </message>
    <message>
        <source>MAR 15/11/2009</source>
        <translation>MAR 15/11/2009</translation>
    </message>
    <message utf8="true">
        <source>INT 18ºC</source>
        <translation>INT 18ºC</translation>
    </message>
    <message>
        <source>MainWindow</source>
        <translation>Schermata  principale</translation>
    </message>
    <message>
        <source>T</source>
        <translation type="obsolete">T</translation>
    </message>
    <message>
        <source>LL</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>MessageDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Conferma</translation>
    </message>
</context>
<context>
    <name>MessagesWindow</name>
    <message>
        <source>Tipo</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Origen</source>
        <translation>Origine</translation>
    </message>
    <message>
        <source>Fecha/Hora</source>
        <translation>Data/ora</translation>
    </message>
    <message>
        <source>Voz</source>
        <translation>Voce</translation>
    </message>
    <message>
        <source>Desconocido</source>
        <translation>Sconbosciuto</translation>
    </message>
    <message>
        <source>Videoportero</source>
        <translation>Videocitofono</translation>
    </message>
    <message>
        <source>Terminal 1</source>
        <translation>Display 1</translation>
    </message>
    <message>
        <source>Terminal 2</source>
        <translation>Display 2</translation>
    </message>
    <message>
        <source>Terminal 3</source>
        <translation>Display 3</translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation>Registrazione in corso...</translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation>Riproduzione in corso...</translation>
    </message>
    <message>
        <source>Se va a eliminar el mensaje.
¿Está seguro?</source>
        <translation type="obsolete">Message is about to be deleted.
do you wish to proceed?</translation>
    </message>
    <message>
        <source>Eliminar mensaje...</source>
        <translation type="obsolete">Elimina messaggio...</translation>
    </message>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>Non è possibile registrare il messaggio, il messaggiovocale è in uso.</translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation>Messaggio vocale in uso</translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>Non è possibile riprodurre il messaggio. Il messaggio vocale è in uso.</translation>
    </message>
    <message utf8="true">
        <source>No es posible borrar los mensajes, los mensajes de voz ya están siendo usados.</source>
        <translation>Non è possibile cancellare il messaggio, il messaggio vocale è in uso.</translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation>Eliminare tutti i messaggi
sei sicuro ?</translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation>Elimina messaggio...</translation>
    </message>
</context>
<context>
    <name>MessagesWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Grabar
mensaje</source>
        <translation>Registra
messaggio</translation>
    </message>
    <message>
        <source>Borrar
mensajes</source>
        <translation>canacellare
messaggi</translation>
    </message>
</context>
<context>
    <name>MsgProgressDialogClass</name>
    <message>
        <source>RecWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Parar</source>
        <translation>Stop</translation>
    </message>
</context>
<context>
    <name>MsgProgressWindowClass</name>
    <message>
        <source>Parar</source>
        <translation type="obsolete">Stop</translation>
    </message>
</context>
<context>
    <name>PasswordClass</name>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>Introduzca clave de acceso</source>
        <translation type="obsolete">Inserisci codice accesso</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para continuar...</source>
        <translation>Introduci password per continuare...</translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialog</name>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>Non è possibile registrare il messaggio, il messaggiovocale è in uso.</translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation>Messaggio vocale in uso</translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation>Eliminare tutti i messaggi
sei sicuro ?</translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation>Elimina messaggio...</translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation>Registra messaggio...</translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>Non è possibile riprodurre il messaggio. Il messaggio vocale è in uso.</translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation>Riproduci Messaggio...</translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation>ConfirmationWindow</translation>
    </message>
    <message>
        <source>Mensajes de voz personalizados</source>
        <translation>Personalizzazione messaggi vocali</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Mensaje para llamadas de alarma</source>
        <translation>messaggio per chiamata di allarme</translation>
    </message>
    <message>
        <source>Reproducir</source>
        <translation>Riproduci</translation>
    </message>
    <message>
        <source>Grabar</source>
        <translation>Registra</translation>
    </message>
    <message>
        <source>Mensaje para contestador de videoportero</source>
        <translation>Messaggio per il risponditore del videocitofono</translation>
    </message>
    <message utf8="true">
        <source>Para grabar los mensajes de voz personalizados primero se borraran todos los mensajes, después se grabará el mensaje para llamadas de alarma y a continuación el mensaje para contestador de videoportero.</source>
        <translation>per registrare i messaggi vocali personalizzati prima cancellare tutti i messaggi, quindi registrare il messaggio per la chiamata di allarme, poi per il risponditore del videocitofono.</translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindow</name>
    <message>
        <source>Tipo</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Numero</source>
        <translation type="obsolete">Number</translation>
    </message>
    <message>
        <source>CRA</source>
        <translation>ARC</translation>
    </message>
    <message>
        <source>SMS</source>
        <translation>SMS</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>TEL</source>
        <translation>TEL</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Introduci nuovo nome...</translation>
    </message>
    <message>
        <source>Introduzca nuevo numero o direccion de correo ...</source>
        <translation type="obsolete">Introduce new number or e-mail address ...</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el contacto.
¿Está seguro?</source>
        <translation>Cancellare il contatto
Vuoi procedere ?
</translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation>Elimina contatto...</translation>
    </message>
    <message utf8="true">
        <source>Número</source>
        <translation>Numero</translation>
    </message>
    <message>
        <source>Es necesario introducir primero el tipo de contacto.</source>
        <translation>Introdurre prima il tipo di contatto.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Errore...</translation>
    </message>
    <message utf8="true">
        <source>Introduzca nuevo número o dirección de correo ...</source>
        <translation>Introdurre nuvo numero o indirizzo mail ...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Completa i dati mancanti.</translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindowClass</name>
    <message>
        <source>PhoneConfigWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Habilitar avisos</source>
        <translation>Abilitare comunicazioni</translation>
    </message>
    <message>
        <source>Habilitar telecontrol</source>
        <translation>Abilitare il telecontrollo</translation>
    </message>
    <message>
        <source>Tonos</source>
        <translation>Toni</translation>
    </message>
    <message>
        <source>Configurar
CRA</source>
        <translation>Configurare
CRA</translation>
    </message>
</context>
<context>
    <name>PhoneWindow</name>
    <message>
        <source>Llamando...</source>
        <translation type="obsolete">Calling ...</translation>
    </message>
    <message>
        <source>LLAMANDO...</source>
        <translation type="obsolete">CHIAMATA IN CORSO...</translation>
    </message>
    <message>
        <source>COLGADO</source>
        <translation type="obsolete">CHIAMATA TERMINATA</translation>
    </message>
</context>
<context>
    <name>PhoneWindowClass</name>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <source>2</source>
        <translation type="obsolete">2</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="obsolete">3</translation>
    </message>
    <message>
        <source>4</source>
        <translation type="obsolete">4</translation>
    </message>
    <message>
        <source>5</source>
        <translation type="obsolete">5</translation>
    </message>
    <message>
        <source>6</source>
        <translation type="obsolete">6</translation>
    </message>
    <message>
        <source>7</source>
        <translation type="obsolete">7</translation>
    </message>
    <message>
        <source>8</source>
        <translation type="obsolete">8</translation>
    </message>
    <message>
        <source>9</source>
        <translation type="obsolete">9</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>*</source>
        <translation type="obsolete">*</translation>
    </message>
    <message>
        <source>#</source>
        <translation type="obsolete">#</translation>
    </message>
    <message>
        <source>Llamar</source>
        <translation type="obsolete">Chiama</translation>
    </message>
    <message>
        <source>Colgar</source>
        <translation type="obsolete">Termina</translation>
    </message>
    <message>
        <source>B</source>
        <translation type="obsolete">Erase</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation type="obsolete">Cancella</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation type="obsolete">Abbassa Vol.</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation type="obsolete">Alza Vol.</translation>
    </message>
</context>
<context>
    <name>PhotosWindow</name>
    <message>
        <source>Marco de fotos</source>
        <translation>Cornice fotografica</translation>
    </message>
    <message>
        <source>No hay fotos disponibles.</source>
        <translation>Nessuna foto disponibile.</translation>
    </message>
    <message>
        <source>Reducir la resolucion de la imagen para su correcta visualizacion.</source>
        <translation type="obsolete">Ridurre la risoluzione dell&apos;immagine per la visualizzazione delle immagini.</translation>
    </message>
    <message>
        <source>No se puede mostrar la foto (%1).</source>
        <translation type="unfinished">Impossibile visualizzare foto (%1).</translation>
    </message>
</context>
<context>
    <name>PhotosWindowClass</name>
    <message>
        <source>Marco de fotos</source>
        <translation type="obsolete">Picture frame</translation>
    </message>
</context>
<context>
    <name>PlugControl</name>
    <message>
        <source>Manual</source>
        <translation>Manuale</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Timer</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Inserisci nuovo nome...</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Sconosciuto</translation>
    </message>
</context>
<context>
    <name>PlugControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo di funzionamento:</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Timer associato:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Tutti</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Cambiare icona</translation>
    </message>
    <message>
        <source>salida temporizada </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>segundos</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindow</name>
    <message>
        <source>24 Franjas</source>
        <translation type="obsolete">24 fasce</translation>
    </message>
    <message>
        <source>5 Franjas</source>
        <translation type="obsolete">5 fasce</translation>
    </message>
    <message>
        <source>Temperatura</source>
        <translation>Temperatura</translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation>0-100%</translation>
    </message>
    <message>
        <source>ON-OFF</source>
        <translation>ON-OFF</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Inserisci nuovo nome...</translation>
    </message>
    <message>
        <source>%1:00</source>
        <translation type="obsolete">%1:00</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation type="obsolete">%1ºC</translation>
    </message>
    <message>
        <source>100%</source>
        <translation type="obsolete">100%</translation>
    </message>
    <message>
        <source>0%</source>
        <translation type="obsolete">0%</translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="obsolete">ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="obsolete">OFF</translation>
    </message>
    <message>
        <source>%1%</source>
        <translation type="obsolete">%1%</translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>0 = OFF</source>
        <translation>0 = OFF</translation>
    </message>
    <message>
        <source>1 = ON</source>
        <translation>1 = OFF</translation>
    </message>
    <message utf8="true">
        <source>Las franjas horarias no están bien definidas.</source>
        <translation>Le fasce orarie non sono definite.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Errore...</translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Maschera</translation>
    </message>
    <message>
        <source>Modo</source>
        <translation type="obsolete">Modalità</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Franja 1:</source>
        <translation>Fascia 1:</translation>
    </message>
    <message>
        <source>Franja 2:</source>
        <translation>Fascia 2:</translation>
    </message>
    <message>
        <source>Franja 3:</source>
        <translation>Fascia 3:</translation>
    </message>
    <message>
        <source>Franja 4:</source>
        <translation>Fascia 4:</translation>
    </message>
    <message>
        <source>Franja 5:</source>
        <translation>Fascia 5:</translation>
    </message>
    <message>
        <source>Inicio</source>
        <translation>Inizio</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:mm</translation>
    </message>
    <message>
        <source>Fin</source>
        <translation>Fine</translation>
    </message>
    <message utf8="true">
        <source>20ºC</source>
        <translation type="obsolete">20ºC</translation>
    </message>
    <message>
        <source>+</source>
        <translation type="obsolete">+</translation>
    </message>
    <message>
        <source>-</source>
        <translation type="obsolete">-</translation>
    </message>
    <message>
        <source>00:00</source>
        <translation type="obsolete">00:00</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message utf8="true">
        <source>Días de ejecución:</source>
        <translation>Giorni attivi:</translation>
    </message>
    <message>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <source>X</source>
        <translation>M</translation>
    </message>
    <message>
        <source>J</source>
        <translation>G</translation>
    </message>
    <message>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <source>QToolButton{
border: 2px inset palette(dark);
background-color: rgba(255,255,255,0);
}</source>
        <translation type="obsolete">QToolButton{border: 2px inset palette(dark);background-color: rgba(255,255,255,0);}</translation>
    </message>
    <message>
        <source>Consigna</source>
        <translation>Set point</translation>
    </message>
</context>
<context>
    <name>ProgramsWindow</name>
    <message>
        <source>24 Franjas</source>
        <translation type="obsolete">24 slots</translation>
    </message>
    <message>
        <source>Temperatura</source>
        <translation>Temperatura</translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation>0-100%</translation>
    </message>
    <message>
        <source>ON/OFF</source>
        <translation>ON-OFF</translation>
    </message>
    <message>
        <source>5 Franjas</source>
        <translation type="obsolete">5 slots</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Modo</source>
        <translation type="obsolete">Mode</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <source>X</source>
        <translation>Me</translation>
    </message>
    <message>
        <source>J</source>
        <translation>J</translation>
    </message>
    <message>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>--</source>
        <translation type="obsolete">--</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el programa.
¿Está seguro?</source>
        <translation>Il programma sarà eliminato
vuoi continuare?</translation>
    </message>
    <message>
        <source>Eliminar programa...</source>
        <translation>Eliminare il programma...</translation>
    </message>
</context>
<context>
    <name>ProgramsWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Modo</source>
        <translation type="obsolete">Modalità</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <source>X</source>
        <translation>M</translation>
    </message>
    <message>
        <source>J</source>
        <translation>G</translation>
    </message>
    <message>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>D</source>
        <translation>SU</translation>
    </message>
    <message>
        <source>Modificar</source>
        <translation type="obsolete">Modify</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation type="obsolete">Erase</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
</context>
<context>
    <name>RBlindControl</name>
    <message>
        <source>Manual</source>
        <translation>Manuale</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Timer</translation>
    </message>
    <message>
        <source>Desplegado</source>
        <translation type="obsolete">Aperte</translation>
    </message>
    <message>
        <source>Plegado</source>
        <translation type="obsolete">Chiuse</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Inserisci nuovo nome...</translation>
    </message>
    <message>
        <source>Arriba</source>
        <translation type="obsolete">Su</translation>
    </message>
    <message>
        <source>Abajo</source>
        <translation type="obsolete">Giù</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Stato sconosciuto</translation>
    </message>
    <message>
        <source>Grupo de toldos</source>
        <translation>Gruppo di tende</translation>
    </message>
</context>
<context>
    <name>RBlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Timer associato:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <source>Plegar toldos en caso de viento fuerte</source>
        <translation>Chiudi le tende in caso di vento forte</translation>
    </message>
    <message>
        <source>Consigna en modo programa:</source>
        <translation type="obsolete">Livello in modalità timer:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Modo di funzionamento:</translation>
    </message>
    <message>
        <source>%</source>
        <translation type="obsolete">%</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zona</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Disposit.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>Tutte</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Tempo di salita/discesa:</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Cambiare icona</translation>
    </message>
    <message>
        <source>Plegar toldos en caso de lluvia</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SOSWindow</name>
    <message utf8="true">
        <source>PÁNICO ACTIVADO</source>
        <translation type="obsolete">ALLARME PANICO ATTIVATO</translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico deshabilitada</source>
        <translation>Allarme antipanico disabilitato</translation>
    </message>
</context>
<context>
    <name>SOSWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>SOS</source>
        <translation>SOS</translation>
    </message>
    <message>
        <source>STOP</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneConditionDialog</name>
    <message>
        <source>Sin condicionar</source>
        <translation>Senza condizione</translation>
    </message>
    <message>
        <source>A</source>
        <translation type="obsolete">A</translation>
    </message>
    <message>
        <source>B</source>
        <translation type="obsolete">B</translation>
    </message>
    <message>
        <source>C</source>
        <translation type="obsolete">C</translation>
    </message>
    <message>
        <source>D</source>
        <translation type="obsolete">D</translation>
    </message>
    <message>
        <source>E</source>
        <translation type="obsolete">E</translation>
    </message>
    <message>
        <source>F</source>
        <translation type="obsolete">F</translation>
    </message>
    <message utf8="true">
        <source>Día semana</source>
        <translation>Giorno della settimana</translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation>Data</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión Armada</source>
        <translation type="obsolete">Allarme antintrusione Attivato</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión Desarmada</source>
        <translation type="obsolete">Allarme antintrusione Disattivato</translation>
    </message>
    <message utf8="true">
        <source>Activación de cualquier alarma</source>
        <translation>Qualsiasi allarme attivato</translation>
    </message>
    <message utf8="true">
        <source>Parámetros erroneos.
</source>
        <translation type="obsolete">Parametri errati.
</translation>
    </message>
    <message utf8="true">
        <source>Parámetros erroneos...</source>
        <translation type="obsolete">Parametri errati...</translation>
    </message>
    <message>
        <source>Cualquier llave</source>
        <translation>Qualunque chiave</translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="obsolete">ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="obsolete">OFF</translation>
    </message>
    <message>
        <source>Llave tipo A</source>
        <translation>Chiave tipo A</translation>
    </message>
    <message>
        <source>Llave tipo B</source>
        <translation>chiave tipo B</translation>
    </message>
    <message>
        <source>Llave tipo C</source>
        <translation>Chiave tipo C</translation>
    </message>
    <message>
        <source>Llave tipo D</source>
        <translation>chiave tipo D</translation>
    </message>
    <message>
        <source>Llave tipo E</source>
        <translation>Chiave tipo E</translation>
    </message>
    <message>
        <source>Llave tipo F</source>
        <translation>Chiave tipo F</translation>
    </message>
    <message>
        <source>Llave: </source>
        <translation>Chiave:</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión armada</source>
        <translation>Allarme antintrusione armato</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión desarmada</source>
        <translation>allarme antintrusione disarmato</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de intrusión</source>
        <translation>Att.All antintrusione</translation>
    </message>
    <message>
        <source>Act. alm. de fuego</source>
        <translation>Att. All incendio</translation>
    </message>
    <message>
        <source>Act. alm. de gas</source>
        <translation>Att all gas</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de inundación</source>
        <translation>Att.all allagamento</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de corte eléc.</source>
        <translation>Att.all tensione elett.</translation>
    </message>
    <message>
        <source>Act. alm. de corte tlf.</source>
        <translation>Att.all linee tel.</translation>
    </message>
    <message>
        <source>Act. alm. de sistema</source>
        <translation>Att.all sistema</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. médica</source>
        <translation>Att. all medico</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de pánico</source>
        <translation>Att all panico</translation>
    </message>
    <message>
        <source>Act. alm. silenciosa</source>
        <translation>Att. all silenzioso</translation>
    </message>
    <message>
        <source>Act. alm. de sabotaje</source>
        <translation>Att all sabotaggio</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de coacción</source>
        <translation>Att. all coerczione</translation>
    </message>
    <message>
        <source>Entrada en Central</source>
        <translation>Entrata en Central</translation>
    </message>
    <message>
        <source>Entrada en MOD0035</source>
        <translation>Entrada en MOD0035</translation>
    </message>
    <message>
        <source>Intrusion en armado total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Intrusion en armado perimetral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Intrusion en armado parcial</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneConditionDialogClass</name>
    <message>
        <source>EventConditionWindow</source>
        <translation>EventConditionWindow</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Condiciones</source>
        <translation>Condizioni</translation>
    </message>
    <message>
        <source>Llave:</source>
        <translation type="obsolete">Chiave:</translation>
    </message>
    <message>
        <source>Hora:</source>
        <translation type="obsolete">Ora:</translation>
    </message>
    <message>
        <source>Fecha / Dia semana</source>
        <translation type="obsolete">Data/giorno</translation>
    </message>
    <message>
        <source>Condicion de alarma</source>
        <translation type="obsolete">Condizione di allarme</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:mm</translation>
    </message>
    <message>
        <source>Condicion de entrada</source>
        <translation type="obsolete">Condizioni Input</translation>
    </message>
    <message>
        <source>Tipo de modulo</source>
        <translation type="obsolete">Tipo di modulo</translation>
    </message>
    <message>
        <source>E/S</source>
        <translation type="obsolete">I/O</translation>
    </message>
    <message>
        <source>Mes</source>
        <translation type="obsolete">Mese</translation>
    </message>
    <message utf8="true">
        <source>Año</source>
        <translation type="obsolete">Anno</translation>
    </message>
    <message>
        <source>Dia</source>
        <translation type="obsolete">Giorno</translation>
    </message>
    <message>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <source>X</source>
        <translation>M</translation>
    </message>
    <message>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <source>J</source>
        <translation>G</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Condicion de llave:</source>
        <translation>Condizione della chiave:</translation>
    </message>
    <message>
        <source>Condicion de hora:</source>
        <translation>Condizione dell&apos;ora:</translation>
    </message>
    <message>
        <source>Condicion de Fecha / Dia semana:</source>
        <translation>Condizione data/ Giorno Settimana:</translation>
    </message>
    <message>
        <source>Condicion de entrada:</source>
        <translation>Condizione di entrata:</translation>
    </message>
    <message>
        <source>Tipo de modulo:</source>
        <translation>Tipo di modulo:</translation>
    </message>
    <message>
        <source>E/S:</source>
        <translation>I/O:</translation>
    </message>
    <message>
        <source>Condicion de alarma:</source>
        <translation>Condizione di allarme:</translation>
    </message>
    <message>
        <source>Mod:</source>
        <translation>Mod:</translation>
    </message>
</context>
<context>
    <name>SceneConditionWindow</name>
    <message>
        <source>Dia semana</source>
        <translation type="obsolete">Week day</translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation type="obsolete">Date</translation>
    </message>
    <message>
        <source>Alarma de intrusion Armada</source>
        <translation type="obsolete">Intrusion alarm armed</translation>
    </message>
    <message>
        <source>Alarma de intrusion Desarmada</source>
        <translation type="obsolete">Intrusion alarm disarmed</translation>
    </message>
    <message>
        <source>Activacion de cualquier alarma</source>
        <translation type="obsolete">Activate any alarm</translation>
    </message>
    <message>
        <source>Sin condicionar</source>
        <translation type="obsolete">No conditioned</translation>
    </message>
</context>
<context>
    <name>SceneConditionWindowClass</name>
    <message>
        <source>Condiciones</source>
        <translation type="obsolete">Conditions</translation>
    </message>
    <message>
        <source>Llave:</source>
        <translation type="obsolete">Key:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="obsolete">Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="obsolete">Close</translation>
    </message>
    <message>
        <source>Hora:</source>
        <translation type="obsolete">Time:</translation>
    </message>
    <message>
        <source>Fecha / Dia semana</source>
        <translation type="obsolete">Dte/Week day</translation>
    </message>
    <message>
        <source>Condicion de alarma</source>
        <translation type="obsolete">Alarm condition</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation type="obsolete">H:mm</translation>
    </message>
    <message>
        <source>Condicion de entrada</source>
        <translation type="obsolete">Input condition</translation>
    </message>
    <message>
        <source>Tipo de modulo</source>
        <translation type="obsolete">Module type</translation>
    </message>
    <message>
        <source>Logica E/S</source>
        <translation type="obsolete">I/O</translation>
    </message>
    <message>
        <source>Mes</source>
        <translation type="obsolete">Month</translation>
    </message>
    <message utf8="true">
        <source>Año</source>
        <translation type="obsolete">Year</translation>
    </message>
    <message>
        <source>Dia</source>
        <translation type="obsolete">Day</translation>
    </message>
    <message>
        <source>L</source>
        <translation type="obsolete">M</translation>
    </message>
    <message>
        <source>V</source>
        <translation type="obsolete">F</translation>
    </message>
    <message>
        <source>X</source>
        <translation type="obsolete">M</translation>
    </message>
    <message>
        <source>D</source>
        <translation type="obsolete">SU</translation>
    </message>
    <message>
        <source>M</source>
        <translation type="obsolete">T</translation>
    </message>
    <message>
        <source>J</source>
        <translation type="obsolete">TH</translation>
    </message>
    <message>
        <source>S</source>
        <translation type="obsolete">S</translation>
    </message>
    <message>
        <source>E/S</source>
        <translation type="obsolete">I/O</translation>
    </message>
</context>
<context>
    <name>SceneEventWindow</name>
    <message>
        <source>Iluminacion</source>
        <translation type="obsolete">Lighting</translation>
    </message>
    <message>
        <source>Elementos motorizados</source>
        <translation type="obsolete">Motorizzazioni</translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation>Prese FM</translation>
    </message>
    <message>
        <source>Climatizacion</source>
        <translation type="obsolete">Climate control</translation>
    </message>
    <message>
        <source>Riego</source>
        <translation>Irrigazione</translation>
    </message>
    <message>
        <source>Retardo</source>
        <translation>Ritardo</translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation>Sicurezza</translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation>Luce singola</translation>
    </message>
    <message>
        <source>Grupo de luces</source>
        <translation type="obsolete">Gruppo di luci</translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation>Tutte le luci</translation>
    </message>
    <message>
        <source>Opening individual</source>
        <translation type="obsolete">Apertura singola</translation>
    </message>
    <message>
        <source>Grupo de openings</source>
        <translation type="obsolete">Gruppo di aperture</translation>
    </message>
    <message>
        <source>Todos los openings</source>
        <translation type="obsolete">Tutte le aperture</translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation>Presa FM singola</translation>
    </message>
    <message>
        <source>Grupo de enchufes</source>
        <translation type="obsolete">Gruppo di prese</translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation>Tutte le prese FM</translation>
    </message>
    <message>
        <source>Riego individual</source>
        <translation>Zona irrigaznione singola</translation>
    </message>
    <message>
        <source>Grupo de riegos</source>
        <translation type="obsolete">Gruppo zone irrigazione</translation>
    </message>
    <message>
        <source>Todos los riegos</source>
        <translation>Tutte gli irrigatori</translation>
    </message>
    <message>
        <source>200 ms</source>
        <translation type="obsolete">200 ms</translation>
    </message>
    <message>
        <source>500 ms</source>
        <translation type="obsolete">500 ms</translation>
    </message>
    <message>
        <source>1 s</source>
        <translation type="obsolete">1 s</translation>
    </message>
    <message>
        <source>3 s</source>
        <translation type="obsolete">3 s</translation>
    </message>
    <message>
        <source>5 s</source>
        <translation type="obsolete">5 s</translation>
    </message>
    <message>
        <source>10 s</source>
        <translation type="obsolete">10 s</translation>
    </message>
    <message>
        <source>20 s</source>
        <translation type="obsolete">20 s</translation>
    </message>
    <message>
        <source>30 s</source>
        <translation type="obsolete">30 s</translation>
    </message>
    <message>
        <source>Alarma de intrusion</source>
        <translation type="obsolete">Intrusion alarm</translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation>Allarme incendio</translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation>Allarme Gas</translation>
    </message>
    <message>
        <source>Alarma de inundacion</source>
        <translation type="obsolete">Flood alarm</translation>
    </message>
    <message>
        <source>Alarma de corte de suministro electrico</source>
        <translation type="obsolete">Power fail alarm</translation>
    </message>
    <message>
        <source>Alarma de corte telefonico</source>
        <translation type="obsolete">Telephone fail alarm</translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation>Allarme di sistema</translation>
    </message>
    <message>
        <source>Alarma medica</source>
        <translation type="obsolete">Medical alarm</translation>
    </message>
    <message>
        <source>Alarma de panico</source>
        <translation type="obsolete">Panic alarm</translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation>Allarme silenzioso</translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation>Allarme manomissione</translation>
    </message>
    <message>
        <source>ON/OFF</source>
        <translation type="obsolete">ON-OFF</translation>
    </message>
    <message>
        <source>Dimmer</source>
        <translation type="obsolete">Dimmer</translation>
    </message>
    <message>
        <source>RGB</source>
        <translation type="obsolete">RGB</translation>
    </message>
    <message>
        <source>Todas</source>
        <translation type="obsolete">Tutte</translation>
    </message>
    <message>
        <source>Persiana</source>
        <translation type="obsolete">Tapparella</translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation>Tapparella veneziana</translation>
    </message>
    <message>
        <source>Toldo</source>
        <translation type="obsolete">Tenda</translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation>Tenda Veneziana</translation>
    </message>
    <message>
        <source>Puerta</source>
        <translation type="obsolete">Porta</translation>
    </message>
    <message>
        <source>Todos</source>
        <translation type="obsolete">Tutti</translation>
    </message>
    <message>
        <source>Deshabilitar alarma</source>
        <translation type="obsolete">Disattiva allarme</translation>
    </message>
    <message>
        <source>Habilitar alarma</source>
        <translation type="obsolete">Abilita allarme</translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation>Attiva allarme</translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation>Attiva modo perimetrale</translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation>Attiva modo parziale</translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation>Attiva modo totale</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Disattiva</translation>
    </message>
    <message>
        <source>Desarmar coaccion</source>
        <translation type="obsolete">Disarm coercion</translation>
    </message>
    <message>
        <source>Encender</source>
        <translation>Accendi</translation>
    </message>
    <message>
        <source>Apagar</source>
        <translation>Spegni</translation>
    </message>
    <message>
        <source>0 %</source>
        <translation type="obsolete">0 %</translation>
    </message>
    <message>
        <source>10 %</source>
        <translation type="obsolete">10 %</translation>
    </message>
    <message>
        <source>20 %</source>
        <translation type="obsolete">20 %</translation>
    </message>
    <message>
        <source>30 %</source>
        <translation type="obsolete">30 %</translation>
    </message>
    <message>
        <source>40 %</source>
        <translation type="obsolete">40 %</translation>
    </message>
    <message>
        <source>50 %</source>
        <translation type="obsolete">50 %</translation>
    </message>
    <message>
        <source>60 %</source>
        <translation type="obsolete">60 %</translation>
    </message>
    <message>
        <source>70 %</source>
        <translation type="obsolete">70 %</translation>
    </message>
    <message>
        <source>80 %</source>
        <translation type="obsolete">80 %</translation>
    </message>
    <message>
        <source>90 %</source>
        <translation type="obsolete">90 %</translation>
    </message>
    <message>
        <source>100 %</source>
        <translation type="obsolete">100 %</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation type="obsolete">Aumentare</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation type="obsolete">Abbassare</translation>
    </message>
    <message>
        <source>Activar</source>
        <translation>Attivato</translation>
    </message>
    <message utf8="true">
        <source>Iluminación</source>
        <translation>illuminazione</translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation>Clima</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation>Allarme antintrusione</translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation>Allarme allagamento</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte de suministro eléctrico</source>
        <translation type="obsolete">Allarme mancanza rete</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte telefónico</source>
        <translation>Allarme linea telefonica</translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation>Allarme medico</translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation>Allarme panico</translation>
    </message>
    <message utf8="true">
        <source>Desarmar coacción</source>
        <translation type="obsolete">Disattiva coercizione</translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation>Disattivare</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation>Allarme mancanza tensione</translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation>Persiana normale</translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation>Tenda normale</translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation>Dis.motorizzato</translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation>Luci zona</translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation>Luce ON/OFF</translation>
    </message>
    <message>
        <source>Luz Regulable</source>
        <translation>Luce regolabile</translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation>Tutti i tipi</translation>
    </message>
    <message>
        <source>0%</source>
        <translation>0%</translation>
    </message>
    <message>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <source>20%</source>
        <translation>20%</translation>
    </message>
    <message>
        <source>40%</source>
        <translation>40%</translation>
    </message>
    <message>
        <source>60%</source>
        <translation>60%</translation>
    </message>
    <message>
        <source>80%</source>
        <translation>80%</translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation>Prese FM zona</translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation>Climatizzazione singola</translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation>Tutti i climatizzatori</translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation>Spegnimento</translation>
    </message>
    <message>
        <source>Modo manual</source>
        <translation>Modalita manuale</translation>
    </message>
    <message>
        <source>Modo programa</source>
        <translation>Modalita programma</translation>
    </message>
    <message utf8="true">
        <source>Modo económico</source>
        <translation>Modalità risparmio</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>Riegos de la zona</source>
        <translation>Irrigatori della zona</translation>
    </message>
    <message>
        <source>1 seg</source>
        <translation>1 sec</translation>
    </message>
    <message>
        <source>3 seg</source>
        <translation>3 sec</translation>
    </message>
    <message>
        <source>5 seg</source>
        <translation>5 sec</translation>
    </message>
    <message>
        <source>10 seg</source>
        <translation>10 sec</translation>
    </message>
    <message>
        <source>20 seg</source>
        <translation>20 sec</translation>
    </message>
    <message>
        <source>30 seg</source>
        <translation>30 sec</translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation>disattiva parzialmente </translation>
    </message>
    <message>
        <source>Dis. individual</source>
        <translation>Dis.singolo</translation>
    </message>
    <message>
        <source>Dis. de la zona</source>
        <translation>Dis. della zona</translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation>Tutti i dispositivi</translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation>Gruppo Persiane</translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation>Qualunque persiana</translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation>Gruppo di tende</translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation>Qualunque tenda</translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation>Tenda a sipario normale</translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation>Tenda a sipario posizionale</translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation>Gruppo di tende a sipario</translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation>Qualunque tenda a sipario</translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation>Porta motorizzata</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Apri</translation>
    </message>
    <message>
        <source>Enchufe normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enchufes temporizados</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneEventWindowClass</name>
    <message>
        <source>SceneEventWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation type="obsolete">Tipo</translation>
    </message>
    <message>
        <source>Parametro 1</source>
        <translation type="obsolete">Parasmetro 1</translation>
    </message>
    <message>
        <source>Parametro 2</source>
        <translation type="obsolete">Parametro 2</translation>
    </message>
    <message>
        <source>Parametro 3</source>
        <translation type="obsolete">Parametro 3</translation>
    </message>
    <message>
        <source>Parametro 4</source>
        <translation type="obsolete">Parametro 4</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Modificar evento</source>
        <translation>Modifica evento</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Tipo de evento:</source>
        <translation>Tipo di evento:</translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation>Tipo di controllo:</translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation>Tipo di elemento:</translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation>Elemenot:</translation>
    </message>
    <message>
        <source>Valor:</source>
        <translation>Valore:</translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindow</name>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Inserisci nuovo nome...</translation>
    </message>
    <message>
        <source>Iluminacion</source>
        <translation type="obsolete">Lighting</translation>
    </message>
    <message>
        <source>Persiana</source>
        <translation type="obsolete">Tapparella</translation>
    </message>
    <message>
        <source>Toldo</source>
        <translation type="obsolete">Tenda</translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation type="obsolete">Porta motorizzata</translation>
    </message>
    <message>
        <source>Todas las Persianas y Toldos</source>
        <translation type="obsolete">Tutte le persiane e le tapparelle</translation>
    </message>
    <message>
        <source>Persianas</source>
        <translation type="obsolete">Tapparelle</translation>
    </message>
    <message>
        <source>Toldos</source>
        <translation type="obsolete">Tende</translation>
    </message>
    <message>
        <source>Puertas motorizada</source>
        <translation type="obsolete">Poerte motorizzate</translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation>Presa fm</translation>
    </message>
    <message>
        <source>Enchufes</source>
        <translation type="obsolete">Prese FM</translation>
    </message>
    <message>
        <source>Todos los enchufes </source>
        <translation type="obsolete">Tutte le prese FM</translation>
    </message>
    <message>
        <source>Climatizacion</source>
        <translation type="obsolete">Climate control</translation>
    </message>
    <message>
        <source>Riego</source>
        <translation>Irrigatore</translation>
    </message>
    <message>
        <source>Riegos</source>
        <translation type="obsolete">Irrigatori</translation>
    </message>
    <message>
        <source>Todos los riegos </source>
        <translation type="obsolete">Tutti gli irrigatori</translation>
    </message>
    <message>
        <source>Retardo</source>
        <translation type="obsolete">Ritardo</translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation>Sicurezza</translation>
    </message>
    <message>
        <source>Se va a eliminar la escena.
¿Está seguro?</source>
        <translation type="obsolete">Scene is about to be deleted.
do you wish to proceed?</translation>
    </message>
    <message>
        <source>Eliminar escena...</source>
        <translation type="obsolete">Delete scene</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el evento.
¿Está seguro?</source>
        <translation>L&apos;evento sarà cancellato.
desideri procedere?</translation>
    </message>
    <message>
        <source>Eliminar evento...</source>
        <translation>Eliminare evento...</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation type="obsolete">Aumentare</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation type="obsolete">Diminuire</translation>
    </message>
    <message>
        <source>Zona </source>
        <translation type="obsolete">Zona</translation>
    </message>
    <message>
        <source>Encender</source>
        <translation type="obsolete">Accendi</translation>
    </message>
    <message>
        <source>Apagar</source>
        <translation type="obsolete">Spegni</translation>
    </message>
    <message>
        <source> Zona </source>
        <translation type="obsolete">Zona</translation>
    </message>
    <message>
        <source>Activar</source>
        <translation type="obsolete">Attivare</translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation type="obsolete">Disattivare</translation>
    </message>
    <message>
        <source>Alarma de Intrusion</source>
        <translation type="obsolete">Intrusion alarm</translation>
    </message>
    <message>
        <source>Deshabilitar alarma</source>
        <translation>Disattiva allarme</translation>
    </message>
    <message>
        <source>Habilitar alarma</source>
        <translation>Abilita allarme</translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation>Attiva allarme</translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation>Attiva modo perimetrale</translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation>Attiva modo parziale</translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation>Attiva modo totale</translation>
    </message>
    <message>
        <source>Desarmar alarma</source>
        <translation type="obsolete">Disattiva allarme</translation>
    </message>
    <message>
        <source>Alarma de Coaccion</source>
        <translation type="obsolete">Coercion alarm</translation>
    </message>
    <message>
        <source>Alarma de Fuego</source>
        <translation type="obsolete">Allarme incendio</translation>
    </message>
    <message>
        <source>Alarma de Gas</source>
        <translation type="obsolete">Allarme Gas</translation>
    </message>
    <message>
        <source>Alarma de Inundacion</source>
        <translation type="obsolete">Flood alarm</translation>
    </message>
    <message>
        <source>Alarma de Corte de suministro electrico</source>
        <translation type="obsolete">Power fail alarm</translation>
    </message>
    <message>
        <source>Alarma de Corte de telefono</source>
        <translation type="obsolete">Telephone fail alarm</translation>
    </message>
    <message>
        <source>Alarma de Sistema</source>
        <translation type="obsolete">Allarme di sistema</translation>
    </message>
    <message>
        <source>Alarma Medica</source>
        <translation type="obsolete">Medical alarm</translation>
    </message>
    <message>
        <source>Alarma de Panico</source>
        <translation type="obsolete">Panic alarm</translation>
    </message>
    <message>
        <source>Alarma Silenciosa</source>
        <translation type="obsolete">Allarme silenzioso</translation>
    </message>
    <message>
        <source>Alarma de Sabotaje</source>
        <translation type="obsolete">Allarme manomissione</translation>
    </message>
    <message>
        <source>Evento</source>
        <translation>Evento</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Iluminación</source>
        <translation>illuminazione</translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation>Climatizzazione</translation>
    </message>
    <message utf8="true">
        <source>Alarma de Intrusión</source>
        <translation type="obsolete">Allarme antintrusione</translation>
    </message>
    <message utf8="true">
        <source>Alarma de Coacción</source>
        <translation type="obsolete">Allarme Coercizione</translation>
    </message>
    <message utf8="true">
        <source>Alarma de Inundación</source>
        <translation type="obsolete">Allarme allagamento</translation>
    </message>
    <message utf8="true">
        <source>Alarma de Corte de suministro eléctrico</source>
        <translation type="obsolete">Allarme mancanza rete</translation>
    </message>
    <message utf8="true">
        <source>Alarma de Corte de teléfono</source>
        <translation type="obsolete">Allarme linea telefonica</translation>
    </message>
    <message utf8="true">
        <source>Alarma Médica</source>
        <translation type="obsolete">Allarme medico</translation>
    </message>
    <message utf8="true">
        <source>Alarma de Pánico</source>
        <translation type="obsolete">Allarme panico</translation>
    </message>
    <message>
        <source>Luces</source>
        <translation type="obsolete">Luci</translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation type="obsolete">Tutte le luci</translation>
    </message>
    <message>
        <source> - Todas las luces</source>
        <translation>-Tutte le luci</translation>
    </message>
    <message>
        <source> - Apagar</source>
        <translation>-Spegni</translation>
    </message>
    <message>
        <source> - ON/OFF</source>
        <translation>-ON/OFF-</translation>
    </message>
    <message>
        <source> - Regulable</source>
        <translation>-Regolabile-</translation>
    </message>
    <message>
        <source> - RGB</source>
        <translation>-RGB-</translation>
    </message>
    <message>
        <source> - Todos los tipos</source>
        <translation>-Tutti i tipi-</translation>
    </message>
    <message>
        <source> - Individual: </source>
        <translation>-Singolo:</translation>
    </message>
    <message>
        <source> - Zona: </source>
        <translation>-Zona:</translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation>Dis.motorizzato</translation>
    </message>
    <message>
        <source> - Persiana normal</source>
        <translation>-Persiana normale</translation>
    </message>
    <message>
        <source> - Persiana posicional</source>
        <translation>-Persiana posizionale</translation>
    </message>
    <message>
        <source> - Persianas agupadas</source>
        <translation>-Gruppo Persiane</translation>
    </message>
    <message>
        <source> - Cualquier persiana</source>
        <translation>-Qualunque persiana</translation>
    </message>
    <message>
        <source> - Toldo normal</source>
        <translation>-Tenda normale</translation>
    </message>
    <message>
        <source> - Toldo posicional</source>
        <translation>-Tenda posizionale</translation>
    </message>
    <message>
        <source> - Toldos agupados</source>
        <translation>-Gruppo di tende</translation>
    </message>
    <message>
        <source> - Cualquier toldo</source>
        <translation>-Qualunque persiana</translation>
    </message>
    <message>
        <source> - Cortina normal</source>
        <translation>-tenda a sipario</translation>
    </message>
    <message>
        <source> - Cortina posicional</source>
        <translation>-Tenda a sipario posizionale </translation>
    </message>
    <message>
        <source> - Cortinas agupadas</source>
        <translation>-Gruppo di tende a sipario</translation>
    </message>
    <message>
        <source> - Cualquier cortina</source>
        <translation>-Qualunque tenda a sipario</translation>
    </message>
    <message>
        <source> - Puerta motorizada</source>
        <translation>-Porta motorizzata</translation>
    </message>
    <message>
        <source> - Todos los dispositivos</source>
        <translation>-Tutti i dispositivi</translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation>-Tutte le prese FM</translation>
    </message>
    <message>
        <source> - Encender</source>
        <translation>-Accendere</translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation>- Tutti i climatizzatori</translation>
    </message>
    <message>
        <source> - Apagado</source>
        <translation>-Spegnimento</translation>
    </message>
    <message>
        <source> - Modo manual - </source>
        <translation>-Modalita manuale-</translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source> - Modo programa</source>
        <translation>-Modalita programma</translation>
    </message>
    <message utf8="true">
        <source> - Modo económico - </source>
        <translation>-Modalità risparmio-</translation>
    </message>
    <message>
        <source> - Todos los riegos</source>
        <translation>-Tutti gli irrigatori</translation>
    </message>
    <message>
        <source> - Activar</source>
        <translation>-Attivare</translation>
    </message>
    <message>
        <source> - Desactivar</source>
        <translation>-Disattivare</translation>
    </message>
    <message>
        <source>Retardo - </source>
        <translation>Ritardo-</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation>Allarme antintrusione</translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation>Allarme incendio</translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation>Allarme Gas</translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation>Allarme allagamento</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation>Allarme mancanza tensione</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte de teléfono</source>
        <translation>Allarme linea telefonica</translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation>Allarme di sistema</translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation>Allarme medico</translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation>Allarme panico</translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation>Allarme silenzioso</translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation>Allarme manomissione</translation>
    </message>
    <message utf8="true">
        <source>Alarma de coacción</source>
        <translation>Allarme Coercizione</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Disarma</translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation>Disarma parzialmente</translation>
    </message>
    <message>
        <source> - Todos </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - No temporizados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Temporizados</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindowClass</name>
    <message>
        <source>ScenesConfigWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <source>Modificar</source>
        <translation type="obsolete">Modify</translation>
    </message>
    <message>
        <source>Eliminar
Accion </source>
        <translation type="obsolete">Delete action</translation>
    </message>
    <message>
        <source>Eliminar
Escena</source>
        <translation type="obsolete">Delete
scene</translation>
    </message>
    <message>
        <source>Condiciones</source>
        <translation type="obsolete">Conditions</translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindow</name>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la escena.
¿Está seguro?</source>
        <translation>Lo scenario verrà cancellato.
Vuoi proseguire?</translation>
    </message>
    <message>
        <source>Eliminar escena...</source>
        <translation>Elimina scenario...</translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
</context>
<context>
    <name>ScenesWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindow</name>
    <message>
        <source>Castellano</source>
        <translation>Spagnolo</translation>
    </message>
    <message utf8="true">
        <source>Inglés</source>
        <translation>Inglese</translation>
    </message>
    <message utf8="true">
        <source>Portugués</source>
        <translation>Portoghese</translation>
    </message>
    <message utf8="true">
        <source>Francés</source>
        <translation>Francese</translation>
    </message>
    <message utf8="true">
        <source>Alemán</source>
        <translation>Tedesco</translation>
    </message>
    <message>
        <source>Euskera</source>
        <translation>Lingua Basca</translation>
    </message>
    <message utf8="true">
        <source>Catalán</source>
        <translation>Catalan</translation>
    </message>
    <message>
        <source>Gallego</source>
        <translation>Galiziano</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation type="obsolete">Scuro</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <source>Marco de fotos digital</source>
        <translation>Digital picture frame</translation>
    </message>
    <message>
        <source>Reloj/Temperatura</source>
        <translation type="obsolete">Ora/Temperatura</translation>
    </message>
    <message>
        <source>Grey Ligth</source>
        <translation type="obsolete">Grey Ligth</translation>
    </message>
    <message utf8="true">
        <source>Botón</source>
        <translation>Pulsante</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Azione</translation>
    </message>
    <message>
        <source>Turco</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>Arancio</translation>
    </message>
    <message>
        <source>Azul</source>
        <translation type="unfinished">Azzurro</translation>
    </message>
    <message>
        <source>Negro</source>
        <translation type="unfinished">Nero</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation>Verde</translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation type="unfinished">Rosso</translation>
    </message>
    <message utf8="true">
        <source>Árabe</source>
        <translation>Arabo</translation>
    </message>
    <message>
        <source>Green</source>
        <translation type="obsolete">Verde</translation>
    </message>
    <message>
        <source>Italiano</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <source>0 %</source>
        <translation>0 %</translation>
    </message>
    <message>
        <source>20 %</source>
        <translation>20 %</translation>
    </message>
    <message>
        <source>40 %</source>
        <translation>40 %</translation>
    </message>
    <message>
        <source>60 %</source>
        <translation>60 %</translation>
    </message>
    <message>
        <source>80 %</source>
        <translation>80 %</translation>
    </message>
    <message>
        <source>100 %</source>
        <translation>100 %</translation>
    </message>
    <message>
        <source>1 minuto</source>
        <translation>1 minuto</translation>
    </message>
    <message>
        <source>2 minuto</source>
        <translation>2 minuti</translation>
    </message>
    <message>
        <source>5 minuto</source>
        <translation>5 minuti</translation>
    </message>
    <message>
        <source>10 minuto</source>
        <translation>10 minuti</translation>
    </message>
    <message>
        <source>15 minuto</source>
        <translation>15 minuti</translation>
    </message>
    <message>
        <source>30 minuto</source>
        <translation>30 minuti</translation>
    </message>
    <message>
        <source>Nunca</source>
        <translation>mai</translation>
    </message>
    <message>
        <source>Oscuro</source>
        <translation>Buio</translation>
    </message>
    <message>
        <source>(vacio)</source>
        <translation>(vuoto)</translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Maschera</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generale</translation>
    </message>
    <message>
        <source> Identificador de pantalla</source>
        <translation>Identificazione display</translation>
    </message>
    <message>
        <source> Idioma</source>
        <translation>Lingua</translation>
    </message>
    <message>
        <source> Volumen</source>
        <translation>Volume</translation>
    </message>
    <message>
        <source> Brillo</source>
        <translation type="obsolete">Luminosità</translation>
    </message>
    <message>
        <source>Sonido teclado</source>
        <translation>Suono tastiera</translation>
    </message>
    <message>
        <source>Sensor de presencia</source>
        <translation>Sensore di presenza</translation>
    </message>
    <message>
        <source> Color</source>
        <translation type="obsolete">Color</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Salvapantallas</source>
        <translation>Salvaschermo</translation>
    </message>
    <message>
        <source> Salvapantallas</source>
        <translation>Salvaschermo</translation>
    </message>
    <message utf8="true">
        <source> Activación Salvapantallas</source>
        <translation>Attivazione salvaschermo</translation>
    </message>
    <message>
        <source> Tiempo entre fotos</source>
        <translation>Durata foto</translation>
    </message>
    <message>
        <source> Autoapagado</source>
        <translation>Auto spegnimento</translation>
    </message>
    <message>
        <source>Botones</source>
        <translation>Pulsanti</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation type="obsolete">Action</translation>
    </message>
    <message>
        <source>Arriba</source>
        <translation type="obsolete">Up</translation>
    </message>
    <message>
        <source>Abajo</source>
        <translation type="obsolete">Down</translation>
    </message>
    <message utf8="true">
        <source>Nueva acción</source>
        <translation type="obsolete">New action</translation>
    </message>
    <message utf8="true">
        <source>Eliminar acción</source>
        <translation type="obsolete">Delete action</translation>
    </message>
    <message>
        <source>QTabBar::tab {
	min-height: 20px;
    padding: 8px;
 }</source>
        <translation type="obsolete">QTabBar::tab {	min-height: 20px;    padding: 8px; }</translation>
    </message>
    <message>
        <source> Paleta</source>
        <translation>Maschere</translation>
    </message>
    <message>
        <source> Color iconos</source>
        <translation>Colori icone</translation>
    </message>
    <message>
        <source>Offset de temperatura</source>
        <translation>Offset temperatura</translation>
    </message>
    <message>
        <source>Visualizar cursor</source>
        <translation>Visualizza cursore</translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para ejecutar escenas</source>
        <translation>chiedere la password per effetuare gli scenari</translation>
    </message>
    <message utf8="true">
        <source>Habilitación tamper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IP</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScreenSaver</name>
    <message>
        <source>%1:%2
%3/%4/%5</source>
        <translation type="obsolete">%1:%2
%3/%4/%5</translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindow</name>
    <message>
        <source>Armado total</source>
        <translation>Attiva Totale</translation>
    </message>
    <message>
        <source>Armado parcial</source>
        <translation>Attiva Parziale</translation>
    </message>
    <message>
        <source>Armado perimetral</source>
        <translation>Attiva Perimetrale</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>Nessuno</translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Maschera</translation>
    </message>
    <message utf8="true">
        <source>Intrusión</source>
        <translation>Intrusione</translation>
    </message>
    <message utf8="true">
        <source>Llamar en caso de intrusión a:</source>
        <translation type="obsolete">In case of intrusion call:</translation>
    </message>
    <message utf8="true">
        <source>Habilitación el autoarmado de intrusión</source>
        <translation type="obsolete">Abilita autoaccensione antifurto</translation>
    </message>
    <message>
        <source>Armado Perimetral</source>
        <translation type="obsolete">Peripheral arming</translation>
    </message>
    <message>
        <source>Armado Parcial</source>
        <translation type="obsolete">Partial arming</translation>
    </message>
    <message>
        <source>Armado Total</source>
        <translation type="obsolete">Full arming</translation>
    </message>
    <message>
        <source>Programa asociado el autoarmado</source>
        <translation>Timer autoaccensione antifurto</translation>
    </message>
    <message>
        <source>Viernes...</source>
        <translation type="obsolete">Friday...</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message utf8="true">
        <source>Activar simulación de presencia con el armado total</source>
        <translation>Attiva simulazione presenza e allarme totale</translation>
    </message>
    <message utf8="true">
        <source>Tiempo mínimo de armado (seg):</source>
        <translation type="obsolete">Tempo inserimento min (sec):</translation>
    </message>
    <message utf8="true">
        <source> Retraso a la activación (seg):</source>
        <translation type="obsolete">Ritardo attivazione (sec):</translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation>Incendio</translation>
    </message>
    <message>
        <source>Llamar en caso de incendio a:</source>
        <translation type="obsolete">In case of fire call:</translation>
    </message>
    <message>
        <source>Gas</source>
        <translation>Gas</translation>
    </message>
    <message>
        <source>Llamar en caso de alarma de gas a:</source>
        <translation type="obsolete">In case of gas alarm call:</translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation>Allagamento</translation>
    </message>
    <message utf8="true">
        <source>Llamar en caso de inundación a:</source>
        <translation type="obsolete">In case of flooding call:</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (seg):</source>
        <translation type="unfinished">Ritardo attivazione (sec):</translation>
    </message>
    <message utf8="true">
        <source>Corte Red Eléctrica</source>
        <translation>Mancanza Tensione</translation>
    </message>
    <message utf8="true">
        <source>Llamar en caso de corte en la red eléctrica a:</source>
        <translation type="obsolete">In case of power fail call:</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (min):</source>
        <translation>Ritardo attivazione (min):</translation>
    </message>
    <message utf8="true">
        <source>Corte teléfono</source>
        <translation>Mancanza linea telefonica</translation>
    </message>
    <message utf8="true">
        <source>Llamar en caso de corte de teléfono a:</source>
        <translation type="obsolete">In case of telephone fail call:</translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <source>Llamar en caso de alarma de sistema a:</source>
        <translation type="obsolete">In case of system alarm call:</translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation>Soccorso</translation>
    </message>
    <message utf8="true">
        <source>Llamar en caso de alarma médica a:</source>
        <translation type="obsolete">In case of medical alarm call:</translation>
    </message>
    <message utf8="true">
        <source>Detección de inactividad</source>
        <translation>Rilevazione inattività</translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation>Panico</translation>
    </message>
    <message utf8="true">
        <source>Llamar en caso de alarma de pánico a:</source>
        <translation type="obsolete">In case of panic alarm call:</translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation>Silenzioso</translation>
    </message>
    <message>
        <source>Llamar en caso de alarma silenciosa a:</source>
        <translation type="obsolete">In case of silent alarm call:</translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation>Manomissione</translation>
    </message>
    <message>
        <source>Llamar en caso de sabotaje a:</source>
        <translation type="obsolete">In case of sabotage alarm call:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>QTabBar::tab {
	min-height: 20px;
    padding: 8px;
 }</source>
        <translation type="obsolete">QTabBar::tab {	min-height: 20px;    padding: 8px; }</translation>
    </message>
    <message>
        <source>Llamar en caso de alarma a:</source>
        <translation>In caso di allarme chiama:</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 1</source>
        <translation>Telefono 1</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 2</source>
        <translation>Telefono 2</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 3</source>
        <translation>Telefono 3</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 4</source>
        <translation>Telefono 4</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 5</source>
        <translation>Telefono 5</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 6</source>
        <translation>Telefono 6</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 7</source>
        <translation>Telefono 7</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 8</source>
        <translation>Telefono 8</translation>
    </message>
    <message utf8="true">
        <source>Habilitar autoarmado de intrusión</source>
        <translation>Abilita autoaccensione antifurto</translation>
    </message>
    <message>
        <source>Tiempo de salida de la vivienda (seg):</source>
        <translation>Tempo di uscita dall&apos;abitazione (sec):</translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para armar la alarma de intrusión</source>
        <translation>Chiedere password per attivare l&apos;antintrusione</translation>
    </message>
    <message utf8="true">
        <source>Hora de auto limpieza de la electroválvula de agua:</source>
        <translation>Tempo di autobonifica della elettrovalvola dell&apos;acqua:</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:mm</translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation>Coercizione</translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation>Messaggi
Personali</translation>
    </message>
</context>
<context>
    <name>SecurityWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Armado Perimetral</source>
        <translation>Attiva Perimetrale</translation>
    </message>
    <message>
        <source>Armado Parcial</source>
        <translation>Attiva Parziale</translation>
    </message>
    <message>
        <source>Armado Total</source>
        <translation>Attiva Totale</translation>
    </message>
</context>
<context>
    <name>SelectActionClass</name>
    <message>
        <source>Aplicar</source>
        <translation type="obsolete">Validate</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="obsolete">Cancel</translation>
    </message>
    <message utf8="true">
        <source>Selecciona la acción:</source>
        <translation type="obsolete">Select action:</translation>
    </message>
</context>
<context>
    <name>SensorControl</name>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Inserisci nuovo nome...</translation>
    </message>
</context>
<context>
    <name>SensorControlClass</name>
    <message>
        <source>SensorControl</source>
        <translation>SensorControl</translation>
    </message>
    <message>
        <source>background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</source>
        <translation type="obsolete">background-color: qlineargradient(spread:pad, x1:1, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 133), stop:0.988636 rgba(255, 255, 255, 0));</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Deshabilitar sensor</source>
        <translation>Disabilitare sensore</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <source>Interviene en el armado parcial</source>
        <translation>Interviene nell&apos;armo parziale</translation>
    </message>
    <message>
        <source>Interviene en el armado perimetral</source>
        <translation>interviene nell&apos;armo perimetrale</translation>
    </message>
    <message>
        <source>Tiempo de entrada:</source>
        <translation>tempo  di entrata:</translation>
    </message>
    <message>
        <source>Offset de temperatura:</source>
        <translation>Offset temperatura:</translation>
    </message>
    <message>
        <source>Retraso a la activacion:</source>
        <translation>Ritardo di attivazione:</translation>
    </message>
</context>
<context>
    <name>SystemConfigWindow</name>
    <message>
        <source>www.tiempo.es</source>
        <translation type="obsolete">www.meteolive.it</translation>
    </message>
    <message>
        <source>www.periodico.es</source>
        <translation type="obsolete">www.ansa.com</translation>
    </message>
    <message>
        <source>www.bolsa.es</source>
        <translation type="obsolete">www.feel3.it</translation>
    </message>
    <message>
        <source>www.viajes.es</source>
        <translation type="obsolete">www.infotraffic.it</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a importar ficheros.
Por favor, no saque el dispositivo durante la importación.
 ¿Desea continuar?</source>
        <translation>Si sta per importare i file
per favore non rimuovere il dispositivo durante l&apos;importazione
desideri continuare ?</translation>
    </message>
    <message>
        <source>Importando...</source>
        <translation>Importazione...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a exportar ficheros.
Por favor, no saque el dispositivo durante la exportación.
¿Desea continuar?</source>
        <translation>Si sta per Esportare i file
per favore non rimuovere il dispositivo
desiderate continuare?</translation>
    </message>
    <message>
        <source>Exportando...</source>
        <translation>Esportare...</translation>
    </message>
    <message>
        <source>Actualizando...</source>
        <translation>Aggiornamento...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Firmware.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation>Si sta aggiornando il Firmware
Per favore non rimuovere il dispositivo durante l&apos;aggiornamento
desiderate continuare?</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Webserver.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation>Si sta aggiornando il Webserver
per favore non rimuovere il dispositivo durante l&apos;aggiornamento
desiderate continuare?</translation>
    </message>
    <message utf8="true">
        <source>Para proceder a calibrar el touch es necesario reiniciar la pantalla.
¿Desea continuar?</source>
        <translation>Per poter calibrare il touch è necessario reinizializzare il touch screen.
desiderate continure?</translation>
    </message>
    <message>
        <source>Calibrar Touch...</source>
        <translation>Calibrare il touch...</translation>
    </message>
    <message>
        <source>Test Alarmas: %1
Pulse para %2</source>
        <translation>Allarme di test:%1
Premere per%2</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation>Disattivare</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>Activar</source>
        <translation>attivare</translation>
    </message>
    <message>
        <source>Activar licencia</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SystemConfigWindowClass</name>
    <message>
        <source>SystemConfigWindow</source>
        <translation>SystemConfigWindow</translation>
    </message>
    <message>
        <source>Internet</source>
        <translation type="obsolete">Internet</translation>
    </message>
    <message>
        <source>Y/N</source>
        <translation type="obsolete">S/N</translation>
    </message>
    <message>
        <source>Link</source>
        <translation type="obsolete">Link</translation>
    </message>
    <message>
        <source>Imagen / Texto</source>
        <translation type="obsolete">Immagine/Testo</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="obsolete">Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Reset del Sistema</source>
        <translation>Reset del sistema</translation>
    </message>
    <message>
        <source>Exportar Ficheros</source>
        <translation>Esportare file</translation>
    </message>
    <message>
        <source>Importar  Ficheros</source>
        <translation>Importare i file</translation>
    </message>
    <message>
        <source>Acceder como
instalador</source>
        <translation>Accedere come
Installatore</translation>
    </message>
    <message>
        <source>Actualizar
Firmware</source>
        <translation>Aggiornare
il Firmware</translation>
    </message>
    <message>
        <source>Recalibrar Touch</source>
        <translation>Recalibrare lo schermo</translation>
    </message>
    <message>
        <source>Log de Errores</source>
        <translation>Log degli errori</translation>
    </message>
    <message>
        <source>Actualizar
WebServer</source>
        <translation>Aggiornare
il web server</translation>
    </message>
    <message>
        <source>Prueba de alarmas: %1
Pulse para %2</source>
        <translation>Allarme di test:%1
Premere per%2</translation>
    </message>
    <message>
        <source>Test llamadas CRA</source>
        <translation>Chiamate di prova CRA</translation>
    </message>
    <message>
        <source>Licencia...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished">Textlabel</translation>
    </message>
</context>
<context>
    <name>UsersConfigWindow</name>
    <message>
        <source>Maestro</source>
        <translation>Master</translation>
    </message>
    <message>
        <source>Alto</source>
        <translation>Alta</translation>
    </message>
    <message>
        <source>Medio</source>
        <translation>Medio</translation>
    </message>
    <message>
        <source>Bajo</source>
        <translation>Basso</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Inserisci nuovo nome...</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Clave</source>
        <translation>Codice</translation>
    </message>
    <message>
        <source>Nivel Acceso</source>
        <translation>Livello Accesso</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el usuario.
¿Está seguro?</source>
        <translation>L&apos;utente sta per essere eliminato.
Desideri proseguire?</translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation>Elimina contatto...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Completa i dati mancanti.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Errore...</translation>
    </message>
    <message utf8="true">
        <source>Introduzca la nueva contraseña</source>
        <translation>Inserisci nuova password</translation>
    </message>
    <message utf8="true">
        <source>No se puede eliminar el único usuario maestro del sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Eliminación de usuario interrumpida.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UsersConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="obsolete">Name</translation>
    </message>
    <message>
        <source>Clave</source>
        <translation type="obsolete">Code</translation>
    </message>
    <message>
        <source>Nivel Acceso</source>
        <translation type="obsolete">Access level</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Microsoft Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Nivel de seguridad&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;del sistema&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Microsoft Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;System security level&lt;/p&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Leer Llave</source>
        <translation>Leggi chiave</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Nivel de seguridad
del sistema</source>
        <translation type="obsolete">Livello sicurezza sistema</translation>
    </message>
</context>
<context>
    <name>WarningDialog</name>
    <message utf8="true">
        <source>Fallo en el sistema de avisos telefónicos.</source>
        <translation>Errore nel sistema di avviso telefonico..</translation>
    </message>
    <message>
        <source>Test de CRA fallido.</source>
        <translation>Test del CRA fallito.</translation>
    </message>
    <message utf8="true">
        <source>Aviso de cancelación de alarma de intrusión fallido.</source>
        <translation>Avviso di cancellazione allarme antintrusione fallito.</translation>
    </message>
    <message utf8="true">
        <source>Armado de intrusión cancelado. Sensor no temporizado activo:
%1</source>
        <translation>Attivazione antintrusione cancellata. Sensore non temporizzato attivo:
%1</translation>
    </message>
    <message>
        <source>Climatizador apagado por ventana abierta:
%1</source>
        <translation>Climatizzazione spenta per finestra aperta:
%1</translation>
    </message>
    <message>
        <source>Entrada de sensor en circuito abierto:
%1</source>
        <translation>Circuito difettoso:
%1</translation>
    </message>
    <message utf8="true">
        <source>Cámara de videoportería ocupada.</source>
        <translation>Telecamera del videocitofono occupata.</translation>
    </message>
    <message>
        <source>No se ha encontrado el mensaje que se desea reproducir.</source>
        <translation>Non è stato trovato il messaggio che si desidera riprodurre..</translation>
    </message>
    <message utf8="true">
        <source>No hay espacio para grabar más mensajes de voz, o se ha alcanzado el límite de 10 mensajes.</source>
        <translation>Non vi è spazio sufficiente per registrare ulteriori messaggi vocali, il limite di 10 messaggi è stato superato.</translation>
    </message>
    <message utf8="true">
        <source>Error en la comunicación con el módulo %1:
Comando rechazado.</source>
        <translation>Errore nella comunicazione con il modulo%1
Comando rifiutato.</translation>
    </message>
    <message>
        <source>Error al iniciar el sistema de ficheros. Compruebe si la tarjeta SD de la central funciona correctamente.</source>
        <translation>Errore nell&apos;inizializzazione dei file.Verificare il corretto funzionamento della scheda sd .</translation>
    </message>
    <message utf8="true">
        <source>El estado de la batería es bajo.</source>
        <translation>Lovello batteria basso.</translation>
    </message>
    <message utf8="true">
        <source>Perdidas de tramas en la comunicación.</source>
        <translation>Perdita della comunicazione..</translation>
    </message>
    <message utf8="true">
        <source>Comunicación recuperada.</source>
        <translation>Comunicazione riattivata.</translation>
    </message>
    <message utf8="true">
        <source>Mensaje de Aviso Nº%1</source>
        <translation>Messaggio di avvisoN°%1</translation>
    </message>
    <message utf8="true">
        <source>No hay batería o la batería falla.</source>
        <translation>Nessuna batteria o batteria guasto.</translation>
    </message>
    <message>
        <source>Iniciando el test de CRA...</source>
        <translation type="obsolete">Avvio del test CRA...</translation>
    </message>
    <message>
        <source>El test CRA ha sido satisfactorio.</source>
        <translation>Il test ha avuto successo CRA.</translation>
    </message>
    <message utf8="true">
        <source>Número de mensaje desconocido %1</source>
        <translation>messaggio sconosciuto %1</translation>
    </message>
    <message>
        <source>Test de CRA...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WarningDialogClass</name>
    <message>
        <source>WarningDialog</source>
        <translation>Worning Dialog</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation>&lt;&lt;</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation>&gt;&gt;</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Cancella</translation>
    </message>
</context>
<context>
    <name>ZoneSelect</name>
    <message>
        <source>luces</source>
        <translation>Luci</translation>
    </message>
    <message>
        <source>clima</source>
        <translation>Clim</translation>
    </message>
    <message>
        <source>dispositivos</source>
        <translation>Dispositivi</translation>
    </message>
    <message>
        <source>persianas</source>
        <translation>Tapparelle</translation>
    </message>
    <message>
        <source>riegos</source>
        <translation>Irrigatori</translation>
    </message>
    <message>
        <source>toldos</source>
        <translation>Tenda da sole</translation>
    </message>
    <message>
        <source>sensores</source>
        <translation>Sensore</translation>
    </message>
    <message>
        <source>cortinas</source>
        <translation>Tenda</translation>
    </message>
    <message>
        <source>puertas</source>
        <translation>Porta</translation>
    </message>
</context>
<context>
    <name>ZoneSelectClass</name>
    <message>
        <source>Form</source>
        <translation></translation>
    </message>
</context>
</TS>
