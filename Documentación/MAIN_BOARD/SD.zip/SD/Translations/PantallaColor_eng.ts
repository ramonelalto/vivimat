<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en">
<context>
    <name>AlarmDialog</name>
    <message utf8="true">
        <source>ALARMA DE INTRUSIÓN</source>
        <translation>INTRUSION ALARM</translation>
    </message>
    <message>
        <source>ALARMA DE FUEGO</source>
        <translation>FIRE ALARM</translation>
    </message>
    <message>
        <source>ALARMA DE GAS</source>
        <translation>GAS ALARM</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE INUNDACIÓN</source>
        <translation>FLOOD ALARM</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE ELÉCTRICO</source>
        <translation>POWER CUT ALARM</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE TELEFÓNICO</source>
        <translation>CUT PHONE LINE ALARM</translation>
    </message>
    <message>
        <source>ALARMA DE SISTEMA</source>
        <translation>SYSTEM ALARM</translation>
    </message>
    <message utf8="true">
        <source>ALARMA MÉDICA</source>
        <translation>MEDICAL ALARM</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE PÁNICO</source>
        <translation>PANIC ALARM</translation>
    </message>
    <message>
        <source>ALARMA SILENCIOSA</source>
        <translation>SILENT ALARM</translation>
    </message>
    <message>
        <source>ALARMA DE SABOTAJE</source>
        <translation>SABOTAGE ALARM</translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE COACCIÓN</source>
        <translation>COERCION ALARM</translation>
    </message>
    <message>
        <source>
 en las siguientes zonas:
</source>
        <translation>
in the follwing zones:</translation>
    </message>
    <message>
        <source>REARMAR ALARMAS</source>
        <translation>REARM ALARMS</translation>
    </message>
    <message>
        <source>Hay alarmas desarmadas. Pulse rearmar para volver a proteger el sistema.</source>
        <translation>There are disabled alarms. Press rearm to protect the system again.</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar alarmas</source>
        <translation>Enter password to disable alarms</translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 90 segundos.</source>
        <translation>System is blocked after three failed attempts.
To re-enter the password wait 90 seconds.</translation>
    </message>
    <message>
        <source>Sistema bloqueado</source>
        <translation>System is locked</translation>
    </message>
</context>
<context>
    <name>AlarmDialogClass</name>
    <message>
        <source>AlarmDialog</source>
        <translation>AlarmDialog</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Disarm</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation>&lt;&lt;</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation>&gt;&gt;</translation>
    </message>
    <message utf8="true">
        <source>Menú
Alarmas</source>
        <translation>Alarm 
Menu</translation>
    </message>
    <message>
        <source>Rearmar</source>
        <translation>Rearm</translation>
    </message>
</context>
<context>
    <name>AlarmsWindow</name>
    <message>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
</context>
<context>
    <name>AlarmsWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation>Fire</translation>
    </message>
    <message>
        <source>Gas</source>
        <translation>Gas</translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation>Flood</translation>
    </message>
    <message utf8="true">
        <source>Corte Eléctrico</source>
        <translation>Power Cut</translation>
    </message>
    <message utf8="true">
        <source>Corte de Teléfono</source>
        <translation>Cut Phone Line</translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation>System</translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation>Medical</translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation>Panic</translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation>Silent</translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation>Sabotage</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation>TextLable</translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation>Coercion</translation>
    </message>
</context>
<context>
    <name>ArmingWindow</name>
    <message>
        <source>Armando...</source>
        <translation type="obsolete">Arming...</translation>
    </message>
</context>
<context>
    <name>ArmingWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:11pt; font-weight:600; color:#ff0000;&quot;&gt;Armando...&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:11pt; font-weight:600; color:#ff0000;&quot;&gt;Arming...&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Armando...</source>
        <translation>Arming...</translation>
    </message>
</context>
<context>
    <name>AssociatedZonesClass</name>
    <message>
        <source>AssociatedZones</source>
        <translation>AssignedZones</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Down</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Up</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message utf8="true">
        <source>Zonas asociadas con la unidad climática...</source>
        <translation>Zones assigned to the climate control unit...</translation>
    </message>
</context>
<context>
    <name>BlackboardWindowClass</name>
    <message>
        <source>BlackboardWindow</source>
        <translation>BlackboardWindow</translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation>Save</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Delete</translation>
    </message>
</context>
<context>
    <name>BlindControl</name>
    <message>
        <source>Ninguno</source>
        <translation>None</translation>
    </message>
    <message>
        <source>Grupo de persianas</source>
        <translation>Blinds group</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Unknown status</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
</context>
<context>
    <name>BlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Assigned program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rename</translation>
    </message>
    <message>
        <source>Bajar persianas en caso de lluvia</source>
        <translation>Close blinds in case of rain</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Opening/Closing time:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Operating mode:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Change icon</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zone</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Device.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>All</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Bajar persianas en caso de viento fuerte</source>
        <translation>Close blind in case of heavy wind</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DOWN</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CRAConfigDialog</name>
    <message>
        <source>ADEMCO CID</source>
        <translation>ADEMCO CID</translation>
    </message>
    <message utf8="true">
        <source>Introduzca el código de abonado ...</source>
        <translation>Enter membership code...</translation>
    </message>
</context>
<context>
    <name>CRAConfigDialogClass</name>
    <message>
        <source>CRAConfigDialog</source>
        <translation>ARCConfigDialog</translation>
    </message>
    <message>
        <source>Configuracion CRA</source>
        <translation>ARC Configuration</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Habilitacion</source>
        <translation>Activation</translation>
    </message>
    <message>
        <source>border: solid;</source>
        <translation type="obsolete">border:solid;</translation>
    </message>
    <message>
        <source>Cambiar
Codigo</source>
        <translation>Change 
code</translation>
    </message>
    <message>
        <source>Protocolo</source>
        <translation>Protocol</translation>
    </message>
    <message>
        <source>Autotest</source>
        <translation>Autotest</translation>
    </message>
    <message>
        <source>Cadencia</source>
        <translation>Cadence</translation>
    </message>
    <message>
        <source>Hora del primer test</source>
        <translation>Time of first test</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:MM</translation>
    </message>
    <message>
        <source>Codigo de cuenta</source>
        <translation>Account code</translation>
    </message>
</context>
<context>
    <name>CamsWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation>Call gate</translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation>Communication with gate established</translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation>Not possible to establish communication because another terminal already answered the call.</translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation>Video Doorphone busy</translation>
    </message>
</context>
<context>
    <name>CamsWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation>Talk</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Open</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation>Vol.Up</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation>Vol.Down</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Up</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Down</translation>
    </message>
    <message>
        <source>Izquierda</source>
        <translation>Left</translation>
    </message>
    <message>
        <source>Derecha</source>
        <translation>Right</translation>
    </message>
</context>
<context>
    <name>ClimaControl</name>
    <message utf8="true">
        <source>Frío</source>
        <translation>Cold</translation>
    </message>
    <message>
        <source>Calor</source>
        <translation>Heat</translation>
    </message>
    <message>
        <source>Climatizador</source>
        <translation>HVAC</translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>None</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name...</translation>
    </message>
</context>
<context>
    <name>ClimaControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Modo general:</source>
        <translation>General mode:</translation>
    </message>
    <message>
        <source>Primer programa asociado:</source>
        <translation>First assigned program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rename</translation>
    </message>
    <message utf8="true">
        <source>Apagar climatización en caso de ventana abierta</source>
        <translation>Turn OFF HVAC in case of an open window</translation>
    </message>
    <message>
        <source>Consig. Min:</source>
        <translation>Min. Ref.:</translation>
    </message>
    <message>
        <source>Consig. Max:</source>
        <translation>Max Ref.:</translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source>Zonas
Asociadas</source>
        <translation>Assigned 
Zones</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Change icon</translation>
    </message>
    <message>
        <source>Sensor de temperatura asociado:</source>
        <translation>Assigned temperature sensor:</translation>
    </message>
    <message>
        <source>Histeresis:</source>
        <translation>Hysteresis:</translation>
    </message>
    <message>
        <source>Segundo programa asociado:</source>
        <translation>Second assigned program:</translation>
    </message>
    <message>
        <source>modo</source>
        <translation>Mode</translation>
    </message>
    <message utf8="true">
        <source>0ºC</source>
        <translation>0ºC</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Device.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>All</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>ClimaWindow</name>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
</context>
<context>
    <name>ClimaWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>MANUAL</source>
        <translation>MANUAL</translation>
    </message>
    <message>
        <source>PROGRAMA</source>
        <translation>PROGRAM</translation>
    </message>
    <message>
        <source>ECO</source>
        <translation>ECO</translation>
    </message>
    <message utf8="true">
        <source>--ºC</source>
        <translation>--ºC</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>--</source>
        <translation>--</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Down</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Up</translation>
    </message>
</context>
<context>
    <name>ConfigWindow</name>
    <message utf8="true">
        <source>Vivimat III

versión %1.%2.%3

[%4]</source>
        <translation>Vivimat III

version %1.%2.%3

[%4]</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión 0.2.0</source>
        <translation type="obsolete">Vision Color 7 

version 0.2.0</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión 0.5.0</source>
        <translation type="obsolete">Vision Color 7 

version 0.5.0</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión 0.6.4</source>
        <translation type="obsolete">Vision Color 7 

version 0.6.4 {7
?}</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión %1.%2.%3</source>
        <translation type="obsolete">Vision Color 7 

Version %1.%2.%3</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión %1.%2.%3
</source>
        <translation>Vision Color 7

version %1.%2.%3</translation>
    </message>
    <message utf8="true">
        <source>Sistema de ficheros

Versión: %1</source>
        <translation>Filesystem

Version:%1</translation>
    </message>
    <message utf8="true">
        <source>Vivimat III

versión Demo %1.%2.%3

[%4]</source>
        <translation>Vivimat III Demo %1.%2.%3[%4]</translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión Demo %1.%2.%3
</source>
        <translation>Vision Color 7 Demo %1.%2.%3</translation>
    </message>
</context>
<context>
    <name>ConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>mando IR</source>
        <translation>IR Remote Control</translation>
    </message>
    <message>
        <source>programas horarios</source>
        <translation>Time Programs</translation>
    </message>
    <message>
        <source>multimedia</source>
        <translation>Multimedia</translation>
    </message>
    <message utf8="true">
        <source>gestión de energía</source>
        <translation>Energy Management</translation>
    </message>
    <message>
        <source>escenas</source>
        <translation>Scenes</translation>
    </message>
    <message utf8="true">
        <source>telefonía</source>
        <translation>Telephony</translation>
    </message>
    <message>
        <source>usuarios</source>
        <translation>Users</translation>
    </message>
    <message>
        <source>sistema</source>
        <translation>System</translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation>Security</translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation>Video Doorphone</translation>
    </message>
    <message>
        <source>fecha y hora</source>
        <translation>Date and Time</translation>
    </message>
    <message>
        <source>pantalla</source>
        <translation>Screen</translation>
    </message>
</context>
<context>
    <name>ConfirmationDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation>ConfirmationWindow</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Accept</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancel</translation>
    </message>
</context>
<context>
    <name>ConsumptionWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Escala</source>
        <translation>Scale</translation>
    </message>
    <message>
        <source>Dia</source>
        <translation>Day</translation>
    </message>
    <message>
        <source>Semana</source>
        <translation>Week</translation>
    </message>
    <message>
        <source>Mes</source>
        <translation>Month</translation>
    </message>
    <message utf8="true">
        <source>Año</source>
        <translation>Year</translation>
    </message>
    <message>
        <source>Unidades</source>
        <translation>Units</translation>
    </message>
    <message>
        <source>Unit1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unit3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CurtainControl</name>
    <message>
        <source>Ninguno</source>
        <translation>None</translation>
    </message>
    <message>
        <source>Grupo de cortinas</source>
        <translation>Curtains group</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Unknown status</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
</context>
<context>
    <name>CurtainControlClass</name>
    <message>
        <source>CurtainControl</source>
        <translation>Curtain Control</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Assigned program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rename</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Operating mode:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Change icon</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Opening/Closing time:</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zone</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Device.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>All</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>DateHourWindow</name>
    <message>
        <source>Lunes</source>
        <translation>MON</translation>
    </message>
    <message>
        <source>Martes</source>
        <translation>TUE</translation>
    </message>
    <message utf8="true">
        <source>Miércoles</source>
        <translation>WED</translation>
    </message>
    <message>
        <source>Jueves</source>
        <translation>THU</translation>
    </message>
    <message>
        <source>Viernes</source>
        <translation>FRI</translation>
    </message>
    <message utf8="true">
        <source>Sábado</source>
        <translation>SAT</translation>
    </message>
    <message>
        <source>Domingo</source>
        <translation>SUN</translation>
    </message>
</context>
<context>
    <name>DateHourWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>/</source>
        <translation>/</translation>
    </message>
    <message>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
</context>
<context>
    <name>DoorControl</name>
    <message>
        <source>Ninguno</source>
        <translation>None</translation>
    </message>
    <message>
        <source>Abierta</source>
        <translation>Open</translation>
    </message>
    <message>
        <source>Cerrada</source>
        <translation>Closed</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Unknown status</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name...</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Open</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
</context>
<context>
    <name>DoorControlClass</name>
    <message>
        <source>DoorControl</source>
        <translation>DoorControl</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Assigned program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rename</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Operating mode:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Change icon</translation>
    </message>
    <message>
        <source>Tiempo de apertura / cierre:</source>
        <translation>Opening/Closing time:</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zone</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Device.</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>All</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Open</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>DoorphoneDialog</name>
    <message>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Accept</translation>
    </message>
    <message>
        <source>Llamada VIDEOPORTERO</source>
        <translation>Door phone call</translation>
    </message>
    <message>
        <source>Llamada desde videoportero</source>
        <translation>Call from door phone</translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation>Call gate</translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation>Communication with gate established</translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation>Not possible to establish communication because another terminal already answered the call.</translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation>Video doorphone busy</translation>
    </message>
    <message>
        <source>Conserje no contesta.</source>
        <translation>The concierge does not answer.</translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación, otra lladama en curso.</source>
        <translation>There is another call, try it later please.</translation>
    </message>
    <message>
        <source>Conserge ocupado</source>
        <translation>Concierge occupied</translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation>Talk</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Open</translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation type="obsolete">Vol.Down.</translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation type="obsolete">Vol.Up.</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Down</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Up</translation>
    </message>
    <message utf8="true">
        <source>Portería</source>
        <translation>Gate</translation>
    </message>
    <message>
        <source>Ver</source>
        <translation>View</translation>
    </message>
</context>
<context>
    <name>EntryphoneConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message utf8="true">
        <source>Habilitar Desvío</source>
        <translation>Enable forwarding</translation>
    </message>
    <message>
        <source>Habilitar Contestador</source>
        <translation>Enable answering machine</translation>
    </message>
    <message utf8="true">
        <source>Contacto al que se desvía la llamada:</source>
        <translation>Contact for call forwarding:</translation>
    </message>
    <message>
        <source>Habilitar llamada desde puerta de entrada</source>
        <translation>Enable call from entrance door</translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation>Personal 
Messages</translation>
    </message>
    <message utf8="true">
        <source>Número de veces que sonara: </source>
        <translation>Number of times bell will ring:</translation>
    </message>
</context>
<context>
    <name>FileTransfer</name>
    <message>
        <source>Aplicacion DEMO para Windows.Simulando la transferencia de ficheros.</source>
        <translation>DEMO application for Windows.Simulating the file transfer.</translation>
    </message>
    <message>
        <source>Se ha encontrado una tarjeta SD.No saque la tarjeta hasta que finalice el intercambio de ficheros.</source>
        <translation>SD card found.Do not take out the SD card until the transfer is finished.</translation>
    </message>
    <message>
        <source>Se ha encontrado un dispositivo USB.No saque el dispositivo hasta que finalice el intercambio de ficheros.</source>
        <translation>USB device found.Do not take out the device until the transfer is finished. </translation>
    </message>
    <message utf8="true">
        <source>No se ha encontrado ningún dispositivo.Pulsa cancelar para salir.</source>
        <translation>No device found.Press cancel to go back.</translation>
    </message>
    <message utf8="true">
        <source>La actualización ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation>The update is finished.Please restart the system.</translation>
    </message>
    <message utf8="true">
        <source>La exportación ha finalizado.Pulsa Aceptar para continuar.</source>
        <translation>The export is finished.Press Accept to continue.</translation>
    </message>
    <message utf8="true">
        <source>La importación ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation>The import is finished.Please restart the system.</translation>
    </message>
    <message>
        <source>No existe un fichero de firmware. Inserte un dispositivo con un fichero de firmware.</source>
        <translation>There is not a firmware file. Insert a device with firmware file on it.</translation>
    </message>
    <message>
        <source>Error a la hora de copiar el nuevo firmware.</source>
        <translation>Error upgradring to a new firmware.</translation>
    </message>
    <message utf8="true">
        <source>La copia del programa de calibración ha fallado.</source>
        <translation type="obsolete">The copy of alibrate copy fail.</translation>
    </message>
    <message utf8="true">
        <source>No se encuentran todos los ficheros necesarios para la actualizacion del servidor web.
No se ha podido realizar la actualización.</source>
        <translation>There are not all the files needed to update Web server.
The update is not completed.</translation>
    </message>
    <message utf8="true">
        <source>La actualización ha fallado. Se mantiene el viejo rcS.</source>
        <translation>The update failed. Maintaining the last rcS file.</translation>
    </message>
    <message>
        <source>cp -rf %1/PantallaColor /App/PantallaColor</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>FileTransferClass</name>
    <message>
        <source>FileTransfer</source>
        <translation>FileTransfer</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Accept</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Restart</translation>
    </message>
</context>
<context>
    <name>FloorSelectClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation>Down</translation>
    </message>
    <message>
        <source>Subir</source>
        <translation>Up</translation>
    </message>
</context>
<context>
    <name>HistoryWindow</name>
    <message>
        <source>Historial de Eventos</source>
        <translation>Event Log</translation>
    </message>
    <message>
        <source>Historial de Errores</source>
        <translation>Error Log</translation>
    </message>
</context>
<context>
    <name>HistoryWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Historial de Eventos</source>
        <translation>Event Log</translation>
    </message>
    <message>
        <source>01/01/2010 13:39:05 &gt; System initialization completed
01/01/2010 13:45:15 &gt; Intrusion alarm armed in total mode: Sergio
01/01/2010 13:50:05 &gt; Intrusion alarm disarmed: Sergio
</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
</context>
<context>
    <name>IRCodeReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Apunte el mando hacia el
receptor y pulse la tecla
correspondiente...</source>
        <translation>Point the remote control 
at the receiver and press 
the corresponding key...</translation>
    </message>
    <message utf8="true">
        <source>Leer código de infrarrojos</source>
        <translation>Read IR code</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindow</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation>Execute Scene</translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation>Perimetric Intrusion Alarm mode</translation>
    </message>
    <message utf8="true">
        <source>Activar pánico</source>
        <translation>Activate panic</translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation>Open video doorphone</translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation>Light ON</translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation>Light OFF</translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation>Increase light level</translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation>Decrease light level</translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation>Motorized device UP</translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation>Motorized device DOWN</translation>
    </message>
    <message>
        <source>Encender clima</source>
        <translation>Climate control ON</translation>
    </message>
    <message>
        <source>Apagar clima</source>
        <translation>Climate control OFF</translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation>Plug ON</translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation>Plug OFF</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Name</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Action</translation>
    </message>
    <message utf8="true">
        <source>Código IR</source>
        <translation>IR Code</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name ...</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la acción.
¿Está seguro?</source>
        <translation>This action will be deleted. 
Do you want to continue?</translation>
    </message>
    <message utf8="true">
        <source>Eliminar acción...</source>
        <translation>Delete action...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Missing data.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <source> - ON/OFF -</source>
        <translation> - ON/OFF -</translation>
    </message>
    <message>
        <source> - Regulable -</source>
        <translation> - Regulable -</translation>
    </message>
    <message>
        <source> - RGB -</source>
        <translation> - RGB -</translation>
    </message>
    <message>
        <source> - Todos los tipos -</source>
        <translation> - All types -</translation>
    </message>
    <message>
        <source> Individual - </source>
        <translation> Individual - </translation>
    </message>
    <message>
        <source> Zona - </source>
        <translation> Zone - </translation>
    </message>
    <message>
        <source> Todas las luces</source>
        <translation> All lights</translation>
    </message>
    <message>
        <source> - Individual - </source>
        <translation> - Individual - </translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation> - ALL HVACs</translation>
    </message>
    <message>
        <source> - Zona - </source>
        <translation> - Zone - </translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation> - All plugs</translation>
    </message>
    <message>
        <source> - Persiana normal -</source>
        <translation> - Blind normal -</translation>
    </message>
    <message>
        <source> - Persiana posicional -</source>
        <translation> - Blind positional -</translation>
    </message>
    <message>
        <source> - Persianas agupadas -</source>
        <translation> - Blinds grouped -</translation>
    </message>
    <message>
        <source> - Cualquier persiana -</source>
        <translation> - Any blind -</translation>
    </message>
    <message>
        <source> - Toldo normal -</source>
        <translation> - Awning normal -</translation>
    </message>
    <message>
        <source> - Toldo posicional -</source>
        <translation> - Awning positional -</translation>
    </message>
    <message>
        <source> - Toldos agupados -</source>
        <translation> - Awnings grouped -</translation>
    </message>
    <message>
        <source> - Cualquier toldo -</source>
        <translation> - Any awning -</translation>
    </message>
    <message>
        <source> - Cortina normal -</source>
        <translation> - Curtain normal -</translation>
    </message>
    <message>
        <source> - Cortina posicional -</source>
        <translation> - Curtain positional -</translation>
    </message>
    <message>
        <source> - Cortinas agupadas -</source>
        <translation> - Curtains grouped -</translation>
    </message>
    <message>
        <source> - Cualquier cortina -</source>
        <translation> - Any curtain -</translation>
    </message>
    <message>
        <source> - Puerta motorizada -</source>
        <translation> - Motorized door -</translation>
    </message>
    <message>
        <source> Todos</source>
        <translation> All</translation>
    </message>
    <message utf8="true">
        <source>Conmutar cámara</source>
        <translation>Change camera</translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Name</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Action</translation>
    </message>
    <message utf8="true">
        <source>Código</source>
        <translation>Code</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialog</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation>Execute Scene</translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation>Intrusion Alarm in Perimetric Mode</translation>
    </message>
    <message utf8="true">
        <source>Activar pánico</source>
        <translation>Activate panic</translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation>Open video doorphone</translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation>Light ON</translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation>Light OFF</translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation>Increase light level</translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation>Decrease light level</translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation>Motorized device UP</translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation>Motorized device DOWN</translation>
    </message>
    <message>
        <source>Encender Clima</source>
        <translation>Climate Control ON</translation>
    </message>
    <message>
        <source>Apagar Clima</source>
        <translation>Climate Control OFF</translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation>Plug ON</translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation>Plug OFF</translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation>Light ON/OFF</translation>
    </message>
    <message>
        <source>Luz regulable</source>
        <translation>Regulable light</translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation>All types</translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation>Individual light</translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation>Lights of the zone</translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation>All lights</translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation>Individual HVAC</translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation>All HVACs</translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation>Individual plug</translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation>Plugs of the zone</translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation>All plugs</translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation>Blind normal</translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation>Blind positional</translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation>Blinds grouped</translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation>Any blind</translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation>Awning normal</translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation>Awning positional</translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation>Awnings grouped</translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation>Any awning</translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation>Curtain normal</translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation>Curtain positional</translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation>Curtains grouped</translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation>Any curtain</translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation>Motorized door</translation>
    </message>
    <message>
        <source>Dispositivo individual</source>
        <translation>Individual device</translation>
    </message>
    <message>
        <source>Dispositivos de la zona</source>
        <translation>Devices of the zone</translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation>All devices</translation>
    </message>
    <message>
        <source>Conmutar camara</source>
        <translation>Change camera</translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message utf8="true">
        <source>Cambiar acción asociada a la tecla</source>
        <translation>Change action assigned to key</translation>
    </message>
    <message utf8="true">
        <source>Acción:</source>
        <translation>Action:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation>Element type:</translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation>Control type:</translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation>Element:</translation>
    </message>
</context>
<context>
    <name>IconChangeDialogClass</name>
    <message>
        <source>IconChangeDialog</source>
        <translation>IconChangeDialog</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Change icon</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
</context>
<context>
    <name>IrrigatorControl</name>
    <message>
        <source>Ninguno</source>
        <translation>None</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>En espera</source>
        <translation>Waiting</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Unknown status</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name ...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
</context>
<context>
    <name>IrrigatorControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Operating mode:</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Assigned program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rename</translation>
    </message>
    <message utf8="true">
        <source>Detener riego en caso de lluvia o suelo ya húmedo</source>
        <translation>Stop irrigation in case of rain or humid soil</translation>
    </message>
    <message>
        <source>Sensor de humedad asociado:</source>
        <translation>Assigned humidity sensor:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Change icon</translation>
    </message>
    <message>
        <source>Duracion del riego (minutos):</source>
        <translation>Time of irrigation (minutes):</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zone</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Device</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>All</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>KeyReadDialog</name>
    <message utf8="true">
        <source>- Código: </source>
        <translation>-Code: </translation>
    </message>
    <message>
        <source>
- Tipo: </source>
        <translation>
-Type: </translation>
    </message>
    <message>
        <source>
- Asignada a: </source>
        <translation>
-Assigned to: </translation>
    </message>
    <message utf8="true">
        <source>Llave desconocida.
- Código: </source>
        <translation>Unknown tag. 
- Code: </translation>
    </message>
</context>
<context>
    <name>KeyReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message utf8="true">
        <source>Acerque la llave
para ser leída</source>
        <translation>Swipe tag in 
order to be read.</translation>
    </message>
    <message>
        <source>Leer llave</source>
        <translation>Read tag</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
</context>
<context>
    <name>KeyRecordDialog</name>
    <message utf8="true">
        <source>El usuario tiene
asociada la llave
con código: </source>
        <translation>The user has
the tag assigned 
to the code: 
</translation>
    </message>
    <message utf8="true">
        <source>No hay espacio
para grabar más llaves</source>
        <translation>No space for 
recording more tags</translation>
    </message>
    <message>
        <source>Acerque la llave
para ser grabada</source>
        <translation>Swipe tag in order 
to be recorded.</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder
a borrar la llave.
¿Está seguro?</source>
        <translation>The tag will
be deleted. 
Are you sure?</translation>
    </message>
    <message>
        <source>La llave ya ha
sido grabada antes.</source>
        <translation>Tag has already 
been recorded.</translation>
    </message>
    <message utf8="true">
        <source>Llave leída.
- Código: </source>
        <translation>Tag read. 
- Code:</translation>
    </message>
</context>
<context>
    <name>KeyRecordDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>El usuario no tiene
llave asociada</source>
        <translation>The user has 
no assigned tag</translation>
    </message>
    <message>
        <source>Grabar llave</source>
        <translation>Record tag</translation>
    </message>
    <message>
        <source>Tipo de llave:</source>
        <translation>Tag type:</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation>&gt;&gt;</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation>&lt;&lt;</translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation>Save</translation>
    </message>
    <message>
        <source>Grabar
llave</source>
        <translation>Record 
tag</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Borrar
llave</source>
        <translation>Delete 
tag</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Accept</translation>
    </message>
</context>
<context>
    <name>KeyboardClass</name>
    <message>
        <source>Keyboad</source>
        <translation>Keyboad</translation>
    </message>
    <message>
        <source>&gt;&gt;&gt;</source>
        <translation>&gt;&gt;&gt;</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Delete</translation>
    </message>
    <message>
        <source>Bloq May</source>
        <translation>Caps Lock</translation>
    </message>
    <message>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <source>U</source>
        <translation>U</translation>
    </message>
    <message>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>W</source>
        <translation>W</translation>
    </message>
    <message>
        <source>I</source>
        <translation>I</translation>
    </message>
    <message>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>T</source>
        <translation>T</translation>
    </message>
    <message>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message utf8="true">
        <source>Ñ</source>
        <translation>Ñ</translation>
    </message>
    <message>
        <source>J</source>
        <translation>J</translation>
    </message>
    <message>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>H</source>
        <translation>H</translation>
    </message>
    <message>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <source>Q</source>
        <translation>Q</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>Z</source>
        <translation>Z</translation>
    </message>
    <message>
        <source>K</source>
        <translation>K</translation>
    </message>
    <message>
        <source>O</source>
        <translation>O</translation>
    </message>
    <message>
        <source>G</source>
        <translation>G</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>N</source>
        <translation>N</translation>
    </message>
    <message utf8="true">
        <source>ó</source>
        <translation>ó</translation>
    </message>
    <message utf8="true">
        <source>é</source>
        <translation>é</translation>
    </message>
    <message utf8="true">
        <source>ş</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ö</source>
        <translation>ö</translation>
    </message>
    <message>
        <source>&apos;</source>
        <translation>&apos;</translation>
    </message>
    <message utf8="true">
        <source>Ó</source>
        <translation>Ó</translation>
    </message>
    <message>
        <source>_</source>
        <translation>_</translation>
    </message>
    <message>
        <source>.</source>
        <translation>.</translation>
    </message>
    <message>
        <source>,</source>
        <translation>,</translation>
    </message>
    <message utf8="true">
        <source>É</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ü</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>á</source>
        <translation></translation>
    </message>
    <message>
        <source>@</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ú</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Í</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Ç</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Ú</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ǧ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Á</source>
        <translation></translation>
    </message>
    <message>
        <source>*</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ç</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>í</source>
        <translation></translation>
    </message>
    <message>
        <source>#</source>
        <translation></translation>
    </message>
    <message>
        <source>-</source>
        <translation></translation>
    </message>
    <message>
        <source>y</source>
        <translation></translation>
    </message>
    <message>
        <source>s</source>
        <translation></translation>
    </message>
    <message>
        <source>f</source>
        <translation></translation>
    </message>
    <message>
        <source>j</source>
        <translation></translation>
    </message>
    <message>
        <source>v</source>
        <translation></translation>
    </message>
    <message>
        <source>t</source>
        <translation></translation>
    </message>
    <message>
        <source>b</source>
        <translation></translation>
    </message>
    <message>
        <source>z</source>
        <translation></translation>
    </message>
    <message>
        <source>c</source>
        <translation></translation>
    </message>
    <message>
        <source>k</source>
        <translation></translation>
    </message>
    <message>
        <source>i</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ñ</source>
        <translation></translation>
    </message>
    <message>
        <source>r</source>
        <translation></translation>
    </message>
    <message>
        <source>g</source>
        <translation></translation>
    </message>
    <message>
        <source>w</source>
        <translation></translation>
    </message>
    <message>
        <source>a</source>
        <translation></translation>
    </message>
    <message>
        <source>x</source>
        <translation></translation>
    </message>
    <message>
        <source>p</source>
        <translation></translation>
    </message>
    <message>
        <source>l</source>
        <translation></translation>
    </message>
    <message>
        <source>m</source>
        <translation></translation>
    </message>
    <message>
        <source>n</source>
        <translation></translation>
    </message>
    <message>
        <source>h</source>
        <translation></translation>
    </message>
    <message>
        <source>u</source>
        <translation></translation>
    </message>
    <message>
        <source>d</source>
        <translation></translation>
    </message>
    <message>
        <source>q</source>
        <translation></translation>
    </message>
    <message>
        <source>o</source>
        <translation></translation>
    </message>
    <message>
        <source>e</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ف</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ى</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ح</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ه</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ا</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ع</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>خ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ي</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>م</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ة</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ض</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ب</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ص</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ت</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ث</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>و</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ش</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ق</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>لا</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ؤ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>س</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ن</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>غ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ك</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ل</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ر</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ئ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ء</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ظ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ز</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>د</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ج</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ط</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٨</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٤</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٣</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٧</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>ذ</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>١</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٢</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٩</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٦</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>٥</source>
        <translation></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
</context>
<context>
    <name>LicenseSystem</name>
    <message>
        <source>Introduzca licencia...</source>
        <translation>Insert license key...</translation>
    </message>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Licencia</source>
        <translation>License</translation>
    </message>
    <message utf8="true">
        <source>La licencia caducará en %1 días. 
Para poder seguir usando el sistema Vivimat III deberá llamar a su instalador para que le proporcione una licencia 
 válida. Deberá indicarle el número de licencia que aparece a continuación para poder activar el sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Número de licencia:</source>
        <translation>License number:</translation>
    </message>
    <message>
        <source>Licencia....</source>
        <translation>Licene...</translation>
    </message>
</context>
<context>
    <name>LightControl</name>
    <message>
        <source>Ninguno</source>
        <translation>None</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Unknown status</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name ...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
    <message>
        <source>Presencia</source>
        <translation>Presence</translation>
    </message>
    <message>
        <source>Crepuscular</source>
        <translation>Twilight</translation>
    </message>
    <message>
        <source>Crep + Pres</source>
        <translation>Twil.+ Pres.</translation>
    </message>
    <message>
        <source>Pres + Prog</source>
        <translation>Pres. + Prog.</translation>
    </message>
</context>
<context>
    <name>LightControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Assigned program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rename</translation>
    </message>
    <message>
        <source>Consigna en modo presencia:</source>
        <translation>Reference in presence mode:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Operating mode:</translation>
    </message>
    <message>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <source>Sensor de presencia asociado:</source>
        <translation>Assigned presence sensor:</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la desactivación:</source>
        <translation>Deactivation delay (sec.):</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Change icon</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Device.</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zone</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>All</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>inicio</source>
        <translation>Home</translation>
    </message>
    <message>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation>Doorphone</translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation>Security</translation>
    </message>
    <message>
        <source>escenas</source>
        <translation>Scenes</translation>
    </message>
    <message>
        <source>mensajes</source>
        <translation>Messages</translation>
    </message>
    <message>
        <source>configurar</source>
        <translation>configure</translation>
    </message>
    <message>
        <source>clima</source>
        <translation>Climate</translation>
    </message>
    <message utf8="true">
        <source>cámaras</source>
        <translation>Cameras</translation>
    </message>
    <message>
        <source>programas</source>
        <translation>Programs</translation>
    </message>
    <message>
        <source>alarmas</source>
        <translation>Alarms</translation>
    </message>
    <message>
        <source>historial</source>
        <translation>Event Log</translation>
    </message>
    <message>
        <source>fotos</source>
        <translation>Photos</translation>
    </message>
    <message>
        <source>pizarra</source>
        <translation>Blackboard</translation>
    </message>
    <message>
        <source>sos</source>
        <translation>SOS</translation>
    </message>
    <message utf8="true">
        <source>No es posible visualizar las cámaras porque ya están siendo visualizadas en otro terminal.</source>
        <translation>It is not possible to display the cameras because they are already displayed on another terminal.</translation>
    </message>
    <message utf8="true">
        <source>Cámaras ocupadas</source>
        <translation>Cameras busy</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar</source>
        <translation>Enter password to disable </translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para menú de seguridad</source>
        <translation>Enter password for the security menu</translation>
    </message>
    <message>
        <source>Antes de poder usar los mensajes de voz es necesario tener grabados los mensajes personales.</source>
        <translation>You need to record personal messages before being able to use the voice messages.</translation>
    </message>
    <message>
        <source>Mensajes personales sin grabar</source>
        <translation>Personal messages not recorded</translation>
    </message>
    <message>
        <source>LUN </source>
        <translation>MON </translation>
    </message>
    <message>
        <source>MAR </source>
        <translation>TUE </translation>
    </message>
    <message>
        <source>MIE </source>
        <translation>WED </translation>
    </message>
    <message>
        <source>JUE </source>
        <translation>THU </translation>
    </message>
    <message>
        <source>VIE </source>
        <translation>FRI </translation>
    </message>
    <message>
        <source>SAB </source>
        <translation>SAT </translation>
    </message>
    <message>
        <source>DOM </source>
        <translation>SUN </translation>
    </message>
    <message>
        <source>dd/MM/yyyy</source>
        <translation>MM/dd/yyyy</translation>
    </message>
    <message utf8="true">
        <source>INT %1 ºC</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Los ficheros de configuración no coinciden.
Para sobreescribir los ficheros de la central en la pantalla pulsa Aceptar. En caso contrario, pulsa Cancelar.</source>
        <translation>Configuration files are different. 
In order to overwrite the files of the central unit on the screen press Accept. Otherwise press Cancel.</translation>
    </message>
    <message utf8="true">
        <source>Actualizar configuración</source>
        <translation>Update configuration</translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código IR:
%1 %2 %3</source>
        <translation>The IR code has been read: 
%1 %2 %3</translation>
    </message>
    <message utf8="true">
        <source>Código IR leído</source>
        <translation>IR code read</translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código RFID:
%1 %2 %3 %4</source>
        <translation>The IR code has been read: 
%1 %2 %3 %4</translation>
    </message>
    <message utf8="true">
        <source>Llave leída</source>
        <translation>Tag read</translation>
    </message>
    <message utf8="true">
        <source>El idioma del sistema ha sido modificado.
¿Desea reiniciar la pantalla?</source>
        <translation>The system language has been changed. 
Do you want to restart the screen?</translation>
    </message>
    <message>
        <source>Actualizar idioma...</source>
        <translation>Update language...</translation>
    </message>
    <message utf8="true">
        <source>Cerrar sesión</source>
        <translation>Log out</translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 30 segundos.</source>
        <translation type="obsolete">System is blocked after three failed attempts.
To re-enter the password wait 30 seconds.</translation>
    </message>
    <message>
        <source>Sistema bloqueado</source>
        <translation>System is locked</translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 90 segundos.</source>
        <translation>System is blocked after three failed attempts.
To re-enter the password wait 90 seconds.</translation>
    </message>
</context>
<context>
    <name>MainWindowClass</name>
    <message>
        <source>MainWindow</source>
        <translation>MainWindow</translation>
    </message>
    <message>
        <source>12:30</source>
        <translation>12:30</translation>
    </message>
    <message>
        <source>MAR 15/11/2009</source>
        <translation>TUE 15/11/2009</translation>
    </message>
    <message utf8="true">
        <source>INT 18ºC</source>
        <translation>TEMP 18ºC</translation>
    </message>
    <message>
        <source>T</source>
        <translation type="obsolete">T</translation>
    </message>
    <message>
        <source>LL</source>
        <translation>LL</translation>
    </message>
</context>
<context>
    <name>MessageDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation>ConfirmationWindow</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Accept</translation>
    </message>
</context>
<context>
    <name>MessagesWindow</name>
    <message>
        <source>Tipo</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Origen</source>
        <translation>Origin</translation>
    </message>
    <message>
        <source>Fecha/Hora</source>
        <translation>Date/Time</translation>
    </message>
    <message>
        <source>Videoportero</source>
        <translation>Video Doorphone</translation>
    </message>
    <message>
        <source>Terminal 1</source>
        <translation>Terminal 1</translation>
    </message>
    <message>
        <source>Terminal 2</source>
        <translation>Terminal 2</translation>
    </message>
    <message>
        <source>Terminal 3</source>
        <translation>Terminal 3</translation>
    </message>
    <message>
        <source>Desconocido</source>
        <translation>Unknown</translation>
    </message>
    <message>
        <source>Voz</source>
        <translation>Voice</translation>
    </message>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>It is not possible to record the message, the voice messages are already in use.</translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation>Voice messages in use</translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation>Recording message...</translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>It is not possible to play the message, the voice messages are already in use.</translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation>Playing message...</translation>
    </message>
    <message utf8="true">
        <source>No es posible borrar los mensajes, los mensajes de voz ya están siendo usados.</source>
        <translation>It is not possible to delete the messages, the voice messages are already in use.</translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation>All messages will be deleted. 
Are you sure?</translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation>Delete messages...</translation>
    </message>
</context>
<context>
    <name>MessagesWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Grabar
mensaje</source>
        <translation>Record 
message</translation>
    </message>
    <message>
        <source>Borrar
mensajes</source>
        <translation>Delete 
message</translation>
    </message>
</context>
<context>
    <name>MsgProgressDialogClass</name>
    <message>
        <source>RecWindow</source>
        <translation>RecWindow</translation>
    </message>
    <message>
        <source>Parar</source>
        <translation>Stop</translation>
    </message>
</context>
<context>
    <name>PasswordClass</name>
    <message>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para continuar...</source>
        <translation>Enter password to continue...</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Delete</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialog</name>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>It is not possible to record the message, the voice messages are already in use.</translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation>Voice messages in use</translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation>All messages will be deleted. 
Are you sure?</translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation>Delete messages...</translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation>Recording message...</translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation>It is not possible to play the message, the voice messages are already in use.</translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation>Playing message...</translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation>ConfirmationWindow</translation>
    </message>
    <message>
        <source>Mensajes de voz personalizados</source>
        <translation>Personalized voice messages</translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation>Accept</translation>
    </message>
    <message>
        <source>Mensaje para llamadas de alarma</source>
        <translation>Message for alarm calls</translation>
    </message>
    <message>
        <source>Reproducir</source>
        <translation>Play</translation>
    </message>
    <message>
        <source>Grabar</source>
        <translation>Record</translation>
    </message>
    <message>
        <source>Mensaje para contestador de videoportero</source>
        <translation>Message for answering the video doorphone</translation>
    </message>
    <message utf8="true">
        <source>Para grabar los mensajes de voz personalizados primero se borraran todos los mensajes, después se grabará el mensaje para llamadas de alarma y a continuación el mensaje para contestador de videoportero.</source>
        <translation>In order to record personalized voice messages delete first all messages, then record the message for alarm calls and afterwards the message for answering the video doorphone.</translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindow</name>
    <message>
        <source>Tipo</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Name</translation>
    </message>
    <message utf8="true">
        <source>Número</source>
        <translation>Number</translation>
    </message>
    <message>
        <source>TEL</source>
        <translation>TEL</translation>
    </message>
    <message>
        <source>SMS</source>
        <translation>SMS</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>CRA</source>
        <translation>ARC</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name ...</translation>
    </message>
    <message>
        <source>Es necesario introducir primero el tipo de contacto.</source>
        <translation>Please enter the type of contact first.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message utf8="true">
        <source>Introduzca nuevo número o dirección de correo ...</source>
        <translation>Enter new number or e-mail address ...</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el contacto.
¿Está seguro?</source>
        <translation>Contact will be deleted.
Are you sure?</translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation>Delete contact...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Missing data.</translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindowClass</name>
    <message>
        <source>PhoneConfigWindow</source>
        <translation>PhoneConfigWindow</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Habilitar avisos</source>
        <translation>Enable alerts</translation>
    </message>
    <message>
        <source>Habilitar telecontrol</source>
        <translation>Enable telecontrol</translation>
    </message>
    <message>
        <source>Tonos</source>
        <translation>Tones</translation>
    </message>
    <message>
        <source>Configurar
CRA</source>
        <translation>Configure 
ARC</translation>
    </message>
</context>
<context>
    <name>PhotosWindow</name>
    <message>
        <source>Marco de fotos</source>
        <translation>Photo frame</translation>
    </message>
    <message>
        <source>No hay fotos disponibles.</source>
        <translation>No images available.</translation>
    </message>
    <message>
        <source>Reducir la resolucion de la imagen para su correcta visualizacion.</source>
        <translation type="obsolete">Reduce the resolution of images to see them properly.</translation>
    </message>
    <message>
        <source>No se puede mostrar la foto (%1).</source>
        <translation>Unable to display image (%1)</translation>
    </message>
</context>
<context>
    <name>PlugControl</name>
    <message>
        <source>Ninguno</source>
        <translation>None</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Unknown status</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name ...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
</context>
<context>
    <name>PlugControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Operating mode:</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Assigned program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rename</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Change icon</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zone</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Device</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>All</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>salida temporizada </source>
        <translation>Timered out</translation>
    </message>
    <message>
        <source>segundos</source>
        <translation>seconds</translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindow</name>
    <message>
        <source>Temperatura</source>
        <translation>Temperature</translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation>0-100%</translation>
    </message>
    <message>
        <source>ON-OFF</source>
        <translation>ON-OFF</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name ...</translation>
    </message>
    <message utf8="true">
        <source>Las franjas horarias no están bien definidas.</source>
        <translation>Time slots are not well defined.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>0 = OFF</source>
        <translation>0 = OFF</translation>
    </message>
    <message>
        <source>1 = ON</source>
        <translation>1 = ON</translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rename</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message utf8="true">
        <source>Días de ejecución:</source>
        <translation>Working days:</translation>
    </message>
    <message>
        <source>L</source>
        <translation>M</translation>
    </message>
    <message>
        <source>M</source>
        <translation>T</translation>
    </message>
    <message>
        <source>X</source>
        <translation>W</translation>
    </message>
    <message>
        <source>J</source>
        <translation>T</translation>
    </message>
    <message>
        <source>V</source>
        <translation>F</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>D</source>
        <translation>S</translation>
    </message>
    <message>
        <source>Fin</source>
        <translation>End</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:MM</translation>
    </message>
    <message>
        <source>Inicio</source>
        <translation>Start</translation>
    </message>
    <message>
        <source>Consigna</source>
        <translation>Reference</translation>
    </message>
    <message>
        <source>Franja 1:</source>
        <translation>Slot 1:</translation>
    </message>
    <message>
        <source>Franja 2:</source>
        <translation>Slot 2:</translation>
    </message>
    <message>
        <source>Franja 3:</source>
        <translation>Slot 3:</translation>
    </message>
    <message>
        <source>Franja 4:</source>
        <translation>Slot 4:</translation>
    </message>
    <message>
        <source>Franja 5:</source>
        <translation>Slot 5:</translation>
    </message>
</context>
<context>
    <name>ProgramsWindow</name>
    <message>
        <source>Nombre</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>L</source>
        <translation>M</translation>
    </message>
    <message>
        <source>M</source>
        <translation>T</translation>
    </message>
    <message>
        <source>X</source>
        <translation>W</translation>
    </message>
    <message>
        <source>J</source>
        <translation>T</translation>
    </message>
    <message>
        <source>V</source>
        <translation>F</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>D</source>
        <translation>S</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>Temperatura</source>
        <translation>Temperature</translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation>0-100%</translation>
    </message>
    <message>
        <source>ON/OFF</source>
        <translation>ON/OFF</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el programa.
¿Está seguro?</source>
        <translation>The program will be deleted.
Are you sure?</translation>
    </message>
    <message>
        <source>Eliminar programa...</source>
        <translation>Delete program...</translation>
    </message>
</context>
<context>
    <name>ProgramsWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>L</source>
        <translation>M</translation>
    </message>
    <message>
        <source>M</source>
        <translation>T</translation>
    </message>
    <message>
        <source>X</source>
        <translation>W</translation>
    </message>
    <message>
        <source>J</source>
        <translation>T</translation>
    </message>
    <message>
        <source>V</source>
        <translation>F</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>D</source>
        <translation>S</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
</context>
<context>
    <name>RBlindControl</name>
    <message>
        <source>Ninguno</source>
        <translation>None</translation>
    </message>
    <message>
        <source>Grupo de toldos</source>
        <translation>Awning group</translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation>Unknown status</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name ...</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <source>Programa</source>
        <translation>Program</translation>
    </message>
</context>
<context>
    <name>RBlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation>PruebaStacked</translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation>Assigned program:</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rename</translation>
    </message>
    <message>
        <source>Plegar toldos en caso de viento fuerte</source>
        <translation>Fold awinings in case of strong wind</translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation>Opening/Closing time:</translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation>Operating mode:</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation>Change icon</translation>
    </message>
    <message>
        <source>zona</source>
        <translation>Zone</translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation>Device</translation>
    </message>
    <message>
        <source>todos</source>
        <translation>All</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Plegar toldos en caso de lluvia</source>
        <translation>Fold awinings in case of rain</translation>
    </message>
</context>
<context>
    <name>SOSWindow</name>
    <message utf8="true">
        <source>Alarma de pánico deshabilitada</source>
        <translation>Panic alarm disabled</translation>
    </message>
</context>
<context>
    <name>SOSWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>SOS</source>
        <translation></translation>
    </message>
    <message>
        <source>STOP</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SceneConditionDialog</name>
    <message>
        <source>Sin condicionar</source>
        <translation>Unconditioned</translation>
    </message>
    <message>
        <source>Cualquier llave</source>
        <translation>Any tag</translation>
    </message>
    <message>
        <source>Llave tipo A</source>
        <translation>Tag type A</translation>
    </message>
    <message>
        <source>Llave tipo B</source>
        <translation>Tag type B</translation>
    </message>
    <message>
        <source>Llave tipo C</source>
        <translation>Tag type C</translation>
    </message>
    <message>
        <source>Llave tipo D</source>
        <translation>Tag type D</translation>
    </message>
    <message>
        <source>Llave tipo E</source>
        <translation>Tag type E</translation>
    </message>
    <message>
        <source>Llave tipo F</source>
        <translation>Tag type F</translation>
    </message>
    <message>
        <source>Llave: </source>
        <translation>Tag: </translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation>Date</translation>
    </message>
    <message utf8="true">
        <source>Día semana</source>
        <translation>Weekday</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión armada</source>
        <translation>Intrusion alarm enabled</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión desarmada</source>
        <translation>Intrusion alarm disabled</translation>
    </message>
    <message utf8="true">
        <source>Activación de cualquier alarma</source>
        <translation>Ativation any alarm</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de intrusión</source>
        <translation>Activation intrusion alarm</translation>
    </message>
    <message>
        <source>Act. alm. de fuego</source>
        <translation>Activation fire alarm</translation>
    </message>
    <message>
        <source>Act. alm. de gas</source>
        <translation>Activation gas alarm</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de inundación</source>
        <translation>Activation flood alarm</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de corte eléc.</source>
        <translation>Activation cut phone line alarm.</translation>
    </message>
    <message>
        <source>Act. alm. de corte tlf.</source>
        <translation>Activation cut phone line alarm.</translation>
    </message>
    <message>
        <source>Act. alm. de sistema</source>
        <translation>Activation system alarm</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. médica</source>
        <translation>Activation medical alarm</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de pánico</source>
        <translation>Activation panic alarm</translation>
    </message>
    <message>
        <source>Act. alm. silenciosa</source>
        <translation>Activation silent alarm</translation>
    </message>
    <message>
        <source>Act. alm. de sabotaje</source>
        <translation>Activation sabotage alarm</translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de coacción</source>
        <translation>Activation coercion alarm</translation>
    </message>
    <message>
        <source>Entrada en Central</source>
        <translation>Input of central unit</translation>
    </message>
    <message>
        <source>Entrada en MOD0035</source>
        <translation>Input of MOD-0035</translation>
    </message>
    <message>
        <source>Intrusion en armado total</source>
        <translation>Intrusion armed in total mode</translation>
    </message>
    <message>
        <source>Intrusion en armado perimetral</source>
        <translation>Intrusion armed in perimetral mode</translation>
    </message>
    <message>
        <source>Intrusion en armado parcial</source>
        <translation>Intrusion armed in perimetral mode</translation>
    </message>
</context>
<context>
    <name>SceneConditionDialogClass</name>
    <message>
        <source>EventConditionWindow</source>
        <translation>EventConditionWindow</translation>
    </message>
    <message>
        <source>Condiciones</source>
        <translation>Conditions</translation>
    </message>
    <message>
        <source>Condicion de llave:</source>
        <translation>Tag condition:</translation>
    </message>
    <message>
        <source>Condicion de hora:</source>
        <translation>Time condition:</translation>
    </message>
    <message>
        <source>Condicion de Fecha / Dia semana:</source>
        <translation>Date / weekday condition:</translation>
    </message>
    <message>
        <source>Condicion de alarma:</source>
        <translation>Alarm condition:</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:MM</translation>
    </message>
    <message>
        <source>L</source>
        <translation>M</translation>
    </message>
    <message>
        <source>V</source>
        <translation>F</translation>
    </message>
    <message>
        <source>X</source>
        <translation>W</translation>
    </message>
    <message>
        <source>D</source>
        <translation>S</translation>
    </message>
    <message>
        <source>M</source>
        <translation>T</translation>
    </message>
    <message>
        <source>J</source>
        <translation>T</translation>
    </message>
    <message>
        <source>S</source>
        <translation>S</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Condicion de entrada:</source>
        <translation>Input condition:</translation>
    </message>
    <message>
        <source>Tipo de modulo:</source>
        <translation>Module type:</translation>
    </message>
    <message>
        <source>E/S:</source>
        <translation>I/O:</translation>
    </message>
    <message>
        <source>Mod:</source>
        <translation>MOD:</translation>
    </message>
</context>
<context>
    <name>SceneEventWindow</name>
    <message utf8="true">
        <source>Iluminación</source>
        <translation>Illumination</translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation>Motorized device</translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation>Plug</translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation>Climate </translation>
    </message>
    <message>
        <source>Riego</source>
        <translation>Irrigation</translation>
    </message>
    <message>
        <source>Retardo</source>
        <translation>Delay</translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation>Security</translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation>Individual light</translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation>Lights of the zone</translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation>All lights</translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation>Light ON/OFF</translation>
    </message>
    <message>
        <source>Luz Regulable</source>
        <translation>Regulable light</translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation>All types</translation>
    </message>
    <message>
        <source>0%</source>
        <translation>0%</translation>
    </message>
    <message>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <source>20%</source>
        <translation>20%</translation>
    </message>
    <message>
        <source>40%</source>
        <translation>40%</translation>
    </message>
    <message>
        <source>60%</source>
        <translation>60%</translation>
    </message>
    <message>
        <source>80%</source>
        <translation>80%</translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation>Individual plug</translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation>Plugs of the zone</translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation>All plugs</translation>
    </message>
    <message>
        <source>Encender</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>Apagar</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation>Individual HVAC</translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation>All HVACs</translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>Modo manual</source>
        <translation>Manual mode</translation>
    </message>
    <message>
        <source>Modo programa</source>
        <translation>Program mode</translation>
    </message>
    <message utf8="true">
        <source>Modo económico</source>
        <translation>ECO mode</translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation>%1ºC</translation>
    </message>
    <message>
        <source>Riego individual</source>
        <translation>Individual irrigation</translation>
    </message>
    <message>
        <source>Riegos de la zona</source>
        <translation>Irrigations of zone</translation>
    </message>
    <message>
        <source>Todos los riegos</source>
        <translation>All irrigations</translation>
    </message>
    <message>
        <source>Activar</source>
        <translation>Activate</translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation>Deactivate</translation>
    </message>
    <message>
        <source>1 seg</source>
        <translation>1 sec.</translation>
    </message>
    <message>
        <source>3 seg</source>
        <translation>3 sec.</translation>
    </message>
    <message>
        <source>5 seg</source>
        <translation>5 sec.</translation>
    </message>
    <message>
        <source>10 seg</source>
        <translation>10 sec.</translation>
    </message>
    <message>
        <source>20 seg</source>
        <translation>20 sec.</translation>
    </message>
    <message>
        <source>30 seg</source>
        <translation>30 sec.</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation>Intrusion alarm</translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation>Fire alarm</translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation>Gas alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation>Flood alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation>Power cut alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte telefónico</source>
        <translation>Cut phone line alarm</translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation>System alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation>Medical alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation>Panic alarm</translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation>Silent alarm</translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation>Sabotage alarm</translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation>Enable in perimetric mode</translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation>Enable in partial mode</translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation>Enable in total mode</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Disable</translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation>Disable partially</translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation>Activate alarm</translation>
    </message>
    <message>
        <source>Dis. individual</source>
        <translation>Ind. device</translation>
    </message>
    <message>
        <source>Dis. de la zona</source>
        <translation>Dev. of  zone</translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation>All devices</translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation>Blind normal</translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation>Blind positional</translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation>Blinds grouped</translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation>Any blind</translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation>Awning normal</translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation>Awning positional</translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation>Awnings grouped</translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation>Any awning</translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation>Curtain normal</translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation>Curtain positional</translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation>Curtains grouped</translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation>Any curtain</translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation>Motorized door</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation>Open</translation>
    </message>
    <message>
        <source>Enchufe normal</source>
        <translation>Normal Device</translation>
    </message>
    <message>
        <source>Enchufes temporizados</source>
        <translation>Time device</translation>
    </message>
</context>
<context>
    <name>SceneEventWindowClass</name>
    <message>
        <source>SceneEventWindow</source>
        <translation>SceneEventWindow</translation>
    </message>
    <message>
        <source>Modificar evento</source>
        <translation>Modify event</translation>
    </message>
    <message>
        <source>Tipo de evento:</source>
        <translation>Event type:</translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation>Control type:</translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation>Element type:</translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation>Element:</translation>
    </message>
    <message>
        <source>Valor:</source>
        <translation>Value:</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindow</name>
    <message>
        <source>Evento</source>
        <translation>Event</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el evento.
¿Está seguro?</source>
        <translation>Element will be deleted. 
Are you sure?</translation>
    </message>
    <message>
        <source>Eliminar evento...</source>
        <translation>Delete event...</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name ...</translation>
    </message>
    <message utf8="true">
        <source>Iluminación</source>
        <translation>Illumination</translation>
    </message>
    <message>
        <source> - ON/OFF</source>
        <translation> - ON/OFF-</translation>
    </message>
    <message>
        <source> - Regulable</source>
        <translation> - Regulable</translation>
    </message>
    <message>
        <source> - RGB</source>
        <translation> - RGB</translation>
    </message>
    <message>
        <source> - Todos los tipos</source>
        <translation> - All types</translation>
    </message>
    <message>
        <source> - Individual: </source>
        <translation> - Individual: </translation>
    </message>
    <message>
        <source> - Zona: </source>
        <translation> - Zone: </translation>
    </message>
    <message>
        <source> - Todas las luces</source>
        <translation> - All lights</translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation>Motorized device</translation>
    </message>
    <message>
        <source> - Persiana normal</source>
        <translation> - Blind normal</translation>
    </message>
    <message>
        <source> - Persiana posicional</source>
        <translation> - Blind positional</translation>
    </message>
    <message>
        <source> - Persianas agupadas</source>
        <translation> - Blinds grouped</translation>
    </message>
    <message>
        <source> - Cualquier persiana</source>
        <translation> - Any blind</translation>
    </message>
    <message>
        <source> - Toldo normal</source>
        <translation> - Awning normal</translation>
    </message>
    <message>
        <source> - Toldo posicional</source>
        <translation> - Awning positional</translation>
    </message>
    <message>
        <source> - Toldos agupados</source>
        <translation> - Awnings grouped</translation>
    </message>
    <message>
        <source> - Cualquier toldo</source>
        <translation> - Any awning</translation>
    </message>
    <message>
        <source> - Cortina normal</source>
        <translation> - Curtain normal</translation>
    </message>
    <message>
        <source> - Cortina posicional</source>
        <translation> - Curtain positional</translation>
    </message>
    <message>
        <source> - Cortinas agupadas</source>
        <translation> - Curtains grouped</translation>
    </message>
    <message>
        <source> - Cualquier cortina</source>
        <translation> - Any courtain</translation>
    </message>
    <message>
        <source> - Puerta motorizada</source>
        <translation> - Motorized door</translation>
    </message>
    <message>
        <source> - Todos los dispositivos</source>
        <translation> - All devices</translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation>Plug</translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation> - All plugs</translation>
    </message>
    <message>
        <source> - Encender</source>
        <translation> - ON</translation>
    </message>
    <message>
        <source> - Apagar</source>
        <translation> - OFF</translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation>Climate</translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation> - ALL HVACs</translation>
    </message>
    <message>
        <source> - Apagado</source>
        <translation> - OFF</translation>
    </message>
    <message>
        <source> - Modo manual - </source>
        <translation> - Manual mode - </translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation>ºC</translation>
    </message>
    <message>
        <source> - Modo programa</source>
        <translation> - Program mode</translation>
    </message>
    <message utf8="true">
        <source> - Modo económico - </source>
        <translation> - Eco mode - </translation>
    </message>
    <message>
        <source>Riego</source>
        <translation>Irrigation</translation>
    </message>
    <message>
        <source> - Todos los riegos</source>
        <translation> - All irrigations</translation>
    </message>
    <message>
        <source> - Activar</source>
        <translation> - Activate</translation>
    </message>
    <message>
        <source> - Desactivar</source>
        <translation> - Deactivate</translation>
    </message>
    <message>
        <source>Retardo - </source>
        <translation>Delay - </translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation>Security</translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation>Intrusion alarm</translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation>Fire alarm</translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation>Gas alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation>Flood alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation>Power cut alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte de teléfono</source>
        <translation>Cut phone line alarm</translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation>System alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation>Medical alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation>Panic alarm</translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation>Silent alarm</translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation>Sabotage alarm</translation>
    </message>
    <message utf8="true">
        <source>Alarma de coacción</source>
        <translation>Coercion alarm</translation>
    </message>
    <message>
        <source>Deshabilitar alarma</source>
        <translation>Disable alarm</translation>
    </message>
    <message>
        <source>Habilitar alarma</source>
        <translation>Enable alarm</translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation>Activate alarm</translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation>Enable in perimetric mode</translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation>Enable in partial mode</translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation>Enable in total mode</translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation>Disable</translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation>Disable partially</translation>
    </message>
    <message>
        <source> - Todos </source>
        <translation>- All</translation>
    </message>
    <message>
        <source> - Temporizados </source>
        <translation type="obsolete">- Timed</translation>
    </message>
    <message>
        <source> - No temporizados</source>
        <translation>- Not Timed</translation>
    </message>
    <message>
        <source> - Temporizados</source>
        <translation>Timed</translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindowClass</name>
    <message>
        <source>ScenesConfigWindow</source>
        <translation>ScenesConfigWindow</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rename</translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindow</name>
    <message>
        <source>Nombre</source>
        <translation>Name</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la escena.
¿Está seguro?</source>
        <translation>Scene will be deleted.
Are you sure?</translation>
    </message>
    <message>
        <source>Eliminar escena...</source>
        <translation>Delete scene...</translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
</context>
<context>
    <name>ScenesWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindow</name>
    <message>
        <source>Castellano</source>
        <translation>Spanish</translation>
    </message>
    <message utf8="true">
        <source>Inglés</source>
        <translation>English</translation>
    </message>
    <message utf8="true">
        <source>Portugués</source>
        <translation>Portuguese</translation>
    </message>
    <message utf8="true">
        <source>Francés</source>
        <translation>French</translation>
    </message>
    <message utf8="true">
        <source>Alemán</source>
        <translation>German</translation>
    </message>
    <message>
        <source>Euskera</source>
        <translation>Basque</translation>
    </message>
    <message utf8="true">
        <source>Catalán</source>
        <translation>Catalan</translation>
    </message>
    <message>
        <source>Gallego</source>
        <translation>Galician</translation>
    </message>
    <message>
        <source>Turco</source>
        <translation>Turkish</translation>
    </message>
    <message>
        <source>Italiano</source>
        <translation>Italian</translation>
    </message>
    <message utf8="true">
        <source>Árabe</source>
        <translation>Arabic</translation>
    </message>
    <message>
        <source>0 %</source>
        <translation>0%</translation>
    </message>
    <message>
        <source>20 %</source>
        <translation>20%</translation>
    </message>
    <message>
        <source>40 %</source>
        <translation>40%</translation>
    </message>
    <message>
        <source>60 %</source>
        <translation>60%</translation>
    </message>
    <message>
        <source>80 %</source>
        <translation>80%</translation>
    </message>
    <message>
        <source>100 %</source>
        <translation>100%</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation type="obsolete">Dark</translation>
    </message>
    <message>
        <source>Green</source>
        <translation type="obsolete">Green</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>Orange</translation>
    </message>
    <message>
        <source>Azul</source>
        <translation>Blue</translation>
    </message>
    <message>
        <source>Negro</source>
        <translation>Black</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation>Green</translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation>Red</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>None</translation>
    </message>
    <message>
        <source>Marco de fotos digital</source>
        <translation>Digital photo frame</translation>
    </message>
    <message>
        <source>1 minuto</source>
        <translation>1 minute</translation>
    </message>
    <message>
        <source>2 minuto</source>
        <translation>2 minutes</translation>
    </message>
    <message>
        <source>5 minuto</source>
        <translation>5 minutes</translation>
    </message>
    <message>
        <source>10 minuto</source>
        <translation>10 minutes</translation>
    </message>
    <message>
        <source>15 minuto</source>
        <translation>15 minutes</translation>
    </message>
    <message>
        <source>30 minuto</source>
        <translation>30 minutes</translation>
    </message>
    <message>
        <source>Nunca</source>
        <translation>Never</translation>
    </message>
    <message utf8="true">
        <source>Botón</source>
        <translation>Key</translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation>Action</translation>
    </message>
    <message>
        <source>Oscuro</source>
        <translation>Dark</translation>
    </message>
    <message>
        <source>(vacio)</source>
        <translation>(empty)</translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source> Identificador de pantalla</source>
        <translation>Screen identifier</translation>
    </message>
    <message>
        <source> Idioma</source>
        <translation> Language</translation>
    </message>
    <message>
        <source> Volumen</source>
        <translation> Volume</translation>
    </message>
    <message>
        <source> Brillo</source>
        <translation type="obsolete"> Brightness</translation>
    </message>
    <message>
        <source>Sonido teclado</source>
        <translation>Keyboard sound</translation>
    </message>
    <message>
        <source>Sensor de presencia</source>
        <translation>Presence sensor</translation>
    </message>
    <message>
        <source> Paleta</source>
        <translation> Color palette</translation>
    </message>
    <message>
        <source> Color iconos</source>
        <translation> Icon color</translation>
    </message>
    <message>
        <source>Offset de temperatura</source>
        <translation>Temperature offset</translation>
    </message>
    <message>
        <source>Visualizar cursor</source>
        <translation>Display cursor</translation>
    </message>
    <message>
        <source>Salvapantallas</source>
        <translation>Screensaver</translation>
    </message>
    <message>
        <source> Salvapantallas</source>
        <translation> Screensaver</translation>
    </message>
    <message utf8="true">
        <source> Activación Salvapantallas</source>
        <translation> Screensaver activation</translation>
    </message>
    <message>
        <source> Tiempo entre fotos</source>
        <translation> Time between photos</translation>
    </message>
    <message>
        <source> Autoapagado</source>
        <translation> Auto turn OFF</translation>
    </message>
    <message>
        <source>Botones</source>
        <translation>Buttons</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para ejecutar escenas</source>
        <translation>Ask for password to execute scenes</translation>
    </message>
    <message utf8="true">
        <source>Habilitación tamper</source>
        <translation>Tamper enabled</translation>
    </message>
    <message>
        <source>IP</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindow</name>
    <message>
        <source>Armado total</source>
        <translation>Totally armed</translation>
    </message>
    <message>
        <source>Armado parcial</source>
        <translation>Partially armed</translation>
    </message>
    <message>
        <source>Armado perimetral</source>
        <translation>Perimetrically armed</translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation>None</translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message utf8="true">
        <source>Intrusión</source>
        <translation>Intrusion</translation>
    </message>
    <message utf8="true">
        <source>Habilitar autoarmado de intrusión</source>
        <translation>Enable intrusion self arming</translation>
    </message>
    <message>
        <source>Programa asociado el autoarmado</source>
        <translation>Program assigned to self arming</translation>
    </message>
    <message utf8="true">
        <source>Activar simulación de presencia con el armado total</source>
        <translation>Activate presence simulation with total armed mode</translation>
    </message>
    <message>
        <source>Tiempo de salida de la vivienda (seg):</source>
        <translation>Time for leaving the houseing (sec.):</translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para armar la alarma de intrusión</source>
        <translation>Request password for enabling the intrusion alarm</translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation>Fire</translation>
    </message>
    <message>
        <source>Gas</source>
        <translation>Gas</translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation>Flood</translation>
    </message>
    <message utf8="true">
        <source>Hora de auto limpieza de la electroválvula de agua:</source>
        <translation>Time of self cleaning of the water solenoid valve:</translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation>H:MM</translation>
    </message>
    <message utf8="true">
        <source>Corte Red Eléctrica</source>
        <translation>Power Cut</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (min):</source>
        <translation>Activation delay (min.):</translation>
    </message>
    <message utf8="true">
        <source>Corte teléfono</source>
        <translation>Cut Phone Line</translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation>System</translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation>Medical</translation>
    </message>
    <message utf8="true">
        <source>Detección de inactividad</source>
        <translation>Detection of inactivity</translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation>Panic</translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation>Silent</translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation>Sabotage</translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation>Coercion</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Llamar en caso de alarma a:</source>
        <translation>In case of alarm call to:</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 1</source>
        <translation>Phone 1</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 2</source>
        <translation>Phone 2</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 3</source>
        <translation>Phone 3</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 4</source>
        <translation>Phone 4</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 5</source>
        <translation>Phone 5</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 6</source>
        <translation>Phone 6</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 7</source>
        <translation>Phone 7</translation>
    </message>
    <message utf8="true">
        <source>Teléfono 8</source>
        <translation>Phone 8</translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation>Personal 
Messages</translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (seg):</source>
        <translation>Activation delay (sec):</translation>
    </message>
</context>
<context>
    <name>SecurityWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Armado Perimetral</source>
        <translation>Perimetrically Armed</translation>
    </message>
    <message>
        <source>Armado Parcial</source>
        <translation>Partially Armed</translation>
    </message>
    <message>
        <source>Armado Total</source>
        <translation>Totally Armed</translation>
    </message>
</context>
<context>
    <name>SensorControl</name>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name ...</translation>
    </message>
</context>
<context>
    <name>SensorControlClass</name>
    <message>
        <source>SensorControl</source>
        <translation>SensorControl</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Deshabilitar sensor</source>
        <translation>Disable sensor</translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation>Rename</translation>
    </message>
    <message>
        <source>Interviene en el armado parcial</source>
        <translation>Intervenes in partial mode</translation>
    </message>
    <message>
        <source>Interviene en el armado perimetral</source>
        <translation>Intervenes in perimetric mode</translation>
    </message>
    <message>
        <source>Tiempo de entrada:</source>
        <translation>Time before siren triggers:</translation>
    </message>
    <message>
        <source>Offset de temperatura:</source>
        <translation>Temperature offset:</translation>
    </message>
    <message>
        <source>Retraso a la activacion:</source>
        <translation>Activation delay:</translation>
    </message>
</context>
<context>
    <name>SystemConfigWindow</name>
    <message utf8="true">
        <source>Se va a proceder a importar ficheros.
Por favor, no saque el dispositivo durante la importación.
 ¿Desea continuar?</source>
        <translation>Files will be imported. 
Do not take out the device while the import is in progress.
Do you want to continue?</translation>
    </message>
    <message>
        <source>Importando...</source>
        <translation>Importing...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a exportar ficheros.
Por favor, no saque el dispositivo durante la exportación.
¿Desea continuar?</source>
        <translation>Files will be exported. 
Do not take out the device while the export is in progress. 
Do you want to continue?</translation>
    </message>
    <message>
        <source>Exportando...</source>
        <translation>Exporting...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Firmware.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation>The firmware will be updated. 
Do not take out the device while the update is in progress. 
Do you want to continue?</translation>
    </message>
    <message>
        <source>Actualizando...</source>
        <translation>Updating...</translation>
    </message>
    <message utf8="true">
        <source>Para proceder a calibrar el touch es necesario reiniciar la pantalla.
¿Desea continuar?</source>
        <translation>In order to proceed with the calibration of the touch screen, restart the screen. 
Do you want to continue?</translation>
    </message>
    <message>
        <source>Calibrar Touch...</source>
        <translation>Calibrating 
touch screen...</translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Webserver.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation>The webserver will be updated. 
Do not take out the device while the update is in progress. 
Do you want to continue?</translation>
    </message>
    <message>
        <source>Test Alarmas: %1
Pulse para %2</source>
        <translation>Alara test is %1

click on to %2</translation>
    </message>
    <message>
        <source>ON</source>
        <translation>ON</translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation>Deactivate</translation>
    </message>
    <message>
        <source>OFF</source>
        <translation>OFF</translation>
    </message>
    <message>
        <source>Activar</source>
        <translation>Activate</translation>
    </message>
    <message>
        <source>Activar licencia</source>
        <translation>Activate License</translation>
    </message>
</context>
<context>
    <name>SystemConfigWindowClass</name>
    <message>
        <source>SystemConfigWindow</source>
        <translation>SystemConfigWindow</translation>
    </message>
    <message>
        <source>Reset del Sistema</source>
        <translation>Reset System</translation>
    </message>
    <message>
        <source>Exportar Ficheros</source>
        <translation>Export Files</translation>
    </message>
    <message>
        <source>Importar  Ficheros</source>
        <translation>Import Files</translation>
    </message>
    <message>
        <source>Actualizar Firmware</source>
        <translation type="obsolete">Update Firmware</translation>
    </message>
    <message>
        <source>Acceder como
instalador</source>
        <translation>Access like 
Installer</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Recalibrar Touch</source>
        <translation>Recalibrate 
Touch Screen</translation>
    </message>
    <message>
        <source>Actualizar
Firmware</source>
        <translation>Update
Firmware</translation>
    </message>
    <message>
        <source>Log de Errores</source>
        <translation>Error Log</translation>
    </message>
    <message>
        <source>Actualizar
WebServer</source>
        <translation>Update
WebServer</translation>
    </message>
    <message>
        <source>Prueba de alarmas: %1
Pulse para %2</source>
        <translation>Alarm test is %1

Click on to %2</translation>
    </message>
    <message>
        <source>Test llamadas CRA</source>
        <translation>ARC test</translation>
    </message>
    <message>
        <source>Licencia...</source>
        <translation>License...</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation>TextLabel</translation>
    </message>
</context>
<context>
    <name>UsersConfigWindow</name>
    <message>
        <source>Nombre</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Clave</source>
        <translation>Password</translation>
    </message>
    <message>
        <source>Nivel Acceso</source>
        <translation>Access Level</translation>
    </message>
    <message>
        <source>Maestro</source>
        <translation>Master</translation>
    </message>
    <message>
        <source>Alto</source>
        <translation>High</translation>
    </message>
    <message>
        <source>Medio</source>
        <translation>Medium</translation>
    </message>
    <message>
        <source>Bajo</source>
        <translation>Low</translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation>Enter new name ...</translation>
    </message>
    <message utf8="true">
        <source>Introduzca la nueva contraseña</source>
        <translation>Enterthe new password</translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el usuario.
¿Está seguro?</source>
        <translation>The user will be deleted.
Are you sure?</translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation>Delete contact...</translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation>Missing data.</translation>
    </message>
    <message>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message utf8="true">
        <source>No se puede eliminar el único usuario maestro del sistema.</source>
        <translation>You can&apos;t delete the last user with master security level.</translation>
    </message>
    <message utf8="true">
        <source>Eliminación de usuario interrumpida.</source>
        <translation>user deletion aborted.</translation>
    </message>
</context>
<context>
    <name>UsersConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Leer Llave</source>
        <translation>Read Tag</translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Close</translation>
    </message>
</context>
<context>
    <name>WarningDialog</name>
    <message utf8="true">
        <source>Fallo en el sistema de avisos telefónicos.</source>
        <translation>Error in telealert system.</translation>
    </message>
    <message>
        <source>Test de CRA fallido.</source>
        <translation>ARC test failed.</translation>
    </message>
    <message utf8="true">
        <source>Aviso de cancelación de alarma de intrusión fallido.</source>
        <translation>Intrusion alarm cancellation alert failed.</translation>
    </message>
    <message utf8="true">
        <source>Armado de intrusión cancelado. Sensor no temporizado activo:
%1</source>
        <translation>Intrusion arming cancelled. Not temporized sensor active:
%1</translation>
    </message>
    <message>
        <source>Climatizador apagado por ventana abierta:
%1</source>
        <translation>HVAC turned OFF because of open window:
%1</translation>
    </message>
    <message>
        <source>Entrada de sensor en circuito abierto:
%1</source>
        <translation>Circuit sensor input open:
%1</translation>
    </message>
    <message utf8="true">
        <source>Cámara de videoportería ocupada.</source>
        <translation>Video doorphone camera busy.</translation>
    </message>
    <message>
        <source>No se ha encontrado el mensaje que se desea reproducir.</source>
        <translation>The message you want to play was not found.</translation>
    </message>
    <message utf8="true">
        <source>No hay espacio para grabar más mensajes de voz, o se ha alcanzado el límite de 10 mensajes.</source>
        <translation>No space for recording more voice messages, or the limit of 10 messages is exceeded.</translation>
    </message>
    <message utf8="true">
        <source>Mensaje de Aviso Nº%1</source>
        <translation>Alert message Nº%1</translation>
    </message>
    <message utf8="true">
        <source>Error en la comunicación con el módulo %1:
Comando rechazado.</source>
        <translation>Communication error with %1 module:
Command rejected.</translation>
    </message>
    <message>
        <source>Error al iniciar el sistema de ficheros. Compruebe si la tarjeta SD de la central funciona correctamente.</source>
        <translation>File system error. Check if the SD card is working correctly.</translation>
    </message>
    <message utf8="true">
        <source>El estado de la batería es bajo.</source>
        <translation>Battery status is low.</translation>
    </message>
    <message utf8="true">
        <source>Perdidas de tramas en la comunicación.</source>
        <translation>Lost frames in communication.</translation>
    </message>
    <message utf8="true">
        <source>Comunicación recuperada.</source>
        <translation>Communication established.</translation>
    </message>
    <message utf8="true">
        <source>No hay batería o la batería falla.</source>
        <translation>No battery or battery fault.</translation>
    </message>
    <message>
        <source>Iniciando el test de CRA...</source>
        <translation type="obsolete">ARC test is starting...</translation>
    </message>
    <message>
        <source>El test CRA ha sido satisfactorio.</source>
        <translation>ARC test was successful.</translation>
    </message>
    <message utf8="true">
        <source>Número de mensaje desconocido %1</source>
        <translation>Unknown message %1</translation>
    </message>
    <message>
        <source>Test de CRA...</source>
        <translation>CRA Test...</translation>
    </message>
</context>
<context>
    <name>WarningDialogClass</name>
    <message>
        <source>WarningDialog</source>
        <translation>WarningDialog</translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation>&lt;&lt;</translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation>&gt;&gt;</translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation>Delete</translation>
    </message>
</context>
<context>
    <name>ZoneSelect</name>
    <message>
        <source>luces</source>
        <translation>Lights</translation>
    </message>
    <message>
        <source>clima</source>
        <translation>Climate</translation>
    </message>
    <message>
        <source>dispositivos</source>
        <translation>Devices</translation>
    </message>
    <message>
        <source>persianas</source>
        <translation>Blinds</translation>
    </message>
    <message>
        <source>cortinas</source>
        <translation>Curtains</translation>
    </message>
    <message>
        <source>puertas</source>
        <translation>Doors</translation>
    </message>
    <message>
        <source>riegos</source>
        <translation>Irrigations</translation>
    </message>
    <message>
        <source>toldos</source>
        <translation>Awnings</translation>
    </message>
    <message>
        <source>sensores</source>
        <translation>Sensors</translation>
    </message>
</context>
<context>
    <name>ZoneSelectClass</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
</context>
</TS>
