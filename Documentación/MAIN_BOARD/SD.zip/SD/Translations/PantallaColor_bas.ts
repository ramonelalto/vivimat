<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AlarmDialog</name>
    <message utf8="true">
        <source>ALARMA DE INTRUSIÓN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALARMA DE FUEGO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALARMA DE GAS</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE INUNDACIÓN</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE ELÉCTRICO</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE CORTE TELEFÓNICO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALARMA DE SISTEMA</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ALARMA MÉDICA</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE PÁNICO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALARMA SILENCIOSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALARMA DE SABOTAJE</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ALARMA DE COACCIÓN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
 en las siguientes zonas:
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>REARMAR ALARMAS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hay alarmas desarmadas. Pulse rearmar para volver a proteger el sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar alarmas</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 90 segundos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sistema bloqueado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AlarmDialogClass</name>
    <message>
        <source>AlarmDialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Menú
Alarmas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rearmar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AlarmsWindow</name>
    <message>
        <source>---</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AlarmsWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Corte Eléctrico</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Corte de Teléfono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ArmingWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Armando...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AssociatedZonesClass</name>
    <message>
        <source>AssociatedZones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Zonas asociadas con la unidad climática...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BlackboardWindowClass</name>
    <message>
        <source>BlackboardWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BlindControl</name>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grupo de persianas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajar persianas en caso de lluvia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajar persianas en caso de viento fuerte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DOWN</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CRAConfigDialog</name>
    <message>
        <source>ADEMCO CID</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Introduzca el código de abonado ...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CRAConfigDialogClass</name>
    <message>
        <source>CRAConfigDialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuracion CRA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Habilitacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar
Codigo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Protocolo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autotest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cadencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hora del primer test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Codigo de cuenta</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CamsWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CamsWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subir Vol.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajar Vol.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Izquierda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Derecha</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClimaControl</name>
    <message utf8="true">
        <source>Frío</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Climatizador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClimaControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo general:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Primer programa asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Apagar climatización en caso de ventana abierta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Consig. Min:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Consig. Max:</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zonas
Asociadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sensor de temperatura asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Histeresis:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Segundo programa asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>modo</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>0ºC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClimaWindow</name>
    <message utf8="true">
        <source>%1ºC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>--</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClimaWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MANUAL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PROGRAMA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ECO</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>--ºC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subir</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigWindow</name>
    <message utf8="true">
        <source>Vivimat III

versión %1.%2.%3

[%4]</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión %1.%2.%3
</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Sistema de ficheros

Versión: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Vivimat III

versión Demo %1.%2.%3

[%4]</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Vision Color 7

versión Demo %1.%2.%3
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mando IR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>programas horarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>multimedia</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>gestión de energía</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>escenas</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>telefonía</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>usuarios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fecha y hora</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pantalla</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfirmationDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConsumptionWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Escala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Semana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mes</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Año</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unidades</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unit3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CurtainControl</name>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grupo de cortinas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CurtainControlClass</name>
    <message>
        <source>CurtainControl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DateHourWindow</name>
    <message>
        <source>Lunes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Martes</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Miércoles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jueves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Viernes</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Sábado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domingo</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DateHourWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DoorControl</name>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abierta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DoorControlClass</name>
    <message>
        <source>DoorControl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo de apertura / cierre:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DoorphoneDialog</name>
    <message>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llamada VIDEOPORTERO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llamada desde videoportero</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindow</name>
    <message utf8="true">
        <source>Llamada a portería</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Comunicación con portería establecida</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación porque ya se ha descolgado desde otro terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Videoportero ocupado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conserje no contesta.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible establecer comunicación, otra lladama en curso.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conserge ocupado</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EntryPhoneWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hablar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subir</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Portería</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ver</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EntryphoneConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Habilitar Desvío</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Habilitar Contestador</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Contacto al que se desvía la llamada:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Habilitar llamada desde puerta de entrada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Número de veces que sonara: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileTransfer</name>
    <message>
        <source>Aplicacion DEMO para Windows.Simulando la transferencia de ficheros.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Se ha encontrado una tarjeta SD.No saque la tarjeta hasta que finalice el intercambio de ficheros.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Se ha encontrado un dispositivo USB.No saque el dispositivo hasta que finalice el intercambio de ficheros.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No se ha encontrado ningún dispositivo.Pulsa cancelar para salir.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>La actualización ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>La exportación ha finalizado.Pulsa Aceptar para continuar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>La importación ha finalizado.Es necesario reiniciar el sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No existe un fichero de firmware. Inserte un dispositivo con un fichero de firmware.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error a la hora de copiar el nuevo firmware.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No se encuentran todos los ficheros necesarios para la actualizacion del servidor web.
No se ha podido realizar la actualización.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>La actualización ha fallado. Se mantiene el viejo rcS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cp -rf %1/PantallaColor /App/PantallaColor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileTransferClass</name>
    <message>
        <source>FileTransfer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FloorSelectClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subir</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HistoryWindow</name>
    <message>
        <source>Historial de Eventos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Historial de Errores</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HistoryWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Historial de Eventos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>01/01/2010 13:39:05 &gt; System initialization completed
01/01/2010 13:45:15 &gt; Intrusion alarm armed in total mode: Sergio
01/01/2010 13:50:05 &gt; Intrusion alarm disarmed: Sergio
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IRCodeReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apunte el mando hacia el
receptor y pulse la tecla
correspondiente...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Leer código de infrarrojos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindow</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Activar pánico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encender clima</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apagar clima</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Código IR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la acción.
¿Está seguro?</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Eliminar acción...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - ON/OFF -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Regulable -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - RGB -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los tipos -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Individual - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Zona - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Todas las luces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Individual - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Zona - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Persiana normal -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Persiana posicional -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Persianas agupadas -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cualquier persiana -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Toldo normal -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Toldo posicional -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Toldos agupados -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cualquier toldo -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cortina normal -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cortina posicional -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cortinas agupadas -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cualquier cortina -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Puerta motorizada -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Conmutar cámara</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IRControlConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Código</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialog</name>
    <message>
        <source>Ejecutar Escena</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Arm. Intrusión Modo Perimetral</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Activar pánico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abrir videoportero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encender luz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apagar luz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aumentar luz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disminuir luz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subir dis. motorizado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajar dis. motorizado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encender Clima</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apagar Clima</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encender enchufe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apagar enchufe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Luz regulable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dispositivo individual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dispositivos de la zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conmutar camara</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IRkeyActionDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Cambiar acción asociada a la tecla</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Acción:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IconChangeDialogClass</name>
    <message>
        <source>IconChangeDialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IrrigatorControl</name>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>En espera</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IrrigatorControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Detener riego en caso de lluvia o suelo ya húmedo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sensor de humedad asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duracion del riego (minutos):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyReadDialog</name>
    <message utf8="true">
        <source>- Código: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
- Tipo: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
- Asignada a: </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Llave desconocida.
- Código: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyReadDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Acerque la llave
para ser leída</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Leer llave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyRecordDialog</name>
    <message utf8="true">
        <source>El usuario tiene
asociada la llave
con código: </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No hay espacio
para grabar más llaves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acerque la llave
para ser grabada</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder
a borrar la llave.
¿Está seguro?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La llave ya ha
sido grabada antes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Llave leída.
- Código: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyRecordDialogClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El usuario no tiene
llave asociada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grabar llave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo de llave:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Guardar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grabar
llave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Borrar
llave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyboardClass</name>
    <message>
        <source>Keyboad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&gt;&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bloq May</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Ñ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>J</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ó</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>é</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ş</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ö</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Ó</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>,</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>É</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ü</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>á</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>@</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ú</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Í</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Ç</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Ú</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ǧ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Á</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>*</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ç</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>í</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>f</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>j</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>v</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>i</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ñ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>r</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>g</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>w</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>u</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>e</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ف</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ى</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ح</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ه</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ا</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ع</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>خ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ي</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>م</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ة</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ض</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ب</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ص</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ت</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ث</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>و</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ش</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ق</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>لا</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ؤ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>س</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ن</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>غ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ك</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ل</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ر</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ئ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ء</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ظ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ز</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>د</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ج</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ط</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٨</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٤</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٣</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٧</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ذ</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>١</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٢</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٩</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٦</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>٥</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LicenseSystem</name>
    <message>
        <source>Introduzca licencia...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>La licencia caducará en %1 días. 
Para poder seguir usando el sistema Vivimat III deberá llamar a su instalador para que le proporcione una licencia 
 válida. Deberá indicarle el número de licencia que aparece a continuación para poder activar el sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Número de licencia:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licencia....</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LightControl</name>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Presencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crepuscular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crep + Pres</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pres + Prog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LightControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Consigna en modo presencia:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sensor de presencia asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Retraso a la desactivación:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message utf8="true">
        <source>Cerrar sesión</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>inicio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>---</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>videoportero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>seguridad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>escenas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mensajes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>configurar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>clima</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>cámaras</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>programas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>alarmas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>historial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fotos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pizarra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sos</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible visualizar las cámaras porque ya están siendo visualizadas en otro terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Cámaras ocupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para desarmar</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para menú de seguridad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sistema bloqueado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Antes de poder usar los mensajes de voz es necesario tener grabados los mensajes personales.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensajes personales sin grabar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LUN </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MAR </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MIE </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JUE </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VIE </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SAB </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DOM </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dd/MM/yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>INT %1 ºC</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Los ficheros de configuración no coinciden.
Para sobreescribir los ficheros de la central en la pantalla pulsa Aceptar. En caso contrario, pulsa Cancelar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Actualizar configuración</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código IR:
%1 %2 %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Código IR leído</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se ha leido el código RFID:
%1 %2 %3 %4</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Llave leída</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>El idioma del sistema ha sido modificado.
¿Desea reiniciar la pantalla?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actualizar idioma...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Sistema bloqueado tras tres intentos de introdución de clave fallidos.
 Para volver a introducir el password espere 90 segundos.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindowClass</name>
    <message>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>12:30</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MAR 15/11/2009</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>INT 18ºC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessagesWindow</name>
    <message>
        <source>Tipo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Origen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha/Hora</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Videoportero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Terminal 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Terminal 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Terminal 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desconocido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voz</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible borrar los mensajes, los mensajes de voz ya están siendo usados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessagesWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grabar
mensaje</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Borrar
mensajes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MsgProgressDialogClass</name>
    <message>
        <source>RecWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordClass</name>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Introduzca contraseña para continuar...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialog</name>
    <message utf8="true">
        <source>No es posible grabar el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensajes de voz en uso</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se van a eliminar todos los mensajes.
¿Está seguro?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eliminar mensajes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grabando mensaje...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No es posible reproducir el mensaje, los mensajes de voz ya están siendo usados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reproduciendo mensaje...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PersonalMsgDialogClass</name>
    <message>
        <source>ConfirmationWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensajes de voz personalizados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aceptar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensaje para llamadas de alarma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reproducir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grabar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensaje para contestador de videoportero</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Para grabar los mensajes de voz personalizados primero se borraran todos los mensajes, después se grabará el mensaje para llamadas de alarma y a continuación el mensaje para contestador de videoportero.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindow</name>
    <message>
        <source>Tipo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Número</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TEL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CRA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Es necesario introducir primero el tipo de contacto.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Introduzca nuevo número o dirección de correo ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el contacto.
¿Está seguro?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PhoneConfigWindowClass</name>
    <message>
        <source>PhoneConfigWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Habilitar avisos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Habilitar telecontrol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tonos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configurar
CRA</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PhotosWindow</name>
    <message>
        <source>Marco de fotos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No hay fotos disponibles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No se puede mostrar la foto (%1).</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlugControl</name>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlugControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>salida temporizada </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>segundos</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindow</name>
    <message>
        <source>Temperatura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ON-OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Las franjas horarias no están bien definidas.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0 = OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 = ON</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgramModifyWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Días de ejecución:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>J</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inicio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Consigna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Franja 1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Franja 2:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Franja 3:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Franja 4:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Franja 5:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgramsWindow</name>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>J</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperatura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0-100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ON/OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el programa.
¿Está seguro?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eliminar programa...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgramsWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>J</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RBlindControl</name>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grupo de toldos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estado desconocido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RBlindControlClass</name>
    <message>
        <source>PruebaStacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa asociado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plegar toldos en caso de viento fuerte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo de subida / bajada:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo de funcionamiento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cambiar icono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disposit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>todos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plegar toldos en caso de lluvia</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SOSWindow</name>
    <message utf8="true">
        <source>Alarma de pánico deshabilitada</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SOSWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SOS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>STOP</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneConditionDialog</name>
    <message>
        <source>Sin condicionar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cualquier llave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave tipo A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave tipo B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave tipo C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave tipo D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave tipo E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave tipo F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llave: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fecha</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Día semana</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión armada</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión desarmada</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Activación de cualquier alarma</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de intrusión</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Act. alm. de fuego</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Act. alm. de gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de inundación</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de corte eléc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Act. alm. de corte tlf.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Act. alm. de sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Act. alm. médica</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de pánico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Act. alm. silenciosa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Act. alm. de sabotaje</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Act. alm. de coacción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entrada en Central</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entrada en MOD0035</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Intrusion en armado total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Intrusion en armado perimetral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Intrusion en armado parcial</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneConditionDialogClass</name>
    <message>
        <source>EventConditionWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condiciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condicion de llave:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condicion de hora:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condicion de Fecha / Dia semana:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condicion de alarma:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>J</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condicion de entrada:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo de modulo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E/S:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mod:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneEventWindow</name>
    <message utf8="true">
        <source>Iluminación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Riego</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Retardo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Luz individual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Luces de la zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todas las luces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Luz ON/OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Luz Regulable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los tipos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>20%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>40%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>60%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>80%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enchufe individual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enchufes de la zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los enchufes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apagar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Climatizador individual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los climatizadores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apagado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modo programa</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Modo económico</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>%1ºC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Riego individual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Riegos de la zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los riegos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Activar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 seg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3 seg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5 seg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>10 seg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>20 seg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>30 seg</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte telefónico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dis. individual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dis. de la zona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Todos los dispositivos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Persiana normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Persiana posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Persianas agrupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cualquier persiana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toldo normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toldo posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toldos agrupados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cualquier toldo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cortina normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cortina posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cortinas agrupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cualquier cortina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Puerta motorizada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abrir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enchufe normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enchufes temporizados</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneEventWindowClass</name>
    <message>
        <source>SceneEventWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modificar evento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo de evento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo de control:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tipo de elemento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Elemento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Valor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindow</name>
    <message>
        <source>Evento</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el evento.
¿Está seguro?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eliminar evento...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Iluminación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - ON/OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Regulable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - RGB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los tipos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Individual: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Zona: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todas las luces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dis. motorizado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Persiana normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Persiana posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Persianas agupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cualquier persiana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Toldo normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Toldo posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Toldos agupados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cualquier toldo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cortina normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cortina posicional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cortinas agupadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Cualquier cortina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Puerta motorizada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los dispositivos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enchufe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los enchufes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Encender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Apagar</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Climatización</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los climatizadores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Apagado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Modo manual - </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>ºC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Modo programa</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source> - Modo económico - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Riego</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos los riegos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Activar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Desactivar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Retardo - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Seguridad</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de intrusión</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alarma de fuego</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alarma de gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de inundación</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte eléctrico</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de corte de teléfono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alarma de sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma médica</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de pánico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alarma silenciosa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alarma de sabotaje</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alarma de coacción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deshabilitar alarma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Habilitar alarma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Activar alarma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Armar en modo perimetral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Armar en modo parcial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Armar en modo total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desarmar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desarmar parcialmente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Todos </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - No temporizados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Temporizados</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScenesConfigWindowClass</name>
    <message>
        <source>ScenesConfigWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindow</name>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar la escena.
¿Está seguro?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eliminar escena...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScenesSelectWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScenesWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindow</name>
    <message>
        <source>Castellano</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Inglés</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Portugués</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Francés</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Alemán</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Euskera</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Catalán</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gallego</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turco</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italiano</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Árabe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>20 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>40 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>60 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>80 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>100 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Marco de fotos digital</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 minuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 minuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5 minuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>10 minuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>15 minuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>30 minuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nunca</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Botón</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Acción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oscuro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Verde</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(vacio)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Azul</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Negro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScreenConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Identificador de pantalla</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Idioma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Volumen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sonido teclado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sensor de presencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Paleta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Color iconos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Offset de temperatura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visualizar cursor</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para ejecutar escenas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Salvapantallas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Salvapantallas</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source> Activación Salvapantallas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Tiempo entre fotos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Autoapagado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Botones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Habilitación tamper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IP</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindow</name>
    <message>
        <source>Armado total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Armado parcial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Armado perimetral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ninguno</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Intrusión</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Habilitar autoarmado de intrusión</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programa asociado el autoarmado</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Activar simulación de presencia con el armado total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo de salida de la vivienda (seg):</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Pedir contraseña para armar la alarma de intrusión</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incendio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Inundación</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Hora de auto limpieza de la electroválvula de agua:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Corte Red Eléctrica</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (min):</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Corte teléfono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Médica</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Detección de inactividad</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Pánico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Silenciosa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sabotaje</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Coacción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Llamar en caso de alarma a:</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Teléfono 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Teléfono 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Teléfono 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Teléfono 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Teléfono 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Teléfono 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Teléfono 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Teléfono 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mensajes
Personales</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Retraso a la activación (seg):</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Armado Perimetral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Armado Parcial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Armado Total</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SensorControl</name>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SensorControlClass</name>
    <message>
        <source>SensorControl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deshabilitar sensor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Renombrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interviene en el armado parcial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interviene en el armado perimetral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo de entrada:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Offset de temperatura:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Retraso a la activacion:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SystemConfigWindow</name>
    <message utf8="true">
        <source>Se va a proceder a importar ficheros.
Por favor, no saque el dispositivo durante la importación.
 ¿Desea continuar?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importando...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a exportar ficheros.
Por favor, no saque el dispositivo durante la exportación.
¿Desea continuar?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exportando...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Firmware.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actualizando...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se va a proceder a actualizar el Webserver.
Por favor, no saque el dispositivo durante la actualización.
 ¿Desea continuar?</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Para proceder a calibrar el touch es necesario reiniciar la pantalla.
¿Desea continuar?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calibrar Touch...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test Alarmas: %1
Pulse para %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desactivar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Activar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Activar licencia</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SystemConfigWindowClass</name>
    <message>
        <source>SystemConfigWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset del Sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exportar Ficheros</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importar  Ficheros</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actualizar
Firmware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acceder como
instalador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recalibrar Touch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log de Errores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actualizar
WebServer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prueba de alarmas: %1
Pulse para %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test llamadas CRA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licencia...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UsersConfigWindow</name>
    <message>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nivel Acceso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maestro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Medio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bajo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introduzca nuevo nombre ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Introduzca la nueva contraseña</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Se va a eliminar el usuario.
¿Está seguro?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eliminar contacto...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Faltan datos por rellenar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No se puede eliminar el único usuario maestro del sistema.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Eliminación de usuario interrumpida.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UsersConfigWindowClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Leer Llave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aplicar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WarningDialog</name>
    <message utf8="true">
        <source>Fallo en el sistema de avisos telefónicos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test de CRA fallido.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Aviso de cancelación de alarma de intrusión fallido.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Armado de intrusión cancelado. Sensor no temporizado activo:
%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Climatizador apagado por ventana abierta:
%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Entrada de sensor en circuito abierto:
%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Cámara de videoportería ocupada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No se ha encontrado el mensaje que se desea reproducir.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No hay espacio para grabar más mensajes de voz, o se ha alcanzado el límite de 10 mensajes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Error en la comunicación con el módulo %1:
Comando rechazado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error al iniciar el sistema de ficheros. Compruebe si la tarjeta SD de la central funciona correctamente.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>El estado de la batería es bajo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Perdidas de tramas en la comunicación.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Comunicación recuperada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Mensaje de Aviso Nº%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>No hay batería o la batería falla.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El test CRA ha sido satisfactorio.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Número de mensaje desconocido %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test de CRA...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WarningDialogClass</name>
    <message>
        <source>WarningDialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Borrar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ZoneSelect</name>
    <message>
        <source>luces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>clima</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dispositivos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>persianas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cortinas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>puertas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>riegos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>toldos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sensores</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ZoneSelectClass</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
